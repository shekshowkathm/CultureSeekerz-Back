package com.cultureSeekerz.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cultureSeekerz.Enum.Role;
import com.cultureSeekerz.dto.ActiveClassResponse;
import com.cultureSeekerz.entity.ActiveClass;
import com.cultureSeekerz.requestDTO.SearchClassDTO;
import com.cultureSeekerz.service.ActiveClassService;

@RestController
@RequestMapping("/activeclass")
@CrossOrigin("*")
public class ActiveClassController {

	@Autowired
	public ActiveClassService activeClassService;

	@PostMapping("/add")
	@PreAuthorize("hasAuthority('TEACHER')")
	public ActiveClass createActiveClass(@RequestBody ActiveClass activeClass) {
		return activeClassService.createClass(activeClass);
	}

	@GetMapping("/getactiveclass/{timeZone}")
	public List<ActiveClassResponse> getAllActiveClasses(@PathVariable String timeZone) {
		return activeClassService.getAll(Role.USER, timeZone);
	}

	@GetMapping("/getActiveClass/{id}/{timeZone}")
	public ActiveClassResponse retrieveActiveClassById(@PathVariable Long id, @PathVariable String timeZone) {
		return activeClassService.retrieveActiveCassById(id, Role.USER, timeZone);
	}

	@GetMapping("/getbyactivity/{activity}/{timeZone}")
	public List<ActiveClassResponse> retrieveByActivity(@PathVariable String activity, @PathVariable String timeZone) {
		return activeClassService.getByActivity(activity, Role.USER, timeZone);
	}

	@GetMapping("/getagegroup/{ageGroup}/{timeZone}")
	public List<ActiveClassResponse> getClassByAgeGroup(@PathVariable String ageGroup, @PathVariable String timeZone) {
		return activeClassService.getByClassByAgeGroup(ageGroup, Role.USER, timeZone);
	}

	@PostMapping("/search")
	public List<ActiveClassResponse> search(@RequestBody SearchClassDTO searchRequestDto) {
		return activeClassService.search(searchRequestDto, Role.USER);
	}

	@GetMapping("/getClasses/{activity}/{approveStatus}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<ActiveClassResponse> retrieveAllClasses(@PathVariable String activity,
			@PathVariable boolean approveStatus) {
		return activeClassService.getAllClasses(Role.ADMIN, activity, approveStatus);
	}

	@GetMapping("/getClassesByUniqueId/{classUniqueId}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<ActiveClassResponse> getClassByClassUniqueId(@PathVariable String classUniqueId) {
		return activeClassService.getClassByUniqueId(classUniqueId, Role.ADMIN);
	}

	@GetMapping("/getTeachersClasses/{uniqueId}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<ActiveClassResponse> retrieveScheduledClassBuuniqueId(@PathVariable String uniqueId) {
		return activeClassService.getScheduledClassByUniqueId(uniqueId, Role.ADMIN);
	}

	@PutMapping("/approveclass/{id}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public String approveClas(@PathVariable Long id) {
		return activeClassService.approveClass(id);
	}

	@PutMapping("/update")
	@PreAuthorize("hasAuthority('TEACHER')")
	public Map<String, String> updateDayAndTime(@RequestBody ActiveClass activeClass) {
		return activeClassService.updateDayAndTime(activeClass);
	}

	@PutMapping("/meetingLink")
	@PreAuthorize("hasAuthority('ADMIN')")
	public Map<String, String> updateMeetingLink(@RequestParam Long id, @RequestParam String meetingLink) {
		return activeClassService.addMeetingLink(id, meetingLink);
	}

	@GetMapping("/trialclassSearch/{activity}/{timeZone}")
	public List<ActiveClassResponse> searchTrialClasses(@PathVariable String activity, @PathVariable String timeZone) {
		return activeClassService.searchTrialClassByActivity(activity, Role.USER, timeZone);
	}

	@GetMapping("/getTopics/{id}")
	@PreAuthorize("hasAuthority('TEACHER')")
	public List<String> getTopics(@PathVariable Long id) {
		return activeClassService.getTopics(id);
	}
}
