<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <style>
        body {
            height: 100%;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 13px;
        }

        .template-container {
            padding: 0px 25px 10px 25px;
        }
        button{
            width: 200px;
             height: 30px;
             background-color:#f76a00;
             border: none;
             border-radius: 5px;
            a{
                text-decoration: none;
                font-family: "Poppins", sans-serif;
                color:#ffff;
                font-size: 16px;
                font-weight: 400;
            }
        }
       

    </style>
</head>

<body>
    
        <img src="cid:logoImage" alt="Logo">
        <div class="template-container">
        <p>Hi,</p>
        <p>Please join us for a captivating trial session in ${activity} on ${date} at ${time} ${timeZone}.</p>
        <p>Access the online class via the following link</p>
        <button><a href="${meetingLink}">Trial class link</a></button>
        <p>We eagerly anticipate your participation for an immersive and educational experience.</p><br>

        <p>Best regards,</p>
        <p>CultureSeekerz Team.</p>
    </div>


</body>

</html>