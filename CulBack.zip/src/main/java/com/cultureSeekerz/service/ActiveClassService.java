package com.cultureSeekerz.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cultureSeekerz.Enum.Role;
import com.cultureSeekerz.dto.ActiveClassResponse;
import com.cultureSeekerz.dto.ParentResponseDTO;
import com.cultureSeekerz.dto.ScheduleClassResponseDTO;
import com.cultureSeekerz.dto.StudentResponse;
import com.cultureSeekerz.dto.TeacherInfoResponse;
import com.cultureSeekerz.dto.TeacherResponseDTO;
import com.cultureSeekerz.entity.ActiveClass;
import com.cultureSeekerz.entity.DayAndTime;
import com.cultureSeekerz.entity.Seekerz;
import com.cultureSeekerz.entity.Student;
import com.cultureSeekerz.entity.Teacher;
import com.cultureSeekerz.repository.IActiveClassRepository;
import com.cultureSeekerz.repository.IDayAndTimeRepository;
import com.cultureSeekerz.repository.ISeekerzRepository;
import com.cultureSeekerz.repository.ITeacherRepository;
import com.cultureSeekerz.requestDTO.SearchClassDTO;
import com.cultureSeekerz.responseDTO.DayAndTimeDTO;
import com.cultureSeekerz.utils.DynamicSelectors;
import com.cultureSeekerz.utils.EmailSender;
import com.cultureSeekerz.utils.TimeZoneConvertor;
import com.cultureSeekerz.utils.UniqueIdGenerator;

@Service
public class ActiveClassService {

	@Autowired
	private IActiveClassRepository activeClassRepository;

	@Autowired
	private EmailSender emailSender;

	@Autowired
	private ITeacherRepository teacherRepository;

	@Autowired
	private ISeekerzRepository seekerzRepository;

	@Autowired
	private IDayAndTimeRepository dayAndTimeRepository;

	@Autowired
	private TimeZoneConvertor timeZoneConvertor;

	/**
	 * Adding class by teacher
	 * 
	 * @Role TEACHER
	 * @param activeClass
	 * @return
	 */
	public ActiveClass createClass(ActiveClass activeClass) {
		activeClass.setDayAndTime(createDayAndTime(activeClass.getDayAndTime()));
		Teacher teacher = teacherRepository.findById(activeClass.getTeacher().getId()).get();
		activeClass.setUniqueId(teacher.getUniqueId());
		activeClass.setClassUniqueId(UniqueIdGenerator.generateUniqueId(activeClass.getActivity()));
		activeClass.setClassImage(DynamicSelectors.getImageUrl(activeClass.getActivity()));
		activeClass.setFeesRange(DynamicSelectors.getFeesRange(activeClass.getAgeGroup()));
		activeClassRepository.save(activeClass);
		teacher.getClasses().add(activeClass);
		teacherRepository.save(teacher);
		return activeClass;
	}

	private List<DayAndTime> createDayAndTime(List<DayAndTime> dayAndTime) {
		List<DayAndTime> dayAndTimeResponse = new ArrayList<DayAndTime>();
		for (DayAndTime dayAndTimeObj : dayAndTime) {
			DayAndTime newDayAndTime = new DayAndTime();
			newDayAndTime.setDay(dayAndTimeObj.getDay());
			newDayAndTime.setStartDate(dayAndTimeObj.getStartDate());
			newDayAndTime.setEndDate(dayAndTimeObj.getEndDate());
			newDayAndTime.setStartTime(dayAndTimeObj.getStartTime());
			newDayAndTime.setEndTime(dayAndTimeObj.getEndTime());
			newDayAndTime.setMeetingLink(dayAndTimeObj.getMeetingLink());
			dayAndTimeRepository.save(newDayAndTime);
			dayAndTimeResponse.add(newDayAndTime);
		}
		return dayAndTimeResponse;
	}

	public List<ActiveClassResponse> getAll(Role value, String timeZone) {
		List<ActiveClassResponse> response = new ArrayList<ActiveClassResponse>();
		List<ActiveClass> activeClasses = activeClassRepository.findByApproveIsTrue();
		for (ActiveClass activeClass : activeClasses) {

			ActiveClassResponse activeClassResponse = new ActiveClassResponse();
			activeClassResponse.setClassId(activeClass.getId());
			activeClassResponse.setTeacherId(activeClass.getTeacher().getId());
			activeClassResponse.setTeacherResponse(teacherResponse(activeClass.getTeacher()));
			activeClassResponse.setScheduleClass(scheduleClassResponse(activeClass, value, timeZone));
			response.add(activeClassResponse);
		}
		return response;
	}

	/**
	 * Retrieve all the teacher
	 * 
	 * @Role TEACHER
	 * @return
	 */
	public List<ActiveClassResponse> getAllClasses(Role value, String activity, boolean approveStatus) {
		List<ActiveClass> activeClasses = null;
		if (approveStatus) {
			activeClasses = activeClassRepository.findByActivityAndApproveIsTrue(activity);
		} else {
			activeClasses = activeClassRepository.findByActivityAndApproveIsFalse(activity);
		}
		List<ActiveClassResponse> response = new ArrayList<ActiveClassResponse>();
		for (ActiveClass activeClass : activeClasses) {
			response.add(activeClassResponse(activeClass, value, "Ist"));
		}
		return response;
	}

	public List<ActiveClassResponse> getClassByUniqueId(String classUniqueId, Role value) {
		List<ActiveClass> activeClasses = activeClassRepository.findByClassUniqueId(classUniqueId);
		List<ActiveClassResponse> response = new ArrayList<ActiveClassResponse>();
		for (ActiveClass activeClass : activeClasses) {
			response.add(activeClassResponse(activeClass, value, "Ist"));
		}
		return response;
	}

	public List<ActiveClassResponse> getScheduledClassByUniqueId(String uniqueId, Role value) {
		List<ActiveClass> activeClasses = activeClassRepository.findByUniqueId(uniqueId);
		List<ActiveClassResponse> response = new ArrayList<ActiveClassResponse>();
		for (ActiveClass activeClass : activeClasses) {
			response.add(activeClassResponse(activeClass, value, "Ist"));
		}
		return response;
	}

	public ActiveClassResponse retrieveActiveCassById(Long id, Role value, String timeZone) {
		ActiveClass activeClass = activeClassRepository.findById(id).get();
		return activeClassResponse(activeClass, value, timeZone);
	}

	/**
	 * Retrieve class by activity
	 * 
	 * @param activity
	 * @return
	 */
	public List<ActiveClassResponse> getByActivity(String activity, Role value, String timeZone) {
		List<ActiveClassResponse> response = new ArrayList<ActiveClassResponse>();
		List<ActiveClass> classes = activeClassRepository.findByActivityAndApproveIsTrue(activity);
		for (ActiveClass activeClass : classes) {
			response.add(activeClassResponse(activeClass, value, timeZone));
		}
		return response;
	}

	/**
	 * For approving the class
	 * 
	 * @Role ADMIN
	 * @param id
	 * @return
	 */
	public String approveClass(Long id) {
		ActiveClass activeClass = activeClassRepository.findById(id).get();
		if (activeClass.isApprove() == true) {
			activeClass.setApprove(false);
			activeClassRepository.save(activeClass);
			return "false";
		} else {
			activeClass.setApprove(true);
			activeClassRepository.save(activeClass);
			return "true";
		}
	}

	/**
	 * Search the class
	 * 
	 * @param searchRequestDto
	 * @return
	 */
	public List<ActiveClassResponse> search(SearchClassDTO searchRequestDto, Role value) {
		List<ActiveClassResponse> response = new ArrayList<>();

		List<ActiveClassResponse> timeZoneConverted = getAll(value, searchRequestDto.getTimeZone());

		List<ActiveClass> activity = activeClassRepository
				.findByActivityAndApproveIsTrue(searchRequestDto.getActivity());
		List<ActiveClass> ageGroup = null;
		List<ActiveClass> classType = null;
		List<ActiveClass> day = null;

		if (searchRequestDto.getAgeGroup() != null) {
			ageGroup = activeClassRepository.findByAgeGroupContainingAndApproveIsTrue(searchRequestDto.getAgeGroup());
		}
		if (searchRequestDto.getClassType() != null) {
			classType = activeClassRepository
					.findByClassTypeContainingAndApproveIsTrue(searchRequestDto.getClassType());
		}
		if (searchRequestDto.getDay() != null) {
			List<ActiveClass> formatedDayClassId = new ArrayList<ActiveClass>();
			for (ActiveClassResponse convertedTimeZone : timeZoneConverted) {
				for (String convertedDay : convertedTimeZone.getScheduleClass().getDay()) {
					if (convertedDay.equals(searchRequestDto.getDay())) {
						ActiveClass activeClass = activeClassRepository.findById(convertedTimeZone.getClassId()).get();
						formatedDayClassId.add(activeClass);
					}
				}
			}
			day = formatedDayClassId;
		}

		Set<Long> commonIds = new HashSet<>();
		if (activity != null)
			commonIds.addAll(activity.stream().map(ActiveClass::getId).collect(Collectors.toSet()));
		if (ageGroup != null)
			commonIds.retainAll(ageGroup.stream().map(ActiveClass::getId).collect(Collectors.toSet()));
		if (classType != null)
			commonIds.retainAll(classType.stream().map(ActiveClass::getId).collect(Collectors.toSet()));
		if (day != null)
			commonIds.retainAll(day.stream().map(ActiveClass::getId).collect(Collectors.toSet()));

		for (Long commonId : commonIds) {
			ActiveClass commonActiveClass = activity.stream().filter(ac -> ac.getId().equals(commonId)).findFirst()
					.orElse(null);
			if (commonActiveClass != null) {
				response.add(activeClassResponse(commonActiveClass, value, searchRequestDto.getTimeZone()));
			}
		}
		return response;
	}

	/**
	 * Retrieve the class by ageGroup
	 * 
	 * @param ageGroup
	 * @return
	 */
	public List<ActiveClassResponse> getByClassByAgeGroup(String ageGroup, Role value, String timeZone) {

		List<ActiveClassResponse> response = new ArrayList<ActiveClassResponse>();
		List<ActiveClass> classes = activeClassRepository.findByAgeGroupContainingAndApproveIsTrue(ageGroup);
		for (ActiveClass activeClass : classes) {
			response.add(activeClassResponse(activeClass, value, timeZone));
		}
		return response;
	}

	public Map<String, String> addMeetingLink(Long id, String meetingLink) {
		DayAndTime dayAndTime = dayAndTimeRepository.findById(id).get();
		dayAndTime.setMeetingLink(meetingLink);
		dayAndTimeRepository.save(dayAndTime);
		return Collections.singletonMap("Message", "Update successfully");
	}

	public List<ActiveClassResponse> searchTrialClassByActivity(String activity, Role value, String timeZone) {
		List<Teacher> teachers = teacherRepository
				.findBySpecializedInContainingAndApproveIsTrueAndTrailClassIsTrue(activity);
		List<ActiveClassResponse> response = new ArrayList<>();

		for (Teacher teacher : teachers) {
			for (ActiveClass activeClass : teacher.getClasses()) {
				if (activeClass.getActivity().equals(activity)) {
					response.add(activeClassResponse(activeClass, value, timeZone));
				}
			}
		}
		return response;
	}

	public List<String> getTopics(Long id) {
		ActiveClass activeClass = activeClassRepository.findById(id).get();
		List<String> topics = activeClass.getTopics();
		return topics;
	}

	// Teacher service
	public List<ScheduleClassResponseDTO> scheduleClassResponseForTeacher(List<ActiveClass> activeClasses, Role value) {
		List<ScheduleClassResponseDTO> scheduleClassResponses = new ArrayList<>();
		for (ActiveClass activeClass : activeClasses) {
			scheduleClassResponses.add(scheduleClassResponse(activeClass, value, "Ist"));
		}
		return scheduleClassResponses;
	}

	/* Private methods */

	public ActiveClassResponse activeClassResponse(ActiveClass activeClass, Role value, String timeZone) {
		ActiveClassResponse activeClassResponse = new ActiveClassResponse();
		activeClassResponse.setClassId(activeClass.getId());
		activeClassResponse.setTeacherId(activeClass.getTeacher().getId());
		activeClassResponse.setTeacherResponse(teacherResponse(activeClass.getTeacher()));
		activeClassResponse.setScheduleClass(scheduleClassResponse(activeClass, value, timeZone));

		return activeClassResponse;
	}

	private ScheduleClassResponseDTO scheduleClassResponse(ActiveClass activeClass, Role value, String timeZone) {
		ScheduleClassResponseDTO scheduleClassResponse = new ScheduleClassResponseDTO();
		scheduleClassResponse.setClassId(activeClass.getId());
		scheduleClassResponse.setFeesRange(activeClass.getFeesRange());
		scheduleClassResponse.setDescription(activeClass.getDescription());
		scheduleClassResponse.setDemoVideo(activeClass.getDemoVideo());
		scheduleClassResponse.setActivity(activeClass.getActivity());
		scheduleClassResponse.setClassType(activeClass.getClassType());
		scheduleClassResponse.setAgeGroup(activeClass.getAgeGroup());
		scheduleClassResponse.setApprove(activeClass.isApprove());
		scheduleClassResponse.setTeacher(teacherInfo(activeClass));
		scheduleClassResponse.setClassImage(activeClass.getClassImage());
		scheduleClassResponse.setClassUniqueId(activeClass.getClassUniqueId());
		if (value == Role.ADMIN) {
			scheduleClassResponse.setFeesInr(activeClass.getFeesInr());
		}
		if (activeClass.getDayAndTime() != null && !activeClass.getDayAndTime().isEmpty()) {
			List<DayAndTimeDTO> dayAndTimeDTO = new ArrayList<>();
			List<String> convertedDays = new ArrayList<>();
			Set<String> uniqueDays = new HashSet<>();
			for (DayAndTime dayAndTimeObj : activeClass.getDayAndTime()) {
				DayAndTimeDTO converted = timeZoneConvertor.timeZoneConvertor(dayAndTimeObj, value, timeZone);
				dayAndTimeDTO.add(converted);
				String convertedDay = converted.getDay();
				if (uniqueDays.add(convertedDay)) {
					convertedDays.add(convertedDay);
				}
			}
			scheduleClassResponse.setDay(convertedDays);
			scheduleClassResponse.setDayAndTimeDTO(dayAndTimeDTO);
		} else {
			scheduleClassResponse.setDay(activeClass.getDay());
		}

		return scheduleClassResponse;
	}

	private TeacherResponseDTO teacherResponse(Teacher teacher) {
		TeacherResponseDTO teacherResponse = new TeacherResponseDTO();
		Seekerz seekerz = teacher.getBasicInfo();
		teacherResponse
				.setName(emailSender.name(seekerz.getFirstName(), seekerz.getMiddleName(), seekerz.getLastName()));
		teacherResponse.setEmail(seekerz.getEmail());
		teacherResponse.setGender(seekerz.getGender());
		teacherResponse.setUG(teacher.getuG());
		teacherResponse.setPG(teacher.getpG());
		teacherResponse.setB_Ed(teacher.isB_Ed());
		teacherResponse.setM_Ed(teacher.isM_Ed());
		teacherResponse.setExperience(teacher.getExperience());
		teacherResponse.setSpecializedIn(teacher.getSpecializedIn());
		teacherResponse.setAdditionalQualification(teacher.getAdditionalQualification());
		teacherResponse.setMode(teacher.getMode());
		teacherResponse.setProfile(teacher.getProfile());
		teacherResponse.setAbout(teacher.getAbout());
		teacherResponse.setTeacherId(teacher.getId());
		teacherResponse.setTrailClass(teacher.isTrailClass());
		teacherResponse.setTeacherUniqueId(teacher.getUniqueId());
		return teacherResponse;
	}

	public StudentResponse studentResponsePayment(Student student, Role value) {
		StudentResponse studentResponse = new StudentResponse();
		studentResponse.setStudentName(emailSender.name(student.getStudentInfo().getFirstName(),
				student.getStudentInfo().getMiddleName(), student.getStudentInfo().getLastName()));
		if (value != Role.TEACHER) {
			studentResponse.setDayAndTime(dayAndTimeResponse(student));
		}
		studentResponse.setAge(student.getStudentInfo().getAge());
		studentResponse.setStudentId(student.getId());
		studentResponse.setSelectedDate(student.getStudentStartDate());
		return studentResponse;
	}

	private TeacherInfoResponse teacherInfo(ActiveClass activeClass) {
		TeacherInfoResponse teacherInfoResponse = new TeacherInfoResponse();
		teacherInfoResponse.setTeacherName(emailSender.name(activeClass.getTeacher().getBasicInfo().getFirstName(),
				activeClass.getTeacher().getBasicInfo().getMiddleName(),
				activeClass.getTeacher().getBasicInfo().getLastName()));
		teacherInfoResponse.setTeacherProfile(activeClass.getTeacher().getProfile());
		teacherInfoResponse.setTeacherId(activeClass.getTeacher().getId());

		teacherInfoResponse.setTeacherEmail(activeClass.getTeacher().getBasicInfo().getEmail());
		teacherInfoResponse.setTeacherPhoneNumber(activeClass.getTeacher().getBasicInfo().getMobileNumber());
		return teacherInfoResponse;

	}

	private ParentResponseDTO parentResponse(Student student) {
		ParentResponseDTO response = new ParentResponseDTO();
		if (student.getStudentInfo().getParentId() != null) {
			Seekerz seekerz = seekerzRepository.findById(student.getStudentInfo().getParentId()).get();
			if (seekerz != null) {
				response.setParentName(
						emailSender.name(seekerz.getFirstName(), seekerz.getMiddleName(), seekerz.getLastName()));
				response.setParentEmail(seekerz.getEmail());
				response.setParentPhoneNumber(seekerz.getMobileNumber());
				response.setTimeZone(seekerz.getTimeZone());
			}
		}
		return response;
	}

	private DayAndTimeDTO dayAndTimeResponse(Student student) {
		DayAndTimeDTO dayAndTimeDTO = new DayAndTimeDTO();
		dayAndTimeDTO.setDayAndTimeId(student.getDayAndTime().getId());
		dayAndTimeDTO.setDay(student.getDayAndTime().getDay());
		dayAndTimeDTO.setStartDate(student.getDayAndTime().getStartDate());
		dayAndTimeDTO.setEndDate(student.getDayAndTime().getEndDate());
		dayAndTimeDTO.setStartTime(student.getDayAndTime().getStartTime());
		dayAndTimeDTO.setEndTime(student.getDayAndTime().getEndTime());
		dayAndTimeDTO.setMeetingLink(student.getDayAndTime().getMeetingLink());
		return dayAndTimeDTO;
	}

	public Map<String, String> updateDayAndTime(ActiveClass activeClass) {
		Optional<ActiveClass> existingActiveClassOptional = activeClassRepository.findById(activeClass.getId());
		if (existingActiveClassOptional.isPresent()) {
			ActiveClass existingActiveClass = existingActiveClassOptional.get();
			existingActiveClass.setDay(activeClass.getDay());
			existingActiveClass.setDescription(activeClass.getDescription());
			existingActiveClass.setFeesInr(activeClass.getFeesInr());
			List<DayAndTime> updatedDayAndTimeList = new ArrayList<>();

			for (DayAndTime dayAndTimeObj : activeClass.getDayAndTime()) {
				if (dayAndTimeObj.getId() != null) {
					Optional<DayAndTime> existingDayAndTimeOptional = existingActiveClass.getDayAndTime().stream()
							.filter(i -> i.getId().equals(dayAndTimeObj.getId())).findFirst();
					existingDayAndTimeOptional.ifPresent(existingDayAndTime -> {
						existingDayAndTime.setDay(dayAndTimeObj.getDay());
						existingDayAndTime.setStartDate(dayAndTimeObj.getStartDate());
						existingDayAndTime.setEndDate(dayAndTimeObj.getEndDate());
						existingDayAndTime.setStartTime(dayAndTimeObj.getStartTime());
						existingDayAndTime.setEndTime(dayAndTimeObj.getEndTime());
						existingDayAndTime.setMeetingLink(dayAndTimeObj.getMeetingLink());
						updatedDayAndTimeList.add(existingDayAndTime); // Adding updated day and time
					});
				} else {
					DayAndTime newDayAndTime = new DayAndTime();
					newDayAndTime.setDay(dayAndTimeObj.getDay());
					newDayAndTime.setStartDate(dayAndTimeObj.getStartDate());
					newDayAndTime.setEndDate(dayAndTimeObj.getEndDate());
					newDayAndTime.setStartTime(dayAndTimeObj.getStartTime());
					newDayAndTime.setEndTime(dayAndTimeObj.getEndTime());
					newDayAndTime.setMeetingLink(dayAndTimeObj.getMeetingLink());
					dayAndTimeRepository.save(newDayAndTime);
					updatedDayAndTimeList.add(newDayAndTime);
				}
			}
			existingActiveClass.setDayAndTime(updatedDayAndTimeList);
			activeClassRepository.save(existingActiveClass);
			return Collections.singletonMap("Message", "Update successfully");
		} else {
			return Collections.singletonMap("Message", "The given id is not present");
		}
	}

}
