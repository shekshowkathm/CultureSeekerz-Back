package com.cultureSeekerz.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cultureSeekerz.entity.Teacher;

@Repository
public interface ITeacherRepository extends JpaRepository<Teacher, Long> {

	List<Teacher> findByApproveIsTrue();

	@Query(value = "SELECT * FROM teacher t WHERE :specialization = ANY(t.specialized_in) AND t.approve = true AND t.trail_class = true", nativeQuery = true)
	List<Teacher> findBySpecializedInContainingAndApproveIsTrueAndTrailClassIsTrue(
			@Param("specialization") String specialization);

	Teacher findByBasicInfoId(Long id);

	@Query(value = "SELECT * FROM teacher t WHERE :specialization = ANY(t.specialized_in) AND t.approve = true", nativeQuery = true)
	List<Teacher> findBySpecializedInContainingAndApproveIsTrue(@Param("specialization") String specialization);

	List<Teacher> findByTrailClassIsTrueAndApproveIsTrue();

	@Query(value = "SELECT * FROM teacher t WHERE :specialization = ANY(t.specialized_in) AND t.approve = false", nativeQuery = true)
	List<Teacher> findBySpecializedInContainingAndApproveIsFalse(@Param("specialization") String specialization);

	List<Teacher> findByUniqueId(String uniqueId);

}
