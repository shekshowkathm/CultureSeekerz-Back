package com.cultureSeekerz.responseDTO;

public class CalenderDTO {

	private String studentName;
	private String teacherName;
	private String activity;
	private String day;
	private String startTime;
	private String endTime;
	private String startDate;
	private String endDate;
	private String meetingLink;
	private Long studentId;
	private boolean rescheduleRequest;
	private boolean rescheduleStatus;

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getMeetingLink() {
		return meetingLink;
	}

	public void setMeetingLink(String meetingLink) {
		this.meetingLink = meetingLink;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public boolean isRescheduleRequest() {
		return rescheduleRequest;
	}

	public void setRescheduleRequest(boolean rescheduleRequest) {
		this.rescheduleRequest = rescheduleRequest;
	}

	public boolean isRescheduleStatus() {
		return rescheduleStatus;
	}

	public void setRescheduleStatus(boolean rescheduleStatus) {
		this.rescheduleStatus = rescheduleStatus;
	}
}
