package com.cultureSeekerz.utils;

import java.util.Random;

public class UniqueIdGenerator {

	private static final String PREFIX = "CS";

	public static String generateShortUniqueId(String role) {
		String rolePrefix = getRolePrefix(role);
		int randomNumber = generateRandomNumber();
		return PREFIX + rolePrefix + randomNumber;
	}

	private static String getRolePrefix(String role) {
		switch (role.toLowerCase()) {
		case "teacher":
			return "T";
		case "student":
			return "S";
		case "parent":
			return "P";
		case "admin":
			return "A";
		default:
			throw new IllegalArgumentException("Invalid role: " + role);
		}
	}

	private static int generateRandomNumber() {
		Random random = new Random();
		return random.nextInt(9000) + 1000; // Generates a random number between 1000 and 9999
	}

	public static String generateUniqueId(String activity) {
		int randomNumber = generateRandomNumber(); // Generate a 4-digit random number
		String activityPrefix = activity.substring(0, Math.min(activity.length(), 3)).toUpperCase();
		return "CS" + activityPrefix + randomNumber;
	}

}
