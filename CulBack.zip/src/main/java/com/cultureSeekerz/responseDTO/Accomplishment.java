package com.cultureSeekerz.responseDTO;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Accomplishment {

	private int age;
	private String activity;
	private List<String> accomplishments;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public List<String> getAccomplishments() {
		return accomplishments;
	}

	public void setAccomplishments(List<String> accomplishments) {
		this.accomplishments = accomplishments;
	}

	@Override
	public String toString() {
		return "Accomplishment [age=" + age + ", activity=" + activity + ", accomplishments=" + accomplishments + "]";
	}

}
