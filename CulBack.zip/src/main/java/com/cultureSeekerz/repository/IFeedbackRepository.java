package com.cultureSeekerz.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cultureSeekerz.entity.Feedback;

@Repository
public interface IFeedbackRepository extends JpaRepository<Feedback, Long> {

	List<Feedback> findByApproachedIsTrue();

	List<Feedback> findByApproachedIsFalse();
}
