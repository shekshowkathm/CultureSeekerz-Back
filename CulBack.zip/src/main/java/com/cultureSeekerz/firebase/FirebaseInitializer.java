package com.cultureSeekerz.firebase;

import java.io.IOException;
import java.io.InputStream;

import javax.annotation.PostConstruct;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

@Configuration
public class FirebaseInitializer {
	@PostConstruct
	public void initialize() throws IOException {
		if (FirebaseApp.getApps().isEmpty()) { // Check if Firebase has already been initialized
			ClassPathResource resource = new ClassPathResource(
					"push-notification-40b43-firebase-adminsdk-nv5a6-171980e4c8.json");
			try (InputStream serviceAccount = resource.getInputStream()) {
				FirebaseOptions options = FirebaseOptions.builder()
						.setCredentials(GoogleCredentials.fromStream(serviceAccount)).build();
				FirebaseApp.initializeApp(options);
			} catch (IOException e) {
				throw e;
			}
		}
	}
}
