package com.cultureSeekerz.utils;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class DynamicSelectors {

	public static String getImageUrl(String activity) {
		activity = activity.toLowerCase().trim();
		String imageUrl;

		switch (activity) {
		case "tamil":
			imageUrl = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/tamil%20subject.png";
			break;
		case "telugu":
			imageUrl = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Telugu.jpg";
			break;
		case "bible":
			imageUrl = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Bible.jpg";
			break;
		case "carnatic":
			imageUrl = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Carnatic.jpg";
			break;
		case "shloka":
			imageUrl = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Shloka.jpeg";
			break;
		case "chess":
			imageUrl = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Chess.jpg";
			break;
		case "programming":
			imageUrl = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Programming.jpg";
			break;
		case "maths":
			imageUrl = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/math-1547018.jpg";
			break;
		case "science":
			imageUrl = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Science.jpg";
			break;
		case "yoga":
			imageUrl = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/woman-sitting-yoga-pose-beach.jpg";
			break;
		case "mridangam":
			imageUrl = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/class%20image%20of%20mir.jpg";
			break;
		case "hindi":
			imageUrl = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/class%20image%20of%20hindi.jpg";
			break;
		default:
			throw new IllegalArgumentException("Invalid subject: " + activity);
		}
		return imageUrl;
	}

	public static String getFeesRange(List<String> classType) {

		if (classType.contains("High")) {
			return "9-12";
		} else if (classType.contains("Middle")) {
			return "9-11";
		} else {
			return "8-10";
		}
	}
}
