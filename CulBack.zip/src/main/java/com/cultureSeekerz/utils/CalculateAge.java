package com.cultureSeekerz.utils;

import java.time.LocalDate;
import java.time.Period;

import org.springframework.stereotype.Component;

import com.cultureSeekerz.entity.Seekerz;

@Component
public class CalculateAge {

	public static int calculateAge(Seekerz seekerz) {
		if (seekerz.getRole().equals("TEACHER") || seekerz.getRole().equals("PARENT")) {
			return -1;
		}
		LocalDate birthDate = LocalDate.parse(seekerz.getDob());
		Period age = Period.between(birthDate, LocalDate.now());
		return age.getYears();
	}
}
