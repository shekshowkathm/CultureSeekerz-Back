package com.cultureSeekerz.dto;

public class StudentDetailsDTO {
	private String name;
	private boolean rescheduleStatus;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isRescheduleStatus() {
		return rescheduleStatus;
	}

	public void setRescheduleStatus(boolean rescheduleStatus) {
		this.rescheduleStatus = rescheduleStatus;
	}

}
