package com.cultureSeekerz.firebase;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cultureSeekerz.entity.ActiveClass;
import com.cultureSeekerz.entity.PushNotification;
import com.cultureSeekerz.entity.Seekerz;
import com.cultureSeekerz.entity.Student;
import com.cultureSeekerz.entity.Teacher;
import com.cultureSeekerz.repository.IActiveClassRepository;
import com.cultureSeekerz.repository.IPushNotificationRepository;
import com.cultureSeekerz.repository.ISeekerzRepository;
import com.cultureSeekerz.repository.IStudentRepository;
import com.cultureSeekerz.responseDTO.Events;
import com.cultureSeekerz.utils.EmailSender;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;

@Service
public class PushNotificationService {

	@Autowired
	private IPushNotificationRepository pushNotificationRepository;

	@Autowired
	private IActiveClassRepository activeClassRepository;

	@Autowired
	private EmailSender emailSender;

	@Autowired
	private ISeekerzRepository seekerzRepository;

	@Autowired
	private IStudentRepository studentRepository;

	public void sendPushNotification(String notificationToken, String title, String body, Long id, String url) {
		if (notificationToken == null || notificationToken.isEmpty()) {
			return;
		}
		Notification notification = Notification.builder().setTitle(title).setBody(body).build();
		Message message = Message.builder().setToken(notificationToken).setNotification(notification)
				.putData("https://cultureseekerz.com/", url) // Include the URL in the message data
				.build();

		try {
			String response = FirebaseMessaging.getInstance().send(message);
			System.out.println("Successfully sent message: " + response);
			PushNotification pushNotification = pushNotificationRepository.findById(id).orElse(null);
			if (pushNotification != null) {
				pushNotification.setNotificationStatus(true);
				pushNotificationRepository.save(pushNotification);
			}
		} catch (Exception e) {
			e.printStackTrace(); // Log the full stack trace
		}
	}

	public String addPushNotificationToken(Long id, String notificationToken, String role) {
		List<PushNotification> pushNotifications = null;

		if ("TEACHER".equals(role)) {
			pushNotifications = pushNotificationRepository.findByTeacherId(id);
		} else if ("PARENT".equals(role)) {
			pushNotifications = pushNotificationRepository.findByParentId(id);
		} else {
			pushNotifications = pushNotificationRepository.findByStudentLoginId(id);
		}

		if (pushNotifications != null && !pushNotifications.isEmpty()) {
			for (PushNotification pushNotificationExisting : pushNotifications) {
				if ("STUDENT".equals(role)) {
					if (pushNotificationExisting.getNotificationToken() == null
							|| !pushNotificationExisting.getNotificationToken().equals(notificationToken)) {
						pushNotificationExisting.setStudentNotificationToken(notificationToken);
					}
				} else {
					pushNotificationExisting.setNotificationToken(notificationToken);
				}
				pushNotificationRepository.save(pushNotificationExisting);
			}
			return "token added";
		} else {
			PushNotification pushNotification = new PushNotification();
			if ("TEACHER".equals(role)) {
				pushNotification.setTeacherId(id);
				pushNotification.setNotificationToken(notificationToken);
			} else if ("PARENT".equals(role)) {
				pushNotification.setParentId(id);
				pushNotification.setNotificationToken(notificationToken);
			} else {
				pushNotification.setStudentLoginId(id);
				pushNotification.setStudentNotificationToken(notificationToken);
			}
			pushNotificationRepository.save(pushNotification);
			return "created new object";
		}
	}

	public List<PushNotification> getNotificationBefore30Min(Long id, String role) {
		List<PushNotification> result = new ArrayList<>();
		LocalDateTime now = LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES);

		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

		List<PushNotification> pushNotifications;
		if ("TEACHER".equals(role)) {
			pushNotifications = pushNotificationRepository.findByTeacherId(id);
		} else {
			pushNotifications = pushNotificationRepository.findByParentId(id);
		}

		for (PushNotification pushNotification : pushNotifications) {
			String date = pushNotification.getStudent().getStudentStartDate();
			String time = pushNotification.getStudent().getStudentStartTime();
			if (date != null && time != null) {
				LocalDateTime notificationDateTime = LocalDateTime.of(LocalDate.parse(date, dateFormatter),
						LocalTime.parse(time, timeFormatter));

				long minutesDifference = ChronoUnit.MINUTES.between(now, notificationDateTime);
				if (minutesDifference == 30) {
					result.add(pushNotification);
				}
			}
		}
		return result;
	}

	public List<Events> retrieveTodayClasses(Long id, String role) {
		List<Events> result = new ArrayList<>();

		LocalDate today = LocalDate.now();
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		List<PushNotification> pushNotifications;

		if ("TEACHER".equals(role)) {
			pushNotifications = pushNotificationRepository.findByTeacherId(id);
			DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
			for (PushNotification pushNotification : pushNotifications) {
				Student student = studentRepository.findById(pushNotification.getEnrollStudentId()).get();
				LocalDate studentStartDate = LocalDate.parse(student.getStudentStartDate(), dateFormatter);
				LocalTime studentStartTime = LocalTime.parse(student.getStudentStartTime(), timeFormatter);

				// Convert the parsed date and time to ZonedDateTime
				ZoneId studentZoneId = ZoneId.of("America/" + student.getStudentInfo().getTimeZone());
				ZonedDateTime startDateTime = ZonedDateTime.of(studentStartDate, studentStartTime, studentZoneId);

				// Convert the time to IST (Indian Standard Time)
				ZoneId targetZone = ZoneId.of("Asia/Kolkata");
				ZonedDateTime startDateTimeInIST = startDateTime.withZoneSameInstant(targetZone);

				// Format the date and time in IST
				String teacherStartDate = startDateTimeInIST.toLocalDate()
						.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
				ActiveClass existingActiveClass = activeClassRepository
						.findById(pushNotification.getStudent().getActiveClass().getId()).get();
				LocalDate notificationDate = LocalDate.parse(teacherStartDate, dateFormatter);
				if (notificationDate.equals(today)) {
					Events event = new Events();
					Seekerz seekerz = seekerzRepository.findById(existingActiveClass.getTeacher().getId()).get();
					event.setTeacherName(
							emailSender.name(seekerz.getFirstName(), seekerz.getMiddleName(), seekerz.getLastName()));
					event.setEventId(pushNotification.getId());
					event.setDate(teacherStartDate);
					event.setTime(pushNotification.getStudent().getDayAndTime().getStartTime());
					event.setActivity(existingActiveClass.getActivity());
					result.add(event);
				}
			}
		} else {
			pushNotifications = pushNotificationRepository.findByParentId(id);
			for (PushNotification pushNotification : pushNotifications) {
				String date = pushNotification.getStudent().getStudentStartDate();
				if (date != null) {
					LocalDate notificationDate = LocalDate.parse(date, dateFormatter);
					if (notificationDate.equals(today)) {
						Events event = new Events();
						ActiveClass existingActiveClass = activeClassRepository
								.findById(pushNotification.getStudent().getActiveClass().getId()).get();
						Seekerz seekerz = seekerzRepository.findById(existingActiveClass.getTeacher().getId()).get();
						event.setTeacherName(emailSender.name(seekerz.getFirstName(), seekerz.getMiddleName(),
								seekerz.getLastName()));
						event.setEventId(pushNotification.getId());
						event.setDate(date);
						event.setTime(pushNotification.getStudent().getDayAndTime().getStartTime());
						event.setActivity(existingActiveClass.getActivity());
						result.add(event);
					}
				}
			}

		}

		return result;
	}

	public List<Events> getParentEvents() {
		List<PushNotification> pushNotifications = pushNotificationRepository
				.findByNotificationStatusIsFalseAndStudentNotificationTokenIsNullAndParentIdIsNotNullAndNotificationTokenIsNotNull();
		List<Events> eventsList = new ArrayList<Events>();
		for (PushNotification pushNotification : pushNotifications) {
			if (pushNotification.getStudent() != null) {
				ActiveClass existingActiveClass = activeClassRepository
						.findById(pushNotification.getStudent().getActiveClass().getId()).get();
				Events event = new Events();
				event.setEventId(pushNotification.getId());
				event.setDate(pushNotification.getStudent().getStudentStartDate());
				event.setTime(pushNotification.getStudent().getStudentStartTime());
				event.setActivity(existingActiveClass.getActivity());
				event.setNotificationToken(pushNotification.getNotificationToken());
				Teacher teacher = existingActiveClass.getTeacher();
				Seekerz teacherSeekerz = teacher.getBasicInfo();
				event.setTeacherName(emailSender.name(teacherSeekerz.getFirstName(), teacherSeekerz.getMiddleName(),
						teacherSeekerz.getLastName()));
				event.setLoginId(pushNotification.getParentId());
				event.setNotificationStatus(pushNotification.isNotificationStatus());
				eventsList.add(event);
			}
		}
		return eventsList;
	}

	public List<Events> getStudentEvents() {
		List<PushNotification> pushNotifications = pushNotificationRepository
				.findByNotificationStatusIsFalseAndStudentNotificationTokenIsNotNull();
		List<Events> eventsList = new ArrayList<Events>();
		for (PushNotification pushNotification : pushNotifications) {
			if (pushNotification.getStudent() != null) {
				ActiveClass existingActiveClass = activeClassRepository
						.findById(pushNotification.getStudent().getActiveClass().getId()).get();
				Events event = new Events();
				event.setEventId(pushNotification.getId());
				event.setDate(pushNotification.getStudent().getStudentStartDate());
				event.setTime(pushNotification.getStudent().getStudentStartTime());
				event.setActivity(existingActiveClass.getActivity());
				event.setNotificationToken(pushNotification.getStudentNotificationToken());
				Teacher teacher = existingActiveClass.getTeacher();
				Seekerz teacherSeekerz = teacher.getBasicInfo();
				event.setTeacherName(emailSender.name(teacherSeekerz.getFirstName(), teacherSeekerz.getMiddleName(),
						teacherSeekerz.getLastName()));
				event.setNotificationStatus(pushNotification.isNotificationStatus());
				Seekerz seekerz = seekerzRepository.findById(pushNotification.getStudentLoginId()).get();
				event.setLoginId(seekerz.getParentId());
				eventsList.add(event);
			}
		}
		return eventsList;
	}

	public List<Events> retrieveStudentTodayClasses(Long parentId, Long studentId) {
		List<PushNotification> pushNotifications = pushNotificationRepository.findByParentIdAndStudentLoginId(parentId,
				studentId);

		List<Events> result = new ArrayList<>();

		LocalDate today = LocalDate.now();
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		for (PushNotification pushNotification : pushNotifications) {
			String date = pushNotification.getStudent().getStudentStartDate();
			if (date != null) {
				LocalDate notificationDate = LocalDate.parse(date, dateFormatter);
				if (notificationDate.equals(today)) {
					Events event = new Events();
					ActiveClass existingActiveClass = activeClassRepository
							.findById(pushNotification.getStudent().getActiveClass().getId()).get();
					Seekerz seekerz = seekerzRepository.findById(existingActiveClass.getTeacher().getId()).get();
					event.setTeacherName(
							emailSender.name(seekerz.getFirstName(), seekerz.getMiddleName(), seekerz.getLastName()));
					event.setEventId(pushNotification.getId());
					event.setDate(date);
					event.setTime(pushNotification.getStudent().getDayAndTime().getStartTime());
					event.setActivity(existingActiveClass.getActivity());
					result.add(event);
				}
			}
		}
		return result;
	}

	public List<Events> getTeacherEvents() {
		List<PushNotification> pushNotifications = pushNotificationRepository
				.findByNotificationStatusFalseAndTeacherIdIsNotNullAndNotificationTokenIsNotNullAndEnrollStudentIdIsNotNull();
		List<Events> eventsList = new ArrayList<Events>();
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); // Adjust the pattern as per your
																						// input date format
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm"); // Adjust the pattern as per your
																				// input time format

		for (PushNotification pushNotification : pushNotifications) {
			Student student = studentRepository.findById(pushNotification.getEnrollStudentId()).get();

			LocalDate studentStartDate = LocalDate.parse(student.getStudentStartDate(), dateFormatter);
			LocalTime studentStartTime = LocalTime.parse(student.getStudentStartTime(), timeFormatter);

			ZoneId studentZoneId = ZoneId.of("America/" + student.getStudentInfo().getTimeZone());
			ZonedDateTime startDateTime = ZonedDateTime.of(studentStartDate, studentStartTime, studentZoneId);

			ZoneId targetZone = ZoneId.of("Asia/Kolkata");
			ZonedDateTime startDateTimeInIST = startDateTime.withZoneSameInstant(targetZone);

			String teacherStartDate = startDateTimeInIST.toLocalDate()
					.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

			ActiveClass existingActiveClass = activeClassRepository.findById(student.getActiveClass().getId()).get();
			Events event = new Events();
			event.setEventId(pushNotification.getId());
			event.setDate(teacherStartDate);
			event.setTime(student.getDayAndTime().getStartTime());
			event.setNotificationToken(pushNotification.getNotificationToken());
			event.setNotificationStatus(pushNotification.isNotificationStatus());
			event.setActivity(existingActiveClass.getActivity());
			event.setLoginId(pushNotification.getTeacherId());
			eventsList.add(event);
		}
		return eventsList;
	}

}
