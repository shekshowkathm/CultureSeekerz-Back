package com.cultureSeekerz.responseDTO;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RemainderDTO {

	private String studentName;
	private String teacherName;
	private String activity;
	private Long studentId;
	private String parentEmail;
	private boolean remainderStatus;

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public String getParentEmail() {
		return parentEmail;
	}

	public void setParentEmail(String parentEmail) {
		this.parentEmail = parentEmail;
	}

	public boolean isRemainderStatus() {
		return remainderStatus;
	}

	public void setRemainderStatus(boolean remainderStatus) {
		this.remainderStatus = remainderStatus;
	}

}
