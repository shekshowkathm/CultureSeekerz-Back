package com.cultureSeekerz.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class TrialClass {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String teacherName;
	private String teacherEmail;
	private String activity;
	private String meetingLink;
	private String time;
	private String date;
	private String requestEmail;
	private String userName;
	private Long classId;
	private String feedback;
	private String timeZone;
	private String teacherUniqueId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getTeacherEmail() {
		return teacherEmail;
	}

	public void setTeacherEmail(String teacherEmail) {
		this.teacherEmail = teacherEmail;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getMeetingLink() {
		return meetingLink;
	}

	public void setMeetingLink(String meetingLink) {
		this.meetingLink = meetingLink;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getRequestEmail() {
		return requestEmail;
	}

	public void setRequestEmail(String requestEmail) {
		this.requestEmail = requestEmail;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Long getClassId() {
		return classId;
	}

	public void setClassId(Long classId) {
		this.classId = classId;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getTeacherUniqueId() {
		return teacherUniqueId;
	}

	public void setTeacherUniqueId(String teacherUniqueId) {
		this.teacherUniqueId = teacherUniqueId;
	}

	@Override
	public String toString() {
		return "TrialClass [id=" + id + ", teacherName=" + teacherName + ", teacherEmail=" + teacherEmail
				+ ", activity=" + activity + ", meetingLink=" + meetingLink + ", time=" + time + ", date=" + date
				+ ", requestEmail=" + requestEmail + ", userName=" + userName + ", classId=" + classId + ", feedback="
				+ feedback + ", timeZone=" + timeZone + ", teacherUniqueId=" + teacherUniqueId + "]";
	}

}
