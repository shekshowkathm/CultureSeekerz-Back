package com.cultureSeekerz.customException;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.ProblemDetail;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.security.SignatureException;

@RestControllerAdvice
public class CustomExceptionHandler {

	@ExceptionHandler(Exception.class)
	public ProblemDetail handleSecurityException(Exception ex) {
		ProblemDetail errorDetails = null;
		if (ex instanceof BadCredentialsException) {
			errorDetails = ProblemDetail.forStatusAndDetail(HttpStatusCode.valueOf(401), ex.getMessage());
			errorDetails.setProperty("access_denied_reason", "Authorization Failure");
		}
		if (ex instanceof AccessDeniedException) {
			errorDetails = ProblemDetail.forStatusAndDetail(HttpStatusCode.valueOf(403), ex.getMessage());
			errorDetails.setProperty("access_denied_reason", "not_authorized!");
		}

		if (ex instanceof SignatureException) {
			errorDetails = ProblemDetail.forStatusAndDetail(HttpStatusCode.valueOf(403), ex.getMessage());
			errorDetails.setProperty("access_denied_reason", "jwt signature not valid");
		}
		if (ex instanceof ExpiredJwtException) {
			errorDetails = ProblemDetail.forStatusAndDetail(HttpStatusCode.valueOf(403), ex.getMessage());
			errorDetails.setProperty("access_denied_reason", "jwt token expired");
		}
		return errorDetails;

	}

}
