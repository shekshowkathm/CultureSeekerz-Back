package com.cultureSeekerz.responseDTO;

import java.util.List;

import com.cultureSeekerz.dto.MyClassesForPayment;

public class PaymentHistroy {

	private List<MyClassesForPayment> paymentHistory;
	private float monthlyAmount;

	public List<MyClassesForPayment> getPaymentHistory() {
		return paymentHistory;
	}

	public void setPaymentHistory(List<MyClassesForPayment> paymentHistory) {
		this.paymentHistory = paymentHistory;
	}

	public float getMonthlyAmount() {
		return monthlyAmount;
	}

	public void setMonthlyAmount(float monthlyAmount) {
		this.monthlyAmount = monthlyAmount;
	}

	@Override
	public String toString() {
		return "PaymentHistroy [paymentHistory=" + paymentHistory + ", monthlyAmount=" + monthlyAmount + "]";
	}

}
