package com.cultureSeekerz.requestDTO;

import java.util.List;

public class Child360DTO {

	private List<String> accomplishments;
	private List<String> goals;
	private List<String> feedbacks;
	private List<String> topicsCovered;
	private Long studentId;

	public List<String> getAccomplishments() {
		return accomplishments;
	}

	public void setAccomplishments(List<String> accomplishments) {
		this.accomplishments = accomplishments;
	}

	public List<String> getGoals() {
		return goals;
	}

	public void setGoals(List<String> goals) {
		this.goals = goals;
	}

	public List<String> getFeedbacks() {
		return feedbacks;
	}

	public void setFeedbacks(List<String> feedbacks) {
		this.feedbacks = feedbacks;
	}

	public List<String> getTopicsCovered() {
		return topicsCovered;
	}

	public void setTopicsCovered(List<String> topicsCovered) {
		this.topicsCovered = topicsCovered;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	@Override
	public String toString() {
		return "Child360DTO [accomplishments=" + accomplishments + ", goals=" + goals + ", feedbacks=" + feedbacks
				+ ", topicsCovered=" + topicsCovered + ", studentId=" + studentId + "]";
	}
}
