package com.cultureSeekerz.responseDTO;

import java.util.List;

import com.cultureSeekerz.dto.StudentDetailsDTO;

public class TeacherCalender {

	private String activity;
	private String startDate;
	private String endDate;
	private String startTime;
	private String endTime;
	private String meetingLink;
	private String day;
	private int enrolledStudentCount;
	private List<StudentDetailsDTO> students;

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getMeetingLink() {
		return meetingLink;
	}

	public void setMeetingLink(String meetingLink) {
		this.meetingLink = meetingLink;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public int getEnrolledStudentCount() {
		return enrolledStudentCount;
	}

	public void setEnrolledStudentCount(int enrolledStudentCount) {
		this.enrolledStudentCount = enrolledStudentCount;
	}

	public List<StudentDetailsDTO> getStudents() {
		return students;
	}

	public void setStudents(List<StudentDetailsDTO> students) {
		this.students = students;
	}

	@Override
	public String toString() {
		return "TeacherCalender [activity=" + activity + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", startTime=" + startTime + ", endTime=" + endTime + ", meetingLink=" + meetingLink + ", day=" + day
				+ ", enrolledStudentCount=" + enrolledStudentCount + ", students=" + students + "]";
	}

}
