package com.cultureSeekerz.dto;

import com.cultureSeekerz.responseDTO.DayAndTimeDTO;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class StudentResponse {

	private Long studentId;
	private int age;
	private String studentName;
	private boolean attendStatus;
	private String selectedDate;
	private String uniqueId;
	private DayAndTimeDTO dayAndTime;

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public boolean isAttendStatus() {
		return attendStatus;
	}

	public void setAttendStatus(boolean attendStatus) {
		this.attendStatus = attendStatus;
	}

	public String getSelectedDate() {
		return selectedDate;
	}

	public void setSelectedDate(String selectedDate) {
		this.selectedDate = selectedDate;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public DayAndTimeDTO getDayAndTime() {
		return dayAndTime;
	}

	public void setDayAndTime(DayAndTimeDTO dayAndTime) {
		this.dayAndTime = dayAndTime;
	}

	@Override
	public String toString() {
		return "StudentResponse [studentId=" + studentId + ", age=" + age + ", studentName=" + studentName
				+ ", attendStatus=" + attendStatus + ", selectedDate=" + selectedDate + ", uniqueId=" + uniqueId
				+ ", dayAndTime=" + dayAndTime + "]";
	}

}
