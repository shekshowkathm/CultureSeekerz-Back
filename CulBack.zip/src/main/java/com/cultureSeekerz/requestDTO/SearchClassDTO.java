package com.cultureSeekerz.requestDTO;

public class SearchClassDTO {

	private String classType;
	private String ageGroup;
	private String activity;
	private String day;
	private String timeZone;

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public String getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	@Override
	public String toString() {
		return "SearchClassDTO [classType=" + classType + ", ageGroup=" + ageGroup + ", activity=" + activity + ", day="
				+ day + ", timeZone=" + timeZone + "]";
	}

}
