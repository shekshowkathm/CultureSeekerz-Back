package com.cultureSeekerz.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cultureSeekerz.Enum.Role;
import com.cultureSeekerz.dto.StudentResponse;
import com.cultureSeekerz.entity.DayAndTime;
import com.cultureSeekerz.entity.Student;
import com.cultureSeekerz.entity.TrialClass;
import com.cultureSeekerz.responseDTO.DayAndTimeDTO;

@Component
public class TimeZoneConvertor {

	@Autowired
	private EmailSender emailSender;

	public DayAndTimeDTO timeZoneConvertor(DayAndTime dayAndTime, Role value, String timeZone) {
		if (timeZone.equals("Ist")) {
			DayAndTimeDTO dayAndTimeDTO = new DayAndTimeDTO();
			if (dayAndTime != null) {
				dayAndTimeDTO.setDayAndTimeId(dayAndTime.getId());
				dayAndTimeDTO.setDay(dayAndTime.getDay());
				dayAndTimeDTO.setStartDate(dayAndTime.getStartDate());
				dayAndTimeDTO.setEndDate(dayAndTime.getEndDate());
				dayAndTimeDTO.setStartTime(dayAndTime.getStartTime());
				dayAndTimeDTO.setEndTime(dayAndTime.getEndTime());
				dayAndTimeDTO.setMeetingLink(dayAndTime.getMeetingLink());
				if (value == Role.TEACHER) {
					List<StudentResponse> enrolledStudentResponses = new ArrayList<>();
					for (Student existingStudent : dayAndTime.getEnrollStudents()) {
						enrolledStudentResponses.add(studentResponsePayment(existingStudent));
					}
					dayAndTimeDTO.setEnrollStudents(enrolledStudentResponses);
				}
			}
			return dayAndTimeDTO;
		}

		else {

			ZonedDateTime startDateTime = parseDateTime(dayAndTime.getStartDate(), dayAndTime.getStartTime());
			ZonedDateTime endDateTime = parseDateTime(dayAndTime.getStartDate(), dayAndTime.getEndTime());

			ZoneId zone = ZoneId.of("America/" + timeZone);
			ZonedDateTime startDateTimeInZone = startDateTime.withZoneSameInstant(zone);
			ZonedDateTime endDateTimeInZone = endDateTime.withZoneSameInstant(zone);
			DayOfWeek dayOfWeek = startDateTimeInZone.getDayOfWeek();
			DayAndTimeDTO dayAndTimeDTO = new DayAndTimeDTO();
			dayAndTimeDTO.setDayAndTimeId(dayAndTime.getId());
			dayAndTimeDTO.setDay(generateDayFormat(dayOfWeek));
			dayAndTimeDTO
					.setStartDate(startDateTimeInZone.toLocalDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
			dayAndTimeDTO.setEndDate(endDateTimeInZone.toLocalDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
			dayAndTimeDTO.setStartTime(startDateTimeInZone.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")));
			dayAndTimeDTO.setEndTime(endDateTimeInZone.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")));
			dayAndTimeDTO.setMeetingLink(dayAndTime.getMeetingLink());
			return dayAndTimeDTO;
		}

	}

	private static ZonedDateTime parseDateTime(String date, String time) {
		LocalDateTime localDateTime = LocalDateTime.of(LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd")),
				LocalTime.parse(time));
		return ZonedDateTime.of(localDateTime, ZoneId.of("Asia/Kolkata"));
	}

	public StudentResponse studentResponsePayment(Student student) {
		StudentResponse studentResponse = new StudentResponse();
		studentResponse.setStudentName(emailSender.name(student.getStudentInfo().getFirstName(),
				student.getStudentInfo().getMiddleName(), student.getStudentInfo().getLastName()));
		studentResponse.setAge(student.getStudentInfo().getAge());
		studentResponse.setStudentId(student.getId());
		studentResponse.setSelectedDate(student.getStudentStartDate());
		studentResponse.setAttendStatus(student.isAttendStatus());
		return studentResponse;
	}

	public String generateDayFormat(DayOfWeek day) {
		String lowerCaseDay = day.toString().toLowerCase();
		switch (lowerCaseDay) {
		case "monday":
			return "Mon";
		case "tuesday":
			return "Tue";
		case "wednesday":
			return "Wed";
		case "thursday":
			return "Thu";
		case "friday":
			return "Fri";
		case "saturday":
			return "Sat";
		case "sunday":
			return "Sun";
		default:
			throw new IllegalArgumentException("Unexpected value: " + lowerCaseDay);
		}
	}

	public TrialClass timeZoneConvertorForTrialClass(TrialClass trialClass) {
		ZonedDateTime startDateTime = parseDateTime(trialClass.getDate(), trialClass.getTime());

		ZoneId zone = ZoneId.of("America/" + trialClass.getTimeZone());
		ZonedDateTime startDateTimeInZone = startDateTime.withZoneSameInstant(zone);
		trialClass.setDate(startDateTimeInZone.toLocalDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		trialClass.setTime(startDateTimeInZone.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")));
		trialClass.setTimeZone(timezoneFormat(trialClass.getTimeZone()));
		return trialClass;
	}

	private String timezoneFormat(String timezone) {
		switch (timezone) {
		case "Chicago":
			return "CST";
		case "New_York":
			return "EST";
		case "Denver":
			return "MST";
		case "Los_Angeles":
			return "PST";
		default:
			throw new IllegalArgumentException("Unexpected value: " + timezone);
		}
	}

	public Calendar createCalendarFromStrings(String date, String time) throws ParseException {
		String dateTimeString = date + " " + time;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date dateTime = sdf.parse(dateTimeString);

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dateTime);
		return calendar;
	}

	private static Calendar convertZonedDateTimeToCalendar(ZonedDateTime zdt) {
		Instant instant = zdt.toInstant();
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(instant.toEpochMilli());
		return calendar;
	}

	public Calendar parseDateTimeForNotification(String date, String time, String timezone) {
		if (timezone.equals("Ist")) {
			LocalDateTime localDateTime = LocalDateTime
					.of(LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd")), LocalTime.parse(time));
			ZonedDateTime zonedDateTime = ZonedDateTime.of(localDateTime, ZoneId.of("Asia/Kolkata"));
			return convertZonedDateTimeToCalendar(zonedDateTime);
		} else {
			LocalDateTime localDateTime = LocalDateTime
					.of(LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd")), LocalTime.parse(time));
			ZonedDateTime zonedDateTime = ZonedDateTime.of(localDateTime, ZoneId.of("America/" + timezone));
			return convertZonedDateTimeToCalendar(zonedDateTime);
		}
	}
}