package com.cultureSeekerz.service;

import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cultureSeekerz.Enum.Role;
import com.cultureSeekerz.dto.ClassDTO;
import com.cultureSeekerz.dto.GoalsAndFeedbackDTO;
import com.cultureSeekerz.dto.LearningProgressByActivityDTO;
import com.cultureSeekerz.dto.LearningProgressByAgeDTO;
import com.cultureSeekerz.dto.MyClassesForPayment;
import com.cultureSeekerz.dto.ParentResponseDTO;
import com.cultureSeekerz.dto.ScheduleClassResponseDTO;
import com.cultureSeekerz.dto.StudentResponse;
import com.cultureSeekerz.dto.TeacherInfoResponse;
import com.cultureSeekerz.entity.ActiveClass;
import com.cultureSeekerz.entity.DayAndTime;
import com.cultureSeekerz.entity.PushNotification;
import com.cultureSeekerz.entity.Seekerz;
import com.cultureSeekerz.entity.Student;
import com.cultureSeekerz.repository.IActiveClassRepository;
import com.cultureSeekerz.repository.IDayAndTimeRepository;
import com.cultureSeekerz.repository.IPushNotificationRepository;
import com.cultureSeekerz.repository.ISeekerzRepository;
import com.cultureSeekerz.repository.IStudentRepository;
import com.cultureSeekerz.requestDTO.Child360DTO;
import com.cultureSeekerz.requestDTO.RescheduledDataDTO;
import com.cultureSeekerz.responseDTO.Accomplishment;
import com.cultureSeekerz.responseDTO.CalenderDTO;
import com.cultureSeekerz.responseDTO.Child360ParentDTO;
import com.cultureSeekerz.responseDTO.DayAndTimeDTO;
import com.cultureSeekerz.responseDTO.FeesProvider;
import com.cultureSeekerz.responseDTO.PaymentHistoryAdmin;
import com.cultureSeekerz.responseDTO.PaymentHistroy;
import com.cultureSeekerz.responseDTO.RemainderDTO;
import com.cultureSeekerz.responseDTO.RescheduleDTO;
import com.cultureSeekerz.utils.EmailSender;
import com.cultureSeekerz.utils.TimeZoneConvertor;

@Service
public class StudentService {

	@Autowired
	private IStudentRepository studentRepository;

	@Autowired
	private EmailSender emailSender;

	@Autowired
	private ISeekerzRepository seekerzRepository;

	@Autowired
	private IActiveClassRepository activeClassRepository;

	@Autowired
	private IDayAndTimeRepository dayAndTimeRepository;

	@Autowired
	private TimeZoneConvertor timeZoneConvertor;

	@Autowired
	private EmailService emailService;

	@Autowired
	private IPushNotificationRepository pushNotificationRepository;

	public String createStudent(Student student) {
		Optional<Seekerz> existingSeekerzOpt = seekerzRepository.findById(student.getStudentInfo().getId());
		Optional<ActiveClass> existingActiveClassOpt = activeClassRepository.findById(student.getActiveClass().getId());

		if (existingSeekerzOpt.isEmpty() || existingActiveClassOpt.isEmpty()) {
			return "Seekerz or ActiveClass not found";
		}

		Seekerz existingSeekerz = existingSeekerzOpt.get();
		ActiveClass existingActiveClass = existingActiveClassOpt.get();
		Student existingStudent = studentRepository
				.findByStudentInfoAndActiveClassAndStudentStartDateAndStudentStartTime(existingSeekerz,
						existingActiveClass, student.getStudentStartDate(), student.getStudentStartTime());

		if (existingStudent != null) {
			return "Already Enrolled";
		}

		student.setUniqueId(existingSeekerzOpt.get().getUniqueId());
		Student savedStudent = studentRepository.save(student);

		existingSeekerz.setPersonalId(savedStudent.getId());
		seekerzRepository.save(existingSeekerz);

		Optional<DayAndTime> dayAndTimeOpt = dayAndTimeRepository.findById(student.getDayAndTime().getId());
		if (dayAndTimeOpt.isEmpty()) {
			return "DayAndTime not found";
		}

		DayAndTime dayAndTime = dayAndTimeOpt.get();
		List<Student> existingStudentList = dayAndTime.getEnrollStudents();
		if (existingStudentList == null) {
			existingStudentList = new ArrayList<>();
		}
		existingStudentList.add(savedStudent);
		dayAndTime.setEnrollStudents(existingStudentList);
		dayAndTimeRepository.save(dayAndTime);

		if (savedStudent.isEnable()) {

			List<PushNotification> pushNotifications = pushNotificationRepository
					.findByParentId(existingSeekerz.getParentId());
			Optional<PushNotification> pushNotificationOptional = pushNotifications.stream()
					.filter(notification -> notification.getNotificationToken() != null).findFirst();

			List<PushNotification> studentPushNotifications = pushNotificationRepository
					.findByStudentLoginId(existingSeekerz.getId());
			Optional<PushNotification> pushNotificationWithStudentToken = studentPushNotifications.stream()
					.filter(notification -> notification.getStudentNotificationToken() != null).findFirst();

			List<PushNotification> teacherpushNotifications = pushNotificationRepository
					.findByTeacherId(existingActiveClass.getTeacher().getBasicInfo().getId());
			Optional<PushNotification> pushNotificationWithTeacherToken = teacherpushNotifications.stream()
					.filter(notification -> notification.getNotificationToken() != null).findFirst();

			PushNotification pushNotification = new PushNotification();
			pushNotification.setStudent(savedStudent);
			pushNotification.setParentId(existingSeekerz.getParentId());
			pushNotification.setStudentLoginId(existingSeekerz.getId());

			if (pushNotificationOptional.isPresent()) {
				pushNotification.setNotificationToken(pushNotificationOptional.get().getNotificationToken());
			}

			if (pushNotificationWithStudentToken.isPresent()) {
				pushNotification.setStudentNotificationToken(
						pushNotificationWithStudentToken.get().getStudentNotificationToken());
			}

//		if (pushNotificationWithTeacherToken.isPresent()) {
//			pushNotification.setNotificationToken(pushNotificationWithTeacherToken.get().getNotificationToken());
//		}

			pushNotificationRepository.save(pushNotification);

			PushNotification teacherPushNotification = new PushNotification();
			teacherPushNotification.setEnrollStudentId(savedStudent.getId());
			teacherPushNotification.setTeacherId(existingActiveClass.getTeacher().getBasicInfo().getId());
			if (pushNotificationWithTeacherToken.isPresent()) {
				teacherPushNotification
						.setNotificationToken(pushNotificationWithTeacherToken.get().getNotificationToken());
			}

			pushNotificationRepository.save(teacherPushNotification);
		}
		return "Enrolled";
	}

	/**
	 * login id (seekerz)
	 * 
	 * @param id
	 * @return
	 */
	public List<ScheduleClassResponseDTO> getStudentById(Long id, Role value, String timeZone) {
		List<Student> student = studentRepository.findByStudentInfoId(id);
		List<ScheduleClassResponseDTO> response = new ArrayList<ScheduleClassResponseDTO>();
		for (Student studentObj : student) {
			response.add(scheduleClassResponse(studentObj, value, timeZone));
		}
		return response;
	}

	/**
	 * Login id (child id) parent page manage class
	 * 
	 * @param id
	 * @return
	 */
	public List<ScheduleClassResponseDTO> parentManageClass(Long id, Role value, String timeZone) {
		List<Student> students = studentRepository.findByStudentInfoIdAndEnable(id);
		List<ScheduleClassResponseDTO> response = new ArrayList<ScheduleClassResponseDTO>();
		for (Student student : students) {
			response.add(scheduleClassResponse(student, value, timeZone));
		}
		return response;
	}

	public String parentApproveChildClass(Long id, String classType, String ageGroup) {
		Student student = studentRepository.findById(id).get();
		student.setClassType(classType);
		student.setAgeGroup(ageGroup);
		student.setEnable(true);
		Student savedStudent = studentRepository.save(student);
		Seekerz existingSeekerz = seekerzRepository.findById(student.getStudentInfo().getId()).get();
		ActiveClass existingActiveClass = activeClassRepository.findById(student.getActiveClass().getId()).get();
		List<PushNotification> pushNotifications = pushNotificationRepository
				.findByParentId(existingSeekerz.getParentId());
		Optional<PushNotification> pushNotificationOptional = pushNotifications.stream()
				.filter(notification -> notification.getNotificationToken() != null).findFirst();

		List<PushNotification> studentPushNotifications = pushNotificationRepository
				.findByStudentLoginId(existingSeekerz.getId());
		Optional<PushNotification> pushNotificationWithStudentToken = studentPushNotifications.stream()
				.filter(notification -> notification.getStudentNotificationToken() != null).findFirst();

		List<PushNotification> teacherpushNotifications = pushNotificationRepository
				.findByTeacherId(existingActiveClass.getTeacher().getBasicInfo().getId());
		Optional<PushNotification> pushNotificationWithTeacherToken = teacherpushNotifications.stream()
				.filter(notification -> notification.getNotificationToken() != null).findFirst();

		PushNotification pushNotification = new PushNotification();
		pushNotification.setStudent(savedStudent);
		pushNotification.setParentId(existingSeekerz.getParentId());
		pushNotification.setStudentLoginId(existingSeekerz.getId());

		if (pushNotificationOptional.isPresent()) {
			pushNotification.setNotificationToken(pushNotificationOptional.get().getNotificationToken());
		}

		if (pushNotificationWithStudentToken.isPresent()) {
			pushNotification
					.setStudentNotificationToken(pushNotificationWithStudentToken.get().getStudentNotificationToken());
		}

		pushNotificationRepository.save(pushNotification);

		PushNotification teacherPushNotification = new PushNotification();
		teacherPushNotification.setEnrollStudentId(savedStudent.getId());
		teacherPushNotification.setTeacherId(existingActiveClass.getTeacher().getBasicInfo().getId());
		if (pushNotificationWithTeacherToken.isPresent()) {
			teacherPushNotification.setNotificationToken(pushNotificationWithTeacherToken.get().getNotificationToken());
		}

		pushNotificationRepository.save(teacherPushNotification);

		return "true";
	}

	public Map<String, String> removeEnrolledClass(Long id) {
		Student student = studentRepository.findById(id).get();
		if (student != null) {
			DayAndTime dayAndTime = student.getDayAndTime();
			if (dayAndTime != null) {
				List<Student> enrolledStudents = new ArrayList<>(dayAndTime.getEnrollStudents());
				boolean removed = enrolledStudents.removeIf(s -> Objects.equals(s.getId(), id));
				if (removed) {
					dayAndTime.setEnrollStudents(enrolledStudents);
					dayAndTimeRepository.save(dayAndTime);
					pushNotificationRepository.deleteByStudentId(id);
					studentRepository.deleteById(id);
					return Collections.singletonMap("Message", "Removed");
				} else {
					return Collections.singletonMap("Message", "Given id is not mapped in dayAndTimeEnrollStudent");
				}
			} else {
				return Collections.singletonMap("Message", "No day and time associated with this student");
			}
		} else {
			return Collections.singletonMap("Message", "No student found with the given id");
		}
	}

	// basicInfo id
	public List<CalenderDTO> studentCalender(Long id, String timeZone) {
		return calendarResponse(id, timeZone);
	}

	public List<CalenderDTO> parentCalender(Long id, String timeZone) {
		Seekerz parent = seekerzRepository.findById(id).orElse(null);
		List<CalenderDTO> calendarDTOs = new ArrayList<>();
		if (parent != null && !parent.getChild().isEmpty()) {
			for (Seekerz child : parent.getChild()) {
				calendarDTOs.addAll(calendarResponse(child.getId(), timeZone));
			}
		}
		return calendarDTOs;
	}

	public List<ScheduleClassResponseDTO> getRemainderClass(Long id, Role value, String timeZone) {
		Student student = studentRepository.findById(id).get();
		List<ScheduleClassResponseDTO> response = new ArrayList<ScheduleClassResponseDTO>();
		response.add(scheduleClassResponse(student, value, timeZone));
		return response;
	}

	public Map<String, String> sendPaymentRemainderMail(RemainderDTO remainder) {
		Student student = studentRepository.findById(remainder.getStudentId()).get();
		student.setRemainderStatus(true);
		studentRepository.save(student);
		emailService.sendRemainderMail(remainder);
		return Collections.singletonMap("Message", "Mail send");
	}

	public List<Child360ParentDTO> getGoalsAndFeedbacks(Long id) {
		List<Student> students = studentRepository.findByStudentInfoIdAndEnableTrueAndAttendStatusTrue(id);
		Map<String, Child360ParentDTO> goalsAndFeedbacksDTOMap = new HashMap<>();

		for (Student student : students) {
			if (student.getFeedback() != null && student.getGoals() != null) {
				int age = calculateAgeAtEnrollment(student.getStudentInfo().getDob(), student.getStudentStartDate());
				String key = age + "_";

				Child360ParentDTO goalsAndFeedbacks = goalsAndFeedbacksDTOMap.getOrDefault(key,
						new Child360ParentDTO());

				goalsAndFeedbacks.setAge(age);
				goalsAndFeedbacks.setStudentLoginId(id);

				if (goalsAndFeedbacks.getGoalsAndFeedbacks() == null) {
					goalsAndFeedbacks.setGoalsAndFeedbacks(new ArrayList<>());
				}
				GoalsAndFeedbackDTO goalsAndFeedback = new GoalsAndFeedbackDTO();
				goalsAndFeedback.setActivity(student.getActiveClass().getActivity());
				goalsAndFeedback.setGoals(student.getGoals());
				goalsAndFeedback.setFeedbacks(student.getFeedback());
				goalsAndFeedback.setTeacherName(
						emailSender.name(student.getActiveClass().getTeacher().getBasicInfo().getFirstName(),
								student.getActiveClass().getTeacher().getBasicInfo().getMiddleName(),
								student.getActiveClass().getTeacher().getBasicInfo().getLastName()));
				goalsAndFeedback.setProfile(student.getActiveClass().getTeacher().getProfile());
				goalsAndFeedbacks.getGoalsAndFeedbacks().add(goalsAndFeedback);
				goalsAndFeedbacksDTOMap.put(key, goalsAndFeedbacks);
			}
		}

		return new ArrayList<>(goalsAndFeedbacksDTOMap.values());
	}

	public List<Child360ParentDTO> getGoalsAndFeedbacksByAge(Long id, String activity, int givenAge) {
		List<Student> students = studentRepository.findByStudentInfoIdAndEnableTrueAndAttendStatusTrue(id);
		Map<String, Child360ParentDTO> goalsAndFeedbacksDTOMap = new HashMap<>();

		for (Student student : students) {
			int age = calculateAgeAtEnrollment(student.getStudentInfo().getDob(), student.getStudentStartDate());
			String key = age + "_";

			Child360ParentDTO goalsAndFeedbacks = goalsAndFeedbacksDTOMap.getOrDefault(key, new Child360ParentDTO());
			if (age == givenAge && student.getActiveClass().getActivity().equals(activity) && student.getGoals() != null
					&& student.getFeedback() != null) {
				goalsAndFeedbacks.setAge(age);
				goalsAndFeedbacks.setStudentLoginId(id);

				if (goalsAndFeedbacks.getGoalsAndFeedbacks() == null) {
					goalsAndFeedbacks.setGoalsAndFeedbacks(new ArrayList<>());
				}

				GoalsAndFeedbackDTO goalsAndFeedback = new GoalsAndFeedbackDTO();
				goalsAndFeedback.setActivity(student.getActiveClass().getActivity());
				goalsAndFeedback.setGoals(student.getGoals());
				goalsAndFeedback.setFeedbacks(student.getFeedback());
				goalsAndFeedback.setTeacherName(
						emailSender.name(student.getActiveClass().getTeacher().getBasicInfo().getFirstName(),
								student.getActiveClass().getTeacher().getBasicInfo().getMiddleName(),
								student.getActiveClass().getTeacher().getBasicInfo().getLastName()));
				goalsAndFeedback.setProfile(student.getActiveClass().getTeacher().getProfile());

				goalsAndFeedbacks.getGoalsAndFeedbacks().add(goalsAndFeedback);
				goalsAndFeedbacksDTOMap.put(key, goalsAndFeedbacks);
			}
		}

		return new ArrayList<>(goalsAndFeedbacksDTOMap.values());
	}

	public List<Child360ParentDTO> getLearningProgressByAge(Long id) {
		List<Student> students = studentRepository.findByStudentInfoId(id);
		Map<String, Child360ParentDTO> child360ParentDTOMap = new HashMap<>();

		for (Student student : students) {
			int age = calculateAgeAtEnrollment(student.getStudentInfo().getDob(), student.getStudentStartDate());
			String key = age + "_";

			Child360ParentDTO child360ParentDTO = child360ParentDTOMap.getOrDefault(key, new Child360ParentDTO());
			child360ParentDTO.setAge(age);
			child360ParentDTO.setStudentLoginId(id);

			if (child360ParentDTO.getLearningProgressByAge() == null) {
				child360ParentDTO.setLearningProgressByAge(new ArrayList<>());
			}

			Map<String, LearningProgressByAgeDTO> learningProgressByAgeMap = new HashMap<>();
			for (LearningProgressByAgeDTO learningProgressByAgeDTO : child360ParentDTO.getLearningProgressByAge()) {
				learningProgressByAgeMap.put(learningProgressByAgeDTO.getActivity(), learningProgressByAgeDTO);
			}

			String activityKey = student.getActiveClass().getActivity();

			LearningProgressByAgeDTO learningProgressByAge = learningProgressByAgeMap.getOrDefault(activityKey,
					new LearningProgressByAgeDTO());
			learningProgressByAge.setActivity(activityKey);

			if (learningProgressByAge.getClasses() == null) {
				learningProgressByAge.setClasses(new ArrayList<>());
			}

			ActiveClass activeClass = activeClassRepository.findById(student.getActiveClass().getId()).orElse(null);
			Seekerz seekerz = seekerzRepository.findById(activeClass.getTeacher().getBasicInfo().getId()).orElse(null);

			ClassDTO classDto = new ClassDTO();
			classDto.setDate(student.getStudentStartDate());
			classDto.setStudentId(student.getId());
			classDto.setProfile(activeClass.getTeacher().getProfile());
			classDto.setTeacherName(
					emailSender.name(seekerz.getFirstName(), seekerz.getMiddleName(), seekerz.getLastName()));

			learningProgressByAge.getClasses().add(classDto);

			learningProgressByAgeMap.put(activityKey, learningProgressByAge);
			child360ParentDTO.getLearningProgressByAge().clear();
			child360ParentDTO.getLearningProgressByAge().addAll(learningProgressByAgeMap.values());

			child360ParentDTOMap.put(key, child360ParentDTO);
		}
		return new ArrayList<>(child360ParentDTOMap.values());
	}

	public Map<String, String> updateChild360(Child360DTO child360DTO) {
		Student student = studentRepository.findById(child360DTO.getStudentId()).get();
		student.setAccomplishments(child360DTO.getAccomplishments());
		student.setGoals(child360DTO.getGoals());
		student.setFeedback(child360DTO.getFeedbacks());
		student.setTopicsCovered(child360DTO.getTopicsCovered());
		studentRepository.save(student);
		return Collections.singletonMap("Message", "update learning");
	}

	public List<String> retrieveActivity(Long id) {
		List<Student> students = studentRepository.findByStudentInfoId(id);
		if (students == null) {
			return List.of();
		}
		Set<String> uniqueActivities = new LinkedHashSet<>();

		for (Student student : students) {
			if (student != null && student.getActiveClass() != null) {
				String activity = student.getActiveClass().getActivity();
				if (activity != null) {
					uniqueActivities.add(activity);
				}
			}
		}
		return uniqueActivities.stream().collect(Collectors.toList());
	}

	public List<Child360ParentDTO> getLearningProgressByActivity(Long id, String activity) {
		List<Student> students = studentRepository.findByStudentInfoIdAndEnableTrueAndAttendStatusTrue(id);
		List<Child360ParentDTO> child360ParentDTOMap = new ArrayList<>();

		for (Student student : students) {
			if (student.getActiveClass().getActivity().equals(activity) && student.getTopicsCovered() != null) {
				int age = calculateAgeAtEnrollment(student.getStudentInfo().getDob(), student.getStudentStartDate());
				String month = getMonthInWords(student.getStudentStartDate());
				List<String> topics = student.getTopicsCovered();

				Child360ParentDTO child360ParentDTO = child360ParentDTOMap.stream().filter(c -> c.getAge() == age)
						.findFirst().orElse(null);

				if (child360ParentDTO == null) {
					child360ParentDTO = new Child360ParentDTO();
					child360ParentDTO.setAge(age);
					child360ParentDTO.setLearningProgressByActivity(new ArrayList<>());
					child360ParentDTOMap.add(child360ParentDTO);
				}

				LearningProgressByActivityDTO learningProgressByActivityDTO = child360ParentDTO
						.getLearningProgressByActivity().stream().filter(l -> l.getMonth().equalsIgnoreCase(month))
						.findFirst().orElse(null);

				if (learningProgressByActivityDTO == null) {
					learningProgressByActivityDTO = new LearningProgressByActivityDTO();
					learningProgressByActivityDTO.setMonth(month);
					learningProgressByActivityDTO.setTopics(student.getTopicsCovered());
					child360ParentDTO.getLearningProgressByActivity().add(learningProgressByActivityDTO);
				} else if (topics != null) {
					learningProgressByActivityDTO.getTopics().addAll(topics);
				} else {
					learningProgressByActivityDTO.setTopics(null);
				}
			}
		}
		return child360ParentDTOMap;
	}

	public List<Accomplishment> getaccomplishmentByActivity(Long id, String activity) {
		List<Student> students = studentRepository.findByStudentInfoIdAndEnableTrueAndAttendStatusTrue(id);
		List<Accomplishment> accomplishmentMap = new ArrayList<>();
		for (Student student : students) {
			if (student.getActiveClass().getActivity().equals(activity) && student.getAccomplishments() != null) {
				int age = calculateAgeAtEnrollment(student.getStudentInfo().getDob(), student.getStudentStartDate());
				List<String> accomplishments = student.getAccomplishments();
				Accomplishment childProgress = accomplishmentMap.stream().filter(c -> c.getAge() == age).findFirst()
						.orElse(null);
				if (childProgress == null) {
					Accomplishment accomplishment = new Accomplishment();
					accomplishment.setAge(age);
					accomplishment.setAccomplishments(student.getAccomplishments());
					accomplishmentMap.add(accomplishment);
				} else {
					childProgress.getAccomplishments().addAll(accomplishments);
				}
			}
		}
		return accomplishmentMap;
	}

	public Accomplishment getAccomplishmentByAge(Long id, String activity, int givenAge) {
		List<Student> students = studentRepository.findByStudentInfoIdAndEnableTrueAndAttendStatusTrue(id);
		List<String> accomplishments = new ArrayList<>();
		for (Student student : students) {
			if (student.getActiveClass().getActivity().equals(activity) && student.getAccomplishments() != null) {
				int age = calculateAgeAtEnrollment(student.getStudentInfo().getDob(), student.getStudentStartDate());
				if (age == givenAge && student.getActiveClass().getActivity() == activity) {
					accomplishments.addAll(student.getAccomplishments());
				}
			}
		}
		Accomplishment accomplishment = new Accomplishment();
		accomplishment.setAge(givenAge);
		accomplishment.setActivity(activity);
		accomplishment.setAccomplishments(accomplishments);
		return accomplishment;
	}

	public List<Accomplishment> getAccomplishment(Long id) {
		List<Student> students = studentRepository.findByStudentInfoIdAndEnableTrueAndAttendStatusTrue(id);
		Map<String, Accomplishment> activityToMaxAgeAccomplishment = new HashMap<>();

		for (Student student : students) {
			int age = calculateAgeAtEnrollment(student.getStudentInfo().getDob(), student.getStudentStartDate());

			String activity = student.getActiveClass().getActivity();
			List<String> accomplishmentsList = student.getAccomplishments();

			if (!activityToMaxAgeAccomplishment.containsKey(activity)
					|| activityToMaxAgeAccomplishment.get(activity).getAge() < age) {
				Accomplishment accomplishment = new Accomplishment();
				accomplishment.setActivity(activity);
				accomplishment.setAccomplishments(accomplishmentsList);
				accomplishment.setAge(age);
				activityToMaxAgeAccomplishment.put(activity, accomplishment);
			}
		}
		List<Accomplishment> response = new ArrayList<>(activityToMaxAgeAccomplishment.values());
		return response;
	}

	public Map<String, String> updateClassForReschedule(Long id) {
		Student student = studentRepository.findById(id).get();
		student.setRescheduleRequest(true);
		studentRepository.save(student);
		return Collections.singletonMap("Message", "updated");
	}

	public List<RescheduleDTO> retrieveRescheduleClasses(String activity, boolean rescheduleStatus) {
		List<RescheduleDTO> result = new ArrayList<RescheduleDTO>();
		List<Student> students = null;
		if (rescheduleStatus) {
			students = studentRepository.findByActiveClassAndRescheduleRequestIsTrueAndRescheduleStatusIsTrue(activity);
		} else {
			students = studentRepository
					.findByActiveClassAndRescheduleRequestIsTrueAndRescheduleStatusIsFalse(activity);
		}
		for (Student student : students) {
			RescheduleDTO reschedule = new RescheduleDTO();
			reschedule.setActivity(student.getActiveClass().getActivity());
			reschedule.setTeacher(teacherInfo(student.getActiveClass()));
			List<DayAndTimeDTO> dayAndTimeDTO = new ArrayList<>();
			for (DayAndTime dayAndTime : student.getActiveClass().getDayAndTime()) {
				dayAndTimeDTO.add(convertingDayAndTime(dayAndTime, student.getStudentInfo().getTimeZone()));
			}
			reschedule.setStudent(studentResponsePayment(student,
					convertingDayAndTime(student.getDayAndTime(), student.getStudentInfo().getTimeZone())));
			reschedule.setParent(parentResponse(student));
			reschedule.setDayAndTimeDTO(dayAndTimeDTO);
			result.add(reschedule);
		}
		return result;
	}

	public List<RescheduleDTO> getStudentByUniqueId(String uniqueId) {
		List<Student> students = studentRepository.findByUniqueId(uniqueId);
		List<RescheduleDTO> result = new ArrayList<RescheduleDTO>();
		for (Student student : students) {
			RescheduleDTO reschedule = new RescheduleDTO();
			reschedule.setActivity(student.getActiveClass().getActivity());
			reschedule.setTeacher(teacherInfo(student.getActiveClass()));
			List<DayAndTimeDTO> dayAndTimeDTO = new ArrayList<>();
			for (DayAndTime dayAndTime : student.getActiveClass().getDayAndTime()) {
				dayAndTimeDTO.add(convertingDayAndTime(dayAndTime, student.getStudentInfo().getTimeZone()));
			}
			reschedule.setStudent(studentResponsePayment(student,
					convertingDayAndTime(student.getDayAndTime(), student.getStudentInfo().getTimeZone())));
			reschedule.setParent(parentResponse(student));
			reschedule.setDayAndTimeDTO(dayAndTimeDTO);
			result.add(reschedule);
		}
		return result;
	}

	public Map<String, String> updateRescheduleClass(RescheduledDataDTO newRescheduleData) {
		Optional<Student> studentOpt = studentRepository.findById(newRescheduleData.getStudentId());
		Optional<DayAndTime> dayAndTimeOpt = dayAndTimeRepository.findById(newRescheduleData.getDayAndTimeId());

		if (studentOpt.isPresent() && dayAndTimeOpt.isPresent()) {
			Student student = studentOpt.get();
			DayAndTime newDayAndTime = dayAndTimeOpt.get();

			DayAndTime oldDayAndTime = student.getDayAndTime();
			if (oldDayAndTime != null && !oldDayAndTime.equals(newDayAndTime)) {
				oldDayAndTime.getEnrollStudents().remove(student);
				dayAndTimeRepository.save(oldDayAndTime);
			}

			if (!newDayAndTime.getEnrollStudents().contains(student)) {
				newDayAndTime.getEnrollStudents().add(student);
			}

			student.setStudentStartDate(newRescheduleData.getNewDate());
			student.setStudentEndDate(newRescheduleData.getNewDate());
			student.setStudentStartTime(newRescheduleData.getNewStartTime());
			student.setStudentEndTime(newRescheduleData.getNewEndTime());
			student.setDayAndTime(newDayAndTime);
			student.setRescheduleStatus(true);
			studentRepository.save(student);
			dayAndTimeRepository.save(newDayAndTime);

			return Collections.singletonMap("Message", "Rescheduled");
		} else {
			return Collections.singletonMap("Message", "Student or DayAndTime not found");
		}
	}

	public List<FeesProvider> getEnrolledStudents(String activity, boolean feeStatus) {
		List<FeesProvider> result = new ArrayList<>();
		List<Student> students;

		if (feeStatus) {
			students = studentRepository.findByActiveClassAndEnableIsTrueAndClassFeesGreaterThanOne(activity);
		} else {
			students = studentRepository.findByActiveClassAndEnableIsTrueAndClassFeesIsZero(activity);
		}

		for (Student student : students) {
			FeesProvider feesProvider = new FeesProvider();
			feesProvider.setStudentId(student.getId());
			feesProvider.setClassFees(student.getClassFees());
			feesProvider.setAgeGroup(student.getAgeGroup());
			feesProvider.setClassType(student.getClassType());
			feesProvider.setStudentSelectedTime(student.getStudentStartTime());
			feesProvider.setStudentSelectedDate(student.getStudentStartDate());

			ActiveClass activeClass = activeClassRepository.findById(student.getActiveClass().getId()).orElse(null);
			if (activeClass != null) {
				feesProvider.setFeesRange(activeClass.getFeesRange());
				feesProvider.setChildName(emailSender.name(student.getStudentInfo().getFirstName(),
						student.getStudentInfo().getMiddleName(), student.getStudentInfo().getLastName()));
				feesProvider.setTeacherName(emailSender.name(activeClass.getTeacher().getBasicInfo().getFirstName(),
						activeClass.getTeacher().getBasicInfo().getMiddleName(),
						activeClass.getTeacher().getBasicInfo().getLastName()));
			}

			result.add(feesProvider);
		}
		return result;
	}

	public Map<String, String> updateFeesForStudents(Long id, Double fee) {
		Student student = studentRepository.findById(id).get();
		student.setClassFees(fee);
		studentRepository.save(student);
		return Collections.singletonMap("Message", "Updated");
	}

	public PaymentHistroy retrieveEnrolledOnClasses(Long studentLoginId, int month) {
		List<Student> students = studentRepository
				.findByStudentInfoIdAndEnableIsTrueAndAttendStatusIsTrue(studentLoginId);
		PaymentHistroy result = new PaymentHistroy();
		List<MyClassesForPayment> myClassesForPayment = new ArrayList<MyClassesForPayment>();
		for (Student student : students) {
			LocalDate localDate = LocalDate.parse(student.getStudentStartDate());
			int monthValue = localDate.getMonthValue();
			if (month == monthValue) {
				MyClassesForPayment paymentHistroy = new MyClassesForPayment();
				ActiveClass activeClass = activeClassRepository.findById(student.getActiveClass().getId()).get();
				paymentHistroy.setActiveClassId(activeClass.getId());
				paymentHistroy.setActivity(activeClass.getActivity());
				paymentHistroy.setEnrolledOn(student.getStudentStartDate());
				paymentHistroy.setFees(student.getClassFees());
				paymentHistroy.setTeacherName(emailSender.name(activeClass.getTeacher().getBasicInfo().getFirstName(),
						activeClass.getTeacher().getBasicInfo().getMiddleName(),
						activeClass.getTeacher().getBasicInfo().getLastName()));
				paymentHistroy.setStudentId(student.getId());
				myClassesForPayment.add(paymentHistroy);
			}
		}
		float totalAmount = 0;
		for (MyClassesForPayment myClassesForPaymentObj : myClassesForPayment) {
			totalAmount += myClassesForPaymentObj.getFees();
		}

		result.setPaymentHistory(myClassesForPayment);
		result.setMonthlyAmount(totalAmount);
		return result;
	}

	public List<PaymentHistoryAdmin> retrievePaymentHistory(int month, boolean paidStatus) {
		List<PaymentHistoryAdmin> result = new ArrayList<>();
		List<Student> students = null;
		if (paidStatus) {
			students = studentRepository.findByAttendStatusIsTrueAndEnableIsTrueAndPaymentStatusIsTrue();
		} else {
			students = studentRepository.findByAttendStatusIsTrueAndEnableIsTrueAndPaymentStatusIsFalse();
		}

		Map<String, PaymentHistoryAdmin> paymentHistoryMap = new HashMap<>();

		for (Student student : students) {
			LocalDate localDate = LocalDate.parse(student.getStudentStartDate());
			int monthValue = localDate.getMonthValue();
			if (month == monthValue) {
				String studentUniqueId = student.getUniqueId();
				PaymentHistoryAdmin paymentHistory = paymentHistoryMap.get(studentUniqueId);

				if (paymentHistory == null) {
					paymentHistory = new PaymentHistoryAdmin();
					Seekerz studentSeekerz = seekerzRepository.findById(student.getStudentInfo().getId()).get();
					Seekerz parentSeekerz = seekerzRepository.findById(studentSeekerz.getParentId()).get();
					paymentHistory.setStudentName(emailSender.name(studentSeekerz.getFirstName(),
							studentSeekerz.getMiddleName(), studentSeekerz.getLastName()));
					paymentHistory.setStudentUniqueId(studentUniqueId);
					paymentHistory.setParentName(emailSender.name(parentSeekerz.getFirstName(),
							parentSeekerz.getMiddleName(), parentSeekerz.getLastName()));
					paymentHistory.setParentEmail(parentSeekerz.getEmail());
					paymentHistory.setPhonenumber(parentSeekerz.getMobileNumber());
					paymentHistory.setMonthName(localDate.getMonth().name());

					paymentHistoryMap.put(studentUniqueId, paymentHistory);
					result.add(paymentHistory);
				}

				List<MyClassesForPayment> myClassesForPaymentList = paymentHistory.getPaymentHistory();
				if (myClassesForPaymentList == null) {
					myClassesForPaymentList = new ArrayList<>();
					paymentHistory.setPaymentHistory(myClassesForPaymentList);
				}

				float totalAmount = 0;

				ActiveClass activeClass = activeClassRepository.findById(student.getActiveClass().getId()).get();
				MyClassesForPayment myClassesForPayment = new MyClassesForPayment();
				myClassesForPayment.setActiveClassId(activeClass.getId());
				myClassesForPayment.setActivity(activeClass.getActivity());
				myClassesForPayment.setEnrolledOn(student.getStudentStartDate());
				myClassesForPayment.setFees(student.getClassFees());
				myClassesForPayment
						.setTeacherName(emailSender.name(activeClass.getTeacher().getBasicInfo().getFirstName(),
								activeClass.getTeacher().getBasicInfo().getMiddleName(),
								activeClass.getTeacher().getBasicInfo().getLastName()));
				myClassesForPayment.setPaid(student.isPaymentStatus());
				myClassesForPayment.setStudentId(student.getId());

				myClassesForPaymentList.add(myClassesForPayment);
				totalAmount += myClassesForPayment.getFees();

				// Update the monthly amount for the student
				paymentHistory.setMonthlyAmount(String.valueOf(totalAmount));
			}
		}
		return result;
	}

	public Map<String, String> updateTheClassAfterJoining(Long studentId) {
		Student student = studentRepository.findById(studentId).get();
		student.setAttendStatus(true);
		studentRepository.save(student);
		return Collections.singletonMap("Message", "Joined");
	}

	public Map<String, String> updatePayment(List<Long> studentIds) {
		for (Long studentId : studentIds) {
			Student student = studentRepository.findById(studentId).get();
			student.setPaymentStatus(true);
			studentRepository.save(student);
		}
		return Collections.singletonMap("Message", "paymentUpdated");
	}

	public List<PaymentHistoryAdmin> retrieveHistroyPaymentByUniqueId(String uniqueId, int month) {
		List<PaymentHistoryAdmin> result = new ArrayList<>();
		List<Student> students = studentRepository.findByUniqueIdAndAttendStatusIsTrueAndEnableIsTrue(uniqueId);
		Map<String, PaymentHistoryAdmin> paymentHistoryMap = new HashMap<>();

		for (Student student : students) {
			LocalDate localDate = LocalDate.parse(student.getStudentStartDate());
			int monthValue = localDate.getMonthValue();
			if (month == monthValue) {
				String studentUniqueId = student.getUniqueId();
				PaymentHistoryAdmin paymentHistory = paymentHistoryMap.get(studentUniqueId);

				if (paymentHistory == null) {
					paymentHistory = new PaymentHistoryAdmin();
					Seekerz studentSeekerz = seekerzRepository.findById(student.getStudentInfo().getId()).get();
					Seekerz parentSeekerz = seekerzRepository.findById(studentSeekerz.getParentId()).get();
					paymentHistory.setStudentName(emailSender.name(studentSeekerz.getFirstName(),
							studentSeekerz.getMiddleName(), studentSeekerz.getLastName()));
					paymentHistory.setStudentUniqueId(studentUniqueId);
					paymentHistory.setParentName(emailSender.name(parentSeekerz.getFirstName(),
							parentSeekerz.getMiddleName(), parentSeekerz.getLastName()));
					paymentHistory.setParentEmail(parentSeekerz.getEmail());
					paymentHistory.setPhonenumber(parentSeekerz.getMobileNumber());
					paymentHistory.setMonthName(localDate.getMonth().name());

					paymentHistoryMap.put(studentUniqueId, paymentHistory);
					result.add(paymentHistory);
				}

				List<MyClassesForPayment> myClassesForPaymentList = paymentHistory.getPaymentHistory();
				if (myClassesForPaymentList == null) {
					myClassesForPaymentList = new ArrayList<>();
					paymentHistory.setPaymentHistory(myClassesForPaymentList);
				}

				float totalAmount = 0;

				ActiveClass activeClass = activeClassRepository.findById(student.getActiveClass().getId()).get();
				MyClassesForPayment myClassesForPayment = new MyClassesForPayment();
				myClassesForPayment.setActiveClassId(activeClass.getId());
				myClassesForPayment.setActivity(activeClass.getActivity());
				myClassesForPayment.setEnrolledOn(student.getStudentStartDate());
				myClassesForPayment.setFees(student.getClassFees());
				myClassesForPayment
						.setTeacherName(emailSender.name(activeClass.getTeacher().getBasicInfo().getFirstName(),
								activeClass.getTeacher().getBasicInfo().getMiddleName(),
								activeClass.getTeacher().getBasicInfo().getLastName()));
				myClassesForPayment.setPaid(student.isPaymentStatus());
				myClassesForPayment.setStudentId(student.getId());

				myClassesForPaymentList.add(myClassesForPayment);
				totalAmount += myClassesForPayment.getFees();

				// Update the monthly amount for the student
				paymentHistory.setMonthlyAmount(String.valueOf(totalAmount));
			}
		}
		return result;
	}

	/* Private methods */

	private DayAndTimeDTO convertingDayAndTime(DayAndTime dayAndTime, String timezone) {
		DayAndTimeDTO converted = timeZoneConvertor.timeZoneConvertor(dayAndTime, null, timezone);
		return converted;
	}

	private ScheduleClassResponseDTO scheduleClassResponse(Student student, Role value, String timeZone) {
		ScheduleClassResponseDTO scheduleClassResponse = new ScheduleClassResponseDTO();
		scheduleClassResponse.setClassId(student.getActiveClass().getId());
		scheduleClassResponse.setFeesRange(student.getActiveClass().getFeesRange());
		scheduleClassResponse.setDescription(student.getActiveClass().getDescription());
		scheduleClassResponse.setDemoVideo(student.getActiveClass().getDemoVideo());
		scheduleClassResponse.setActivity(student.getActiveClass().getActivity());
		scheduleClassResponse.setDay(student.getActiveClass().getDay());
		scheduleClassResponse.setClassType(student.getActiveClass().getClassType());
		scheduleClassResponse.setAgeGroup(student.getActiveClass().getAgeGroup());
		scheduleClassResponse.setApprove(student.getActiveClass().isApprove());
		scheduleClassResponse.setTeacher(teacherInfo(student.getActiveClass()));
		scheduleClassResponse.setClassImage(student.getActiveClass().getClassImage());
		scheduleClassResponse.setClassUniqueId(student.getActiveClass().getClassUniqueId());
		if (value == Role.STUDENT || value == Role.PARENT) {
			if (student.getDayAndTime() != null) {
				List<String> convertedDay = new ArrayList<>();
				DayAndTimeDTO converted = timeZoneConvertor.timeZoneConvertor(student.getDayAndTime(), value, timeZone);
				String day = converted.getDay();
				convertedDay.add(day);
				scheduleClassResponse.setDay(convertedDay);
				scheduleClassResponse.setStudentResponse(studentResponsePayment(student, converted));
			}
		}
		return scheduleClassResponse;
	}

	private TeacherInfoResponse teacherInfo(ActiveClass activeClass) {
		TeacherInfoResponse teacherInfoResponse = new TeacherInfoResponse();
		teacherInfoResponse.setTeacherName(emailSender.name(activeClass.getTeacher().getBasicInfo().getFirstName(),
				activeClass.getTeacher().getBasicInfo().getMiddleName(),
				activeClass.getTeacher().getBasicInfo().getLastName()));
		teacherInfoResponse.setTeacherProfile(activeClass.getTeacher().getProfile());
		teacherInfoResponse.setTeacherId(activeClass.getTeacher().getId());
		teacherInfoResponse.setTeacherEmail(activeClass.getTeacher().getBasicInfo().getEmail());
		teacherInfoResponse.setTeacherPhoneNumber(activeClass.getTeacher().getBasicInfo().getMobileNumber());
		return teacherInfoResponse;
	}

	private StudentResponse studentResponsePayment(Student student, DayAndTimeDTO dayAndTimeDTO) {
		StudentResponse studentResponse = new StudentResponse();
		studentResponse.setStudentName(emailSender.name(student.getStudentInfo().getFirstName(),
				student.getStudentInfo().getMiddleName(), student.getStudentInfo().getLastName()));
		studentResponse.setAge(student.getStudentInfo().getAge());
		studentResponse.setDayAndTime(dayAndTimeDTO);
		studentResponse.setSelectedDate(student.getStudentStartDate());
		studentResponse.setAttendStatus(student.isAttendStatus());
		studentResponse.setStudentId(student.getId());
		studentResponse.setUniqueId(student.getUniqueId());
		return studentResponse;
	}

	private ParentResponseDTO parentResponse(Student student) {
		ParentResponseDTO response = new ParentResponseDTO();
		if (student.getStudentInfo().getParentId() != null) {
			Seekerz seekerz = seekerzRepository.findById(student.getStudentInfo().getParentId()).get();
			if (seekerz != null) {
				response.setParentName(
						emailSender.name(seekerz.getFirstName(), seekerz.getMiddleName(), seekerz.getLastName()));
				response.setParentEmail(seekerz.getEmail());
				response.setParentPhoneNumber(seekerz.getMobileNumber());
				response.setTimeZone(seekerz.getTimeZone());
			}
		}
		return response;
	}

	private List<CalenderDTO> calendarResponse(Long id, String timeZone) {
		List<CalenderDTO> studentCalendarResponse = new ArrayList<CalenderDTO>();
		List<Student> student = studentRepository.findByStudentInfoId(id);
		if (student != null) {
			for (Student StudentObj : student) {
				CalenderDTO calenderResponse = new CalenderDTO();
				calenderResponse.setStudentName(emailSender.name(StudentObj.getStudentInfo().getFirstName(),
						StudentObj.getStudentInfo().getMiddleName(), StudentObj.getStudentInfo().getLastName()));
				calenderResponse.setTeacherName(
						emailSender.name(StudentObj.getActiveClass().getTeacher().getBasicInfo().getFirstName(),
								StudentObj.getActiveClass().getTeacher().getBasicInfo().getMiddleName(),
								StudentObj.getActiveClass().getTeacher().getBasicInfo().getLastName()));
				calenderResponse.setActivity(StudentObj.getActiveClass().getActivity());
				DayAndTimeDTO convertedDayAndTime = timeZoneConvertor.timeZoneConvertor(StudentObj.getDayAndTime(),
						Role.USER, timeZone);
				calenderResponse.setDay(convertedDayAndTime.getDay());
				calenderResponse.setStartDate(dateFormatter(StudentObj.getStudentStartDate()));
				calenderResponse.setEndDate(dateFormatter(StudentObj.getStudentEndDate()));
				calenderResponse.setStartTime(convertedDayAndTime.getStartTime());
				calenderResponse.setEndTime(convertedDayAndTime.getEndTime());
				calenderResponse.setMeetingLink(StudentObj.getDayAndTime().getMeetingLink());
				calenderResponse.setStudentId(StudentObj.getId());
				calenderResponse.setRescheduleRequest(StudentObj.isRescheduleRequest());
				calenderResponse.setRescheduleStatus(StudentObj.isRescheduleStatus());
				studentCalendarResponse.add(calenderResponse);
			}
		}
		return studentCalendarResponse;
	}

	public long calculateDaysBetweenGivenDateAndToday(String givenDate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate parsedDate = LocalDate.parse(givenDate, formatter);
		LocalDate today = LocalDate.now();
		return ChronoUnit.DAYS.between(today, parsedDate);
	}

	public static String dateFormatter(String givenDate) {
		DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate parsedDate = LocalDate.parse(givenDate, inputFormatter);
		String formattedDate = parsedDate.format(outputFormatter);
		return formattedDate;
	}

	public static int calculateAgeAtEnrollment(String dob, String enrolledOn) {
		LocalDate birthDate = LocalDate.parse(dob);
		LocalDate enrolledDate = LocalDate.parse(enrolledOn);
		Period ageAtEnrollment = Period.between(birthDate, enrolledDate);
		return ageAtEnrollment.getYears();
	}

	public static String getMonthInWords(String dateString) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
		try {
			Date date = sdf.parse(dateString);
			SimpleDateFormat monthFormat = new SimpleDateFormat("MM", Locale.ENGLISH);
			int monthNumber = Integer.parseInt(monthFormat.format(date));

			DateFormatSymbols dfs = new DateFormatSymbols(Locale.ENGLISH);
			String monthName = dfs.getMonths()[monthNumber - 1];

			return monthName;
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

}
