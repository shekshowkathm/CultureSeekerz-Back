package com.cultureSeekerz.Enum;

public enum Role {
	STUDENT, PARENT, TEACHER, ADMIN,USER
}
