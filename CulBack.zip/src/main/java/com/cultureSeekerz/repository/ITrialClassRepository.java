package com.cultureSeekerz.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cultureSeekerz.entity.TrialClass;

@Repository
public interface ITrialClassRepository extends JpaRepository<TrialClass, Long> {

	List<TrialClass> findByRequestEmail(String requestEmail);

	List<TrialClass> findByTeacherEmail(String teacherEmail);

	List<TrialClass> findByUserName(String userName);
	
	@Query("SELECT t FROM TrialClass t WHERE t.activity = :activity AND (t.meetingLink IS NULL OR t.date IS NULL)")
	List<TrialClass> findByActivityAndMeetingLinkIsNullOrDateIsNull(@Param("activity") String activity);

	
	@Query("SELECT t FROM TrialClass t WHERE t.activity = :activity AND t.meetingLink IS NOT NULL AND t.date IS NOT NULL")
	List<TrialClass> findByActivityAndMeetingLinkIsNotNullAndDateIsNotNull(@Param("activity") String activity);


	List<TrialClass> findByTeacherUniqueId(String teacherUniqueId);

}
