package com.cultureSeekerz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cultureSeekerz.entity.TrialClass;
import com.cultureSeekerz.repository.ITrialClassRepository;
import com.cultureSeekerz.utils.TimeZoneConvertor;

@Service
public class TrialClassService {
	@Autowired
	private ITrialClassRepository trialClassRepository;

	@Autowired
	private EmailService emailService;

	@Autowired
	private TimeZoneConvertor timeZoneConvertor;

	public TrialClass createTrailClass(TrialClass trialClass) {
		return trialClassRepository.save(trialClass);
	}

	public List<TrialClass> getTrailClass(String activity, boolean scheduledStatus) {
		List<TrialClass> trialClasses = null;
		if (scheduledStatus) {
			trialClasses = trialClassRepository.findByActivityAndMeetingLinkIsNotNullAndDateIsNotNull(activity);
		} else {
			trialClasses = trialClassRepository.findByActivityAndMeetingLinkIsNullOrDateIsNull(activity);
		}
		return trialClasses;
	}

	public String updateAndSendEmail(TrialClass trialClass) {
		TrialClass trialClassObj = trialClassRepository.findById(trialClass.getId()).get();
		trialClassObj.setTime(trialClass.getTime());
		trialClassObj.setDate(trialClass.getDate());
		trialClassObj.setMeetingLink(trialClass.getMeetingLink());
		trialClassObj.setTimeZone(trialClass.getTimeZone());
		TrialClass emailSending = trialClassRepository.save(trialClassObj);
		if (emailSending.getRequestEmail() != null) {
			TrialClass convertedTimeZone = timeZoneConvertor.timeZoneConvertorForTrialClass(trialClass);
			emailService.sendEmail(emailSending.getRequestEmail(), convertedTimeZone);
		}

		TrialClass teacherTimezone = emailSending;
		teacherTimezone.setTimeZone("IST");
		emailService.sendEmail(emailSending.getTeacherEmail(), teacherTimezone);
		return "Mail Sending";
	}

	public List<TrialClass> getTrialClassesByRequesterEmail(String requestEmailOrUsername) {
		List<TrialClass> trialClassForEmail = trialClassRepository.findByRequestEmail(requestEmailOrUsername);

		if (!trialClassForEmail.isEmpty()) {
			return trialClassForEmail;
		} else {
			List<TrialClass> trialClassForUserName = trialClassRepository.findByUserName(requestEmailOrUsername);
			return trialClassForUserName;
		}
	}

	public List<TrialClass> getTrialClassesByteacherEmail(String teacherEmail) {
		return trialClassRepository.findByTeacherEmail(teacherEmail);
	}

	public TrialClass updateFeedBack(TrialClass trialClass) {
		TrialClass existingTrialClass = trialClassRepository.findById(trialClass.getId()).get();
		existingTrialClass.setFeedback(trialClass.getFeedback());
		return trialClassRepository.save(existingTrialClass);
	}

	public List<TrialClass> getTeacherByUniqueId(String uniqueId) {
		List<TrialClass> trialClass = trialClassRepository.findByTeacherUniqueId(uniqueId);
		return trialClass;
	}

}
