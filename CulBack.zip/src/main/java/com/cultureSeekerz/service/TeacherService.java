package com.cultureSeekerz.service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cultureSeekerz.Enum.Role;
import com.cultureSeekerz.dto.ActiveClassResponse;
import com.cultureSeekerz.dto.AdminTeacherDTO;
import com.cultureSeekerz.dto.ScheduleClassResponseDTO;
import com.cultureSeekerz.dto.StudentDetailsDTO;
import com.cultureSeekerz.dto.TeacherResponseDTO;
import com.cultureSeekerz.dto.TeacherScheduleDTO;
import com.cultureSeekerz.entity.ActiveClass;
import com.cultureSeekerz.entity.Seekerz;
import com.cultureSeekerz.entity.Student;
import com.cultureSeekerz.entity.Teacher;
import com.cultureSeekerz.repository.ISeekerzRepository;
import com.cultureSeekerz.repository.IStudentRepository;
import com.cultureSeekerz.repository.ITeacherRepository;
import com.cultureSeekerz.responseDTO.TeacherCalender;
import com.cultureSeekerz.utils.EmailSender;
import com.cultureSeekerz.utils.TimeZoneConvertor;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.PersistenceContext;

@Service
public class TeacherService {

	@Autowired
	public ITeacherRepository teacherRepository;

	@Autowired
	public EmailSender emailSender;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	public ActiveClassService activeClassService;

	@Autowired
	public ISeekerzRepository seekerzRepository;

	@Autowired
	public IStudentRepository studentRepository;

	@Autowired
	public TimeZoneConvertor timezoneconvertor;

	public Teacher createTeacher(Teacher teacher) {
		Seekerz basicInfo = seekerzRepository.findById(teacher.getBasicInfo().getId()).get();
		if (basicInfo != null && basicInfo.getId() != null) {
			Seekerz managedBasicInfo = entityManager.find(Seekerz.class, basicInfo.getId());
			if (managedBasicInfo != null) {
				teacher.setBasicInfo(managedBasicInfo);
			} else {
				throw new EntityNotFoundException("Seekerz with ID " + basicInfo.getId() + " not found.");
			}
		}

		if (teacher.getProfile() == null && teacher.getBasicInfo().getGender().equals("Male")) {
			teacher.setProfile("https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/male teacher (1).png");
		} else {
			teacher.setProfile("https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Female teacher (1).png");
		}
		teacher.setUniqueId(basicInfo.getUniqueId());
		Teacher teacherObj = teacherRepository.save(teacher);
		Seekerz seekerz = seekerzRepository.findById(teacher.getBasicInfo().getId()).get();
		seekerz.setPersonalId(teacherObj.getId());
		seekerzRepository.save(seekerz);
		return teacherObj;
	}

	public Map<String, String> updateTeacherDetails(Teacher teacher) {
		Teacher teacherObj = teacherRepository.findById(teacher.getId()).get();
		if (teacherObj != null) {
			teacherObj.setAbout(teacher.getAbout());
			teacherObj.setProfile(teacher.getProfile());
			teacherObj.setTrailClass(teacher.isTrailClass());
			teacherObj.setCertificate(teacher.getCertificate());
			teacherRepository.save(teacherObj);
			return Collections.singletonMap("Message", "Update successfully");
		} else {
			return Collections.singletonMap("Message", "ID not found");
		}
	}

	public List<AdminTeacherDTO> retrieveTeachers(Role value, String specialization, boolean approveStatus) {
		List<Teacher> teachers = null;
		if (approveStatus) {
			teachers = teacherRepository.findBySpecializedInContainingAndApproveIsTrue(specialization);
		} else {
			teachers = teacherRepository.findBySpecializedInContainingAndApproveIsFalse(specialization);
		}
		List<AdminTeacherDTO> response = new ArrayList<AdminTeacherDTO>();
		for (Teacher teacher : teachers) {
			response.add(adminTeacherResponse(teacher));
		}
		return response;
	}

	public List<AdminTeacherDTO> getTeacherByUniqueId(String uniqueId) {
		List<Teacher> teachers = teacherRepository.findByUniqueId(uniqueId);
		List<AdminTeacherDTO> response = new ArrayList<AdminTeacherDTO>();
		for (Teacher teacher : teachers) {
			response.add(adminTeacherResponse(teacher));
		}
		return response;
	}

	public TeacherScheduleDTO getTeacher(Long id, Role value) {
		Teacher teacher = teacherRepository.findById(id).get();
		TeacherScheduleDTO response = new TeacherScheduleDTO();
		response.setTeacher(adminTeacherResponse(teacher));
		return response;
	}

	public TeacherResponseDTO teacherResponse(Teacher teacher) {
		TeacherResponseDTO teacherResponse = new TeacherResponseDTO();
		Seekerz seekerz = teacher.getBasicInfo();
		teacherResponse
				.setName(emailSender.name(seekerz.getFirstName(), seekerz.getMiddleName(), seekerz.getLastName()));
		teacherResponse.setEmail(seekerz.getEmail());
		teacherResponse.setGender(seekerz.getGender());
		teacherResponse.setUG(teacher.getuG());
		teacherResponse.setPG(teacher.getpG());
		teacherResponse.setB_Ed(teacher.isB_Ed());
		teacherResponse.setM_Ed(teacher.isM_Ed());
		teacherResponse.setExperience(teacher.getExperience());
		teacherResponse.setSpecializedIn(teacher.getSpecializedIn());
		teacherResponse.setAdditionalQualification(teacher.getAdditionalQualification());
		teacherResponse.setProfile(teacher.getProfile());
		teacherResponse.setTeacherId(teacher.getId());
		teacherResponse.setTeacherUniqueId(seekerz.getUniqueId());
		return teacherResponse;
	}

	private AdminTeacherDTO adminTeacherResponse(Teacher teacher) {

		AdminTeacherDTO adminresponse = new AdminTeacherDTO();
		adminresponse.setTeacher(teacherResponse(teacher));
		adminresponse.setMobileNumber(teacher.getBasicInfo().getMobileNumber());
		adminresponse.setAge(teacher.getBasicInfo().getAge());
		adminresponse.setuGUniversity(teacher.getuGUniversity());
		adminresponse.setpGUniversity(teacher.getpGUniversity());
		adminresponse.setB_EdInstitute(teacher.getB_EdInstitute());
		adminresponse.setM_EdInstitute(teacher.getM_EdInstitute());
		adminresponse.setApprove(teacher.isApprove());
		adminresponse.setCertificate(teacher.getCertificate());
		adminresponse.setMode(teacher.getMode());
		adminresponse.setAbout(teacher.getAbout());
		adminresponse.setTrailclass(teacher.isTrailClass());
		return adminresponse;
	}

	public String approveTeacher(Long id) {
		Teacher teacher = teacherRepository.findById(id).get();
		if (teacher.isApprove() == true) {
			teacher.setApprove(false);
			teacherRepository.save(teacher);
			return "fasle";
		} else {
			teacher.setApprove(true);
			teacherRepository.save(teacher);
			return "true";
		}

	}

	public List<ActiveClassResponse> getTeacherByTrailClass(Role value, String timeZone) {
		List<Teacher> teachers = teacherRepository.findByTrailClassIsTrueAndApproveIsTrue();
		List<ActiveClassResponse> response = new ArrayList<ActiveClassResponse>();
		for (Teacher teacher : teachers) {
			for (ActiveClass activeClass : teacher.getClasses()) {
				response.add(activeClassService.activeClassResponse(activeClass, value, timeZone));
			}

		}
		return response;
	}

	public List<ScheduleClassResponseDTO> getManageClass(Long id, Role value) {
		Teacher teacher = teacherRepository.findById(id).get();
		return activeClassService.scheduleClassResponseForTeacher(teacher.getClasses(), value);
	}

	public List<TeacherCalender> getTeacherCalender(Long id) {
		Optional<Teacher> optionalTeacher = teacherRepository.findById(id);
		if (!optionalTeacher.isPresent()) {
			throw new EntityNotFoundException("Teacher not found with id: " + id);
		}

		Teacher teacher = optionalTeacher.get();
		Map<String, TeacherCalender> calenderMap = new HashMap<>();

		for (ActiveClass scheduleClass : teacher.getClasses()) {
			List<Student> students = studentRepository.findByActiveClassAndenableIsTrue(scheduleClass.getId());

			for (Student student : students) {
				ZonedDateTime startDateTime = zonedDateAndTime(student.getStudentStartDate(),
						student.getStudentStartTime(), student.getStudentInfo().getTimeZone());
				ZonedDateTime endDateTime = zonedDateAndTime(student.getStudentStartDate(), student.getStudentEndTime(),
						student.getStudentInfo().getTimeZone());
				ZoneId zone = ZoneId.of("Asia/Kolkata");
				ZonedDateTime startDateTimeInZone = startDateTime.withZoneSameInstant(zone);
				ZonedDateTime endDateTimeInZone = endDateTime.withZoneSameInstant(zone);
				DayOfWeek dayOfWeek = startDateTimeInZone.getDayOfWeek();

				String teacherStartDate = startDateTimeInZone.toLocalDate()
						.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
				String teacherEndDate = endDateTimeInZone.toLocalDate()
						.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
				String key = scheduleClass.getActivity() + "_" + student.getDayAndTime().getDay() + "_"
						+ student.getDayAndTime().getStartTime() + "_" + teacherStartDate;

				TeacherCalender teacherCalender = calenderMap.getOrDefault(key, new TeacherCalender());
				if (!calenderMap.containsKey(key)) {
					teacherCalender.setActivity(scheduleClass.getActivity());
					teacherCalender.setMeetingLink(student.getDayAndTime().getMeetingLink());

					teacherCalender.setStartDate(teacherStartDate);
					teacherCalender.setEndDate(teacherEndDate);
					teacherCalender.setStartTime(student.getDayAndTime().getStartTime());
					teacherCalender.setEndTime(student.getDayAndTime().getEndTime());
					teacherCalender.setDay(timezoneconvertor.generateDayFormat(dayOfWeek));
					teacherCalender.setStudents(new ArrayList<>());
					teacherCalender.setEnrolledStudentCount(0);
					calenderMap.put(key, teacherCalender);
				}

				StudentDetailsDTO studentDetails = new StudentDetailsDTO();
				studentDetails.setName(emailSender.name(student.getStudentInfo().getFirstName(),
						student.getStudentInfo().getMiddleName(), student.getStudentInfo().getLastName()));
				studentDetails.setRescheduleStatus(student.isRescheduleStatus());

				teacherCalender.getStudents().add(studentDetails);
				teacherCalender.setEnrolledStudentCount(teacherCalender.getEnrolledStudentCount() + 1);
			}
		}
		return new ArrayList<>(calenderMap.values());
	}

	private static ZonedDateTime zonedDateAndTime(String date, String time, String timezone) {
		LocalDateTime localDateTime = LocalDateTime.of(LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd")),
				LocalTime.parse(time));
		return ZonedDateTime.of(localDateTime, ZoneId.of("America/" + timezone));
	}

	public String teacherTimeZoneConverted(String date, String time, String timezone) {
		ZonedDateTime startDateTime = zonedDateAndTime(date, time, timezone);
		ZoneId zone = ZoneId.of("Asia/Kolkata");
		ZonedDateTime startDateTimeInZone = startDateTime.withZoneSameInstant(zone);
		String teacherDate = startDateTimeInZone.toLocalDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		return teacherDate;
	}

}
