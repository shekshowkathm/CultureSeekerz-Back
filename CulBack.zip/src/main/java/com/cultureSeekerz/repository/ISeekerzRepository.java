package com.cultureSeekerz.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cultureSeekerz.entity.Seekerz;

@Repository
public interface ISeekerzRepository extends JpaRepository<Seekerz, Long> {

	public boolean existsByEmail(String username);

	public Seekerz findByOtp(String otp);

	public boolean existsByEmailAndStatusIsTrue(String email);

	public boolean existsByEmailAndStatusIsFalse(String email);

	public Optional<Seekerz> findByEmail(String email);

	public Seekerz findByEmailAndStatusIsTrue(String username);

	public Optional<Seekerz> findByEmailAndStatus(String username, boolean status);


}
