package com.cultureSeekerz.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;

import com.cultureSeekerz.filter.JWTAuthFilter;
import com.cultureSeekerz.service.LoginService;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

	@Autowired
	@Qualifier("handlerExceptionResolver")
	private HandlerExceptionResolver exceptionResolver;
	
	@Bean
	public UserDetailsService userDetailsService() {
		return new LoginService();
	}
	
	@Bean
	public JWTAuthFilter jwtAuthFilter() {
		return new JWTAuthFilter(exceptionResolver);
	}
	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		return http.csrf(AbstractHttpConfigurer::disable)
				.authorizeHttpRequests(auth->{
					auth
					.requestMatchers(
							"/seekerz/unique/{email}",
							"/teacher/getTeacher",
							"/teacher/getTeacher/{id}",
							"/teacher/getTeachers/{specialization}",
							"/teacher/gettrialclassteachers/{timeZone}",
							"/activeclass/search",
							"/trailclass/add",
							"/activeclass/getactiveclass/{timeZone}",
							"/activeclass/getActiveClass/{id}/{timeZone}",
							"/activeclass/getbyactivity/{activity}/{timeZone}",
							"/activeclass/extracttopic/{activity}/{timeZone}",
							"/activeclass/getagegroup/{ageGroup}/{timeZone}",
							"/activeclass/trialclassSearch/{activity}/{timeZone}",
							"/teacher/add",
							"/seekerz/add",
							"/seekerz/update",
							"/seekerz/resend/{eamil}",
							"/seekerz/authenticate",
							"/seekerz/forgotPassword",
							"/seekerz/forgotpassword/{email}",
							"/seekerz/verifyOtp/{otp}",
							"/feedback/savefeedback"
							).permitAll()
				.requestMatchers("/teacher/**","/seekerz/**","/activeclass/**","/student/**","/trailclass/**","/pushnotification/**","/feedback/**")
				.authenticated();
					})
				.sessionManagement(session->session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))			
				.authenticationProvider(authenticationProvider())
				.addFilterBefore(jwtAuthFilter(), UsernamePasswordAuthenticationFilter.class).build();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public AuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
		authenticationProvider.setUserDetailsService(userDetailsService());
		authenticationProvider.setPasswordEncoder(passwordEncoder());
		return authenticationProvider;
	}

	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
		return config.getAuthenticationManager();
	}

}
