package com.cultureSeekerz.requestDTO;

public class RescheduledDataDTO {

	private Long studentId;
	private Long dayAndTimeId;
	private String newDate;
	private String newStartTime;
	private String newEndTime;

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public Long getDayAndTimeId() {
		return dayAndTimeId;
	}

	public void setDayAndTimeId(Long dayAndTimeId) {
		this.dayAndTimeId = dayAndTimeId;
	}

	public String getNewDate() {
		return newDate;
	}

	public void setNewDate(String newDate) {
		this.newDate = newDate;
	}

	public String getNewStartTime() {
		return newStartTime;
	}

	public void setNewStartTime(String newStartTime) {
		this.newStartTime = newStartTime;
	}

	public String getNewEndTime() {
		return newEndTime;
	}

	public void setNewEndTime(String newEndTime) {
		this.newEndTime = newEndTime;
	}

	@Override
	public String toString() {
		return "RescheduledDataDTO [studentId=" + studentId + ", dayAndTimeId=" + dayAndTimeId + ", newDate=" + newDate
				+ ", newStartTime=" + newStartTime + ", newEndTime=" + newEndTime + "]";
	}

}
