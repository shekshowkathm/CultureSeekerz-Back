package com.cultureSeekerz.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.cultureSeekerz.entity.TrialClass;
import com.cultureSeekerz.responseDTO.RemainderDTO;
import com.cultureSeekerz.responseDTO.RemainderEmail;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {
	@Autowired
	private JavaMailSender javaMailSender;
	@Autowired
	private Configuration config;
	@Value("${spring.mail.username}")
	private String sender;

	public void sendEmail(String to, TrialClass trialClass) {
		MimeMessage message = javaMailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			Template trialClassTemplate = config.getTemplate("trialClass-template.ftl");
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(trialClassTemplate, trialClass);
			helper.setTo(to);
			helper.setText(html, true);
			helper.setSubject("Invitation to Join Our " + trialClass.getActivity() + "  Trial Session");
			helper.setFrom(sender);
			ClassPathResource logo = new ClassPathResource("static/images/logo.png");
			helper.addInline("logoImage", logo);
			javaMailSender.send(message);
		} catch (MessagingException | IOException | TemplateException e) {
			e.printStackTrace();
		}
	}

	public void sendRemainderMail(RemainderDTO remanider) {
		MimeMessage message = javaMailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			Template trialClassTemplate = config.getTemplate("remainderMail-template.ftl");
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(trialClassTemplate, remanider);
			helper.setTo(remanider.getParentEmail());
			helper.setText(html, true);
			helper.setSubject("Payment Remainder");
			helper.setFrom(sender);
			javaMailSender.send(message);
		} catch (MessagingException | IOException | TemplateException e) {
			e.printStackTrace();
		}
	}

	public void send30MinMail(String email, RemainderEmail remanider) {
		MimeMessage message = javaMailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			Template trialClassTemplate = config.getTemplate("remainderMail-template.ftl");
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(trialClassTemplate, remanider);
			helper.setTo(email);
			helper.setText(html, true);
			helper.setSubject("30 min");
			helper.setFrom(sender);
			javaMailSender.send(message);
		} catch (MessagingException | IOException | TemplateException e) {
			e.printStackTrace();
		}
	}
}
