package com.cultureSeekerz.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cultureSeekerz.entity.Seekerz;
import com.cultureSeekerz.repository.ISeekerzRepository;
import com.cultureSeekerz.requestDTO.ChangePasswordDTO;
import com.cultureSeekerz.responseDTO.SeekerzDTO;
import com.cultureSeekerz.utils.CalculateAge;
import com.cultureSeekerz.utils.EmailSender;
import com.cultureSeekerz.utils.UniqueIdGenerator;

@Service
public class SeekerzService {

	@Autowired
	public ISeekerzRepository seekerzRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private EmailSender emailSender;

	public SeekerzDTO createSeekerz(Seekerz seekerz) {
		if (seekerzRepository.existsByEmailAndStatusIsTrue(seekerz.getEmail())) {
			return generateSeekerzResponse(seekerz, "Email already exist");
		} else if (seekerzRepository.existsByEmailAndStatusIsFalse(seekerz.getEmail())
				&& "STUDENT".equals(seekerz.getRole())) {
			return generateSeekerzResponse(seekerz, "Email already exist");
		} else if (seekerzRepository.existsByEmailAndStatusIsFalse(seekerz.getEmail())) {
			Seekerz seekerzObj = seekerzRepository.findByEmail(seekerz.getEmail()).get();
			seekerzObj.setPassword(passwordEncoder.encode(seekerz.getPassword()));
			updateSeekerzData(seekerzObj, seekerz);
			if (seekerz.getRole().equals("TEACHER")) {
				sendVerficationEmail(seekerzObj);
			}
			Seekerz result = seekerzRepository.save(seekerzObj);
			if (result.getChild() != null && !result.getChild().isEmpty()) {
				setParentId(result);
			}
			return generateSeekerzResponse(seekerzObj, "Saved");
		} else {
			if (seekerz.getMobileNumber() == null) {
				seekerz.setMobileNumber("-");
			}
			seekerz.setPassword(passwordEncoder.encode(seekerz.getPassword()));
			seekerz.setUniqueId(UniqueIdGenerator.generateShortUniqueId(seekerz.getRole()));
			if (seekerz.getRole().equals("STUDENT")) {
				seekerz.setStatus(true);
				seekerz.setAge(CalculateAge.calculateAge(seekerz));
			}
			if (seekerz.getRole().equals("TEACHER")) {
				sendVerficationEmail(seekerz);
			}
			Seekerz result = seekerzRepository.save(seekerz);
			if (result.getChild() != null && !result.getChild().isEmpty()) {
				setParentId(result);
			}
			return generateSeekerzResponse(seekerz, "Saved");
		}
	}

	private Seekerz updateSeekerzData(Seekerz seekerzObj, Seekerz seekerz) {
		seekerzObj.setChild(seekerz.getChild());
		seekerzObj.setFirstName(seekerz.getFirstName());
		seekerzObj.setMiddleName(seekerz.getMiddleName());
		seekerzObj.setLastName(seekerz.getLastName());
		seekerzObj.setGender(seekerz.getGender());
		if (seekerz.getMobileNumber() == null) {
			seekerz.setMobileNumber("-");
		} else {
			seekerzObj.setMobileNumber(seekerz.getMobileNumber());
		}
		seekerzObj.setTimeZone(seekerz.getTimeZone());
		if (seekerz.getRole() == "STUDENT") {
			seekerz.setStatus(true);
			seekerzObj.setAge(CalculateAge.calculateAge(seekerz));
		} else {
			seekerzObj.setAge(seekerz.getAge());
		}
		return seekerzObj;
	}

	private void sendVerficationEmail(Seekerz seekerz) {
		String OTPString = emailSender.createOtpString();
		seekerz.setOtp(OTPString);

		String name = emailSender.name(seekerz.getFirstName(), seekerz.getMiddleName(), seekerz.getLastName());
		emailSender.sendEmail(seekerz.getEmail(), name, OTPString);
		emailSender.expireOTP(seekerz);

	}

	private SeekerzDTO generateSeekerzResponse(Seekerz seekerz, String response) {
		SeekerzDTO seekerzResponse = new SeekerzDTO();
		seekerzResponse.setResponse(response);
		if (seekerz != null) {
			seekerzResponse.setId(seekerz.getId());
			seekerzResponse.setEmail(seekerz.getEmail());
			seekerzResponse
					.setName(emailSender.name(seekerz.getFirstName(), seekerz.getMiddleName(), seekerz.getLastName()));
			seekerzResponse.setRole(seekerz.getRole());
			if (seekerz.getRole() == "STUDENT") {
				seekerz.setAge(CalculateAge.calculateAge(seekerz));
			}
			seekerz.setAge(seekerz.getAge());
		}
		seekerzResponse.setTimeZone(seekerz.getTimeZone());
		return seekerzResponse;
	}

	public List<Seekerz> retrieveAllSeekerz() {
		return seekerzRepository.findAll();
	}

	public Optional<Seekerz> retrieveSeekerzById(Long id) {
		return seekerzRepository.findById(id);
	}

	public Seekerz updateSeekerzProfile(Seekerz seekerz) {
		Seekerz seekerzObj = seekerzRepository.findById(seekerz.getId()).get();
		if (seekerzObj.getChild().isEmpty() && seekerzObj.isStatus() == false) {
			sendVerficationEmail(seekerzObj);
		}
		if (!seekerz.getChild().isEmpty()) {
			setParentId(seekerz);
		}
		seekerzObj.setChild(seekerz.getChild());

		return seekerzRepository.save(seekerzObj);
	}

	public String deleteById(Long id) {
		if (seekerzRepository.existsById(id)) {
			seekerzRepository.deleteById(id);
			return "Seekers deleted";
		} else {
			return " Id doesn't exist";
		}
	}

	// verify OTP
	public SeekerzDTO verifyOtpAndActivateAccount(String otp) {
		Seekerz seekerz = seekerzRepository.findByOtp(otp);
		if (seekerz != null && seekerz.getOtp() != null) {
			seekerz.setStatus(true);
			seekerz.setOtp(null);
			seekerzRepository.save(seekerz);
			return generateSeekerzResponse(seekerz, "OTP is correct");
		} else {
			return generateSeekerzResponse(null, "OTP is invalid");
		}
	}

	public Seekerz resendOTP(String email) {
		Seekerz seekerz = seekerzRepository.findByEmail(email).get();
		sendVerficationEmail(seekerz);
		return seekerzRepository.save(seekerz);
	}

	public SeekerzDTO forgotPassowrd(ChangePasswordDTO changePasswordDto) {
		SeekerzDTO seekerzResponseDto = new SeekerzDTO();
		Seekerz seekerz = seekerzRepository.findByEmail(changePasswordDto.getEmail()).get();
		if (seekerz != null) {
			seekerz.setPassword(passwordEncoder.encode(changePasswordDto.getPassword()));
			seekerzRepository.save(seekerz);
			seekerzResponseDto.setId(seekerz.getId());
			seekerzResponseDto.setEmail(seekerz.getEmail());
			seekerzResponseDto
					.setName(emailSender.name(seekerz.getFirstName(), seekerz.getMiddleName(), seekerz.getLastName()));
			seekerzResponseDto.setRole(seekerz.getRole());
			seekerzResponseDto.setAge(seekerz.getAge());
			seekerzResponseDto.setResponse("Password saved");
			return seekerzResponseDto;
		} else {
			seekerzResponseDto.setResponse("email doesn't exist");
			return seekerzResponseDto;
		}
	}

	public SeekerzDTO forgotPasswordAndChangePassword(String email) {
		SeekerzDTO seekerzResonse = new SeekerzDTO();
		Seekerz seekerz = seekerzRepository.findByEmailAndStatusIsTrue(email);
		if (seekerz != null) {
			emailSender.forgotPasswordEmail(email,
					emailSender.name(seekerz.getFirstName(), seekerz.getMiddleName(), seekerz.getLastName()));
			seekerzResonse.setResponse("Mail send");
			return seekerzResonse;
		} else {
			seekerzResonse.setResponse("Email  doesn't exist");
			return seekerzResonse;
		}
	}

	private void setParentId(Seekerz result) {

		for (Seekerz childObj : result.getChild()) {
			Seekerz child = seekerzRepository.findById(childObj.getId()).get();
			Seekerz parent = seekerzRepository.findById(result.getId()).get();
			child.setParentId(result.getId());
			child.setTimeZone(parent.getTimeZone());
			seekerzRepository.save(child);
		}
	}

	public String generateUniqueId(String email) {
		Seekerz seekerz = seekerzRepository.findByEmail(email).get();
		String uniqueId = UniqueIdGenerator.generateShortUniqueId(seekerz.getRole());
		seekerz.setUniqueId(uniqueId);
		seekerzRepository.save(seekerz);
		return uniqueId;
	}
}
