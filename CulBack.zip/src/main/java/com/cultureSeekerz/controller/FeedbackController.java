package com.cultureSeekerz.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cultureSeekerz.entity.Feedback;
import com.cultureSeekerz.service.FeedbackService;

@RestController
@RequestMapping("/feedback")
@CrossOrigin("*")
public class FeedbackController {

	@Autowired
	private FeedbackService feedbackService;

	@PostMapping("/savefeedback")
	public Feedback saveFeedback(@RequestBody Feedback feedback) {
		return feedbackService.saveFeedback(feedback);
	}

	@GetMapping("/getallapprachesbytrue")
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<Feedback> getApporachesBytrue() {
		return feedbackService.getAllFeedbackApproachedTrue();
	}

	@GetMapping("/getallapprachesbyfalse")
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<Feedback> getApporachesByFalse() {
		return feedbackService.getAllFeedbackApproachedFalse();
	}

	@PutMapping("/updatefeedback/{id}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public Feedback updateFeedback(@PathVariable Long id) {
		return feedbackService.updateIsApproached(id);
	}
}
