package com.cultureSeekerz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CultureSeekerzApplicationTests {

	@Test
	void contextLoads() {
	}

}
