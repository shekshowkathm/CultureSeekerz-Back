package com.cultureSeekerz.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cultureSeekerz.entity.ActiveClass;
import com.cultureSeekerz.entity.Seekerz;
import com.cultureSeekerz.entity.Student;

@Repository
public interface IStudentRepository extends JpaRepository<Student, Long> {

	@Query("SELECT s FROM Student s WHERE s.studentInfo.id = :studentInfoId")
	List<Student> findByStudentInfoId(@Param("studentInfoId") Long studentInfoId);

	@Query("SELECT s FROM Student s WHERE s.studentInfo.id = :studentInfoId AND s.enable = false ")
	List<Student> findByStudentInfoIdAndEnable(@Param("studentInfoId") Long studentInfoId);

	Student findByStudentInfoAndActiveClassAndStudentStartDateAndStudentStartTime(Seekerz existingSeekerz,
			ActiveClass existingActiveClass, String studentStartDate, String studentStartTime);

	@Query("SELECT s FROM Student s WHERE s.studentInfo.id = :studentInfoId AND s.enable = true AND s.attendStatus = true")
	List<Student> findByStudentInfoIdAndEnableTrueAndAttendStatusTrue(@Param("studentInfoId") Long studentInfoId);

	@Query("SELECT s FROM Student s WHERE s.studentInfo.id = :studentInfoId AND s.attendStatus = false AND s.enable = true")
	List<Student> findByStudentInfoIdAndAttendStatusIsFalseAndEnableIsTrue(@Param("studentInfoId") Long studentInfoId);

	List<Student> findByAttendStatusIsFalseAndEnableIsTrueAndRemainderStatusIsFalse();

	@Query("SELECT s FROM Student s WHERE s.activeClass.activity = :activity AND s.enable = true AND s.classFees > 1")
	List<Student> findByActiveClassAndEnableIsTrueAndClassFeesGreaterThanOne(@Param("activity") String activity);

	@Query("SELECT s FROM Student s WHERE s.activeClass.activity = :activity AND s.enable = true AND s.classFees = 0")
	List<Student> findByActiveClassAndEnableIsTrueAndClassFeesIsZero(@Param("activity") String activity);

	@Query("SELECT s FROM Student s WHERE s.studentInfo.id= :studentInfoId AND s.enable = true And s.attendStatus = true")
	List<Student> findByStudentInfoIdAndEnableIsTrueAndAttendStatusIsTrue(@Param("studentInfoId") Long studentInfoId);

	@Query("SELECT s FROM Student s WHERE s.activeClass.id = :activeClassId AND s.enable = true")
	List<Student> findByActiveClassAndenableIsTrue(@Param("activeClassId") Long activeClassId);

	@Query("SELECT s FROM Student s WHERE s.activeClass.activity = :activity AND s.rescheduleRequest = true  AND s.rescheduleStatus = true")
	List<Student> findByActiveClassAndRescheduleRequestIsTrueAndRescheduleStatusIsTrue(
			@Param("activity") String activity);

	@Query("SELECT s FROM Student s WHERE s.activeClass.activity = :activity AND s.rescheduleRequest = true  AND s.rescheduleStatus = false")
	List<Student> findByActiveClassAndRescheduleRequestIsTrueAndRescheduleStatusIsFalse(
			@Param("activity") String activity);

	List<Student> findByUniqueId(String uniqueId);

	List<Student> findByAttendStatusIsTrueAndEnableIsTrueAndPaymentStatusIsFalse();

	List<Student> findByAttendStatusIsTrueAndEnableIsTrueAndPaymentStatusIsTrue();

	List<Student> findByUniqueIdAndAttendStatusIsTrueAndEnableIsTrue(String uniqueId);
}
