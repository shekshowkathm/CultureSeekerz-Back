package com.cultureSeekerz.utils;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import com.cultureSeekerz.entity.Seekerz;
import com.cultureSeekerz.entity.TrialClass;
import com.cultureSeekerz.repository.ISeekerzRepository;

/**
 * 
 * @author josephine
 * @date 25-Jan-2024
 * 
 */
@Component
public class EmailSender {

	@Autowired
	private JavaMailSender javaMailSender;

	@Value("${spring.mail.username}")
	private String sender;

	@Autowired
	private ISeekerzRepository seekerzRepository;

	// Create OTP for seekerz
	public String createOtpString() {
		Random randomotp = new Random();
		int otp = 100000 + randomotp.nextInt(900000);
		return Integer.toString(otp);
	}

	// sending email to the register Seekerz
	public void sendEmail(String to, String name, String OTP) {
		Thread thread = new Thread(() -> {
			String text = "Hello " + name + ",\n";
			text += "Your verification code for completing your registration is:" + OTP + "\n\n";
			text += "Please enter this code in the designated field to confirm your registration. For security purposes, please do not share this code with anyone."
					+ "\n";
			text += "Thank you for choosing our platform." + "\n\n";
			text += "Best regards," + "\n";
			text += "CultureSeekerz Team";
			SimpleMailMessage message = new SimpleMailMessage();
			message.setFrom(sender);
			message.setTo(to);
			message.setSubject("Registration Verification Code");
			message.setText(text);
			javaMailSender.send(message);
		});
		thread.start();
	}

	// expiring the OTP
	public void expireOTP(Seekerz seekerz) {
		Timer timer = new Timer();
		timer.schedule(new TimerTask() {

			@Override
			public void run() {
				System.out.println("timer handled");
				Seekerz seekerzObj = seekerzRepository.findById(seekerz.getId()).get();
				seekerzObj.setOtp(null);
				seekerzRepository.save(seekerzObj);
				System.out.println("null value saved on otp");
			}
		}, 120000);
	}

	public String name(String firstName, String middleName, String lastName) {
		if (middleName == null) {
			String name = firstName + " " + lastName;
			return name;
		} else {
			String name = firstName + " " + middleName + " " + lastName;
			return name;
		}
	}

	// Sending mail for trail class
	public void sendEmailForTrailClass(String to, TrialClass trialClass) {
		Thread thread = new Thread(() -> {
			String text = "Dear Educators/Parents/Learners " + ",\n";
			text += " Join us for an exciting " + trialClass.getActivity() + " trial session on " + trialClass.getDate()
					+ " at " + trialClass.getTime() + ". \n";
			text += "Access the online class here:" + trialClass.getMeetingLink() + "\n";
			text += "We look forward to your participation for an engaging and enriching experience." + "\n\n";
			text += "Best regards," + "\n";
			text += "CultureSeekerz Team";
			SimpleMailMessage message = new SimpleMailMessage();
			message.setFrom(sender);
			message.setTo(to);
			message.setSubject("Invitation to Join Our " + trialClass.getActivity() + "  Trial Session");
			message.setText(text);
			javaMailSender.send(message);
		});
		thread.start();
	}

	// Forgotpassword

	public void forgotPasswordEmail(String to, String name) {
		Thread thread = new Thread(() -> {
			String text = "Dear " + name + ",\n";
			text += "We've received a request to reset the password associated with your account. To proceed with the password reset process, please click on the link below:"
					+ "\n\n";
			text += "https://cultureseekerz.com/changepassword/" + to + "/qwertyuiopasdfghjkl;zxcvbnm" + "\n";
			text += "If you did not initiate this request, you can safely disregard this email." + "\n";
			text += "Best regards," + "\n";
			text += "CultureSeekerz Team";
			SimpleMailMessage message = new SimpleMailMessage();
			message.setFrom(sender);
			message.setTo(to);
			message.setSubject("Password Reset Request");
			message.setText(text);
			javaMailSender.send(message);
		});
		thread.start();
	}
}
