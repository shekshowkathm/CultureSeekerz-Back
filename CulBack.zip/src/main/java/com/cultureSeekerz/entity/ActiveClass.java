package com.cultureSeekerz.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class ActiveClass {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne
	private Teacher teacher;
	@Column(length = 3000)
	private String description;
	@Column(length = 3000)
	private String demoVideo;
	private String activity;
	private List<String> day;
	private boolean approve;
	private List<String> classType;
	private List<String> ageGroup;
	private String classImage;
	private String feesRange;
	private String feesInr;
	@OneToMany(mappedBy = "activeClass", cascade = CascadeType.ALL)
	private List<Student> students;
	@Column(length = 10000)
	private List<String> topics;
	private String uniqueId;
	private String classUniqueId;
	@OneToMany
	private List<DayAndTime> dayAndTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDemoVideo() {
		return demoVideo;
	}

	public void setDemoVideo(String demoVideo) {
		this.demoVideo = demoVideo;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public List<String> getDay() {
		return day;
	}

	public void setDay(List<String> day) {
		this.day = day;
	}

	public boolean isApprove() {
		return approve;
	}

	public void setApprove(boolean approve) {
		this.approve = approve;
	}

	public List<String> getClassType() {
		return classType;
	}

	public void setClassType(List<String> classType) {
		this.classType = classType;
	}

	public List<String> getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(List<String> ageGroup) {
		this.ageGroup = ageGroup;
	}

	public String getClassImage() {
		return classImage;
	}

	public void setClassImage(String classImage) {
		this.classImage = classImage;
	}

	public String getFeesRange() {
		return feesRange;
	}

	public void setFeesRange(String feesRange) {
		this.feesRange = feesRange;
	}

	public String getFeesInr() {
		return feesInr;
	}

	public void setFeesInr(String feesInr) {
		this.feesInr = feesInr;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	public List<String> getTopics() {
		return topics;
	}

	public void setTopics(List<String> topics) {
		this.topics = topics;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getClassUniqueId() {
		return classUniqueId;
	}

	public void setClassUniqueId(String classUniqueId) {
		this.classUniqueId = classUniqueId;
	}

	public List<DayAndTime> getDayAndTime() {
		return dayAndTime;
	}

	public void setDayAndTime(List<DayAndTime> dayAndTime) {
		this.dayAndTime = dayAndTime;
	}

	@Override
	public String toString() {
		return "ActiveClass [id=" + id + ", teacher=" + teacher + ", description=" + description + ", demoVideo="
				+ demoVideo + ", activity=" + activity + ", day=" + day + ", approve=" + approve + ", classType="
				+ classType + ", ageGroup=" + ageGroup + ", classImage=" + classImage + ", feesRange=" + feesRange
				+ ", feesInr=" + feesInr + ", students=" + students + ", topics=" + topics + ", uniqueId=" + uniqueId
				+ ", classUniqueId=" + classUniqueId + ", dayAndTime=" + dayAndTime + "]";
	}

}