package com.cultureSeekerz.responseDTO;

import java.util.List;

import com.cultureSeekerz.dto.ParentResponseDTO;
import com.cultureSeekerz.dto.StudentResponse;
import com.cultureSeekerz.dto.TeacherInfoResponse;

public class RescheduleDTO {

	private String activity;
	private TeacherInfoResponse teacher;
	private StudentResponse student;
	private ParentResponseDTO parent;
	private String timeZone;
	private List<DayAndTimeDTO> dayAndTimeDTO;

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public TeacherInfoResponse getTeacher() {
		return teacher;
	}

	public void setTeacher(TeacherInfoResponse teacher) {
		this.teacher = teacher;
	}

	public StudentResponse getStudent() {
		return student;
	}

	public void setStudent(StudentResponse student) {
		this.student = student;
	}

	public ParentResponseDTO getParent() {
		return parent;
	}

	public void setParent(ParentResponseDTO parent) {
		this.parent = parent;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public List<DayAndTimeDTO> getDayAndTimeDTO() {
		return dayAndTimeDTO;
	}

	public void setDayAndTimeDTO(List<DayAndTimeDTO> dayAndTimeDTO) {
		this.dayAndTimeDTO = dayAndTimeDTO;
	}

	@Override
	public String toString() {
		return "RescheduleDTO [activity=" + activity + ", teacher=" + teacher + ", student=" + student + ", parent="
				+ parent + ", timeZone=" + timeZone + ", dayAndTimeDTO=" + dayAndTimeDTO + "]";
	}
}
