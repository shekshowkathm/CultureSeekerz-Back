package com.cultureSeekerz.dto;

import java.util.List;

public class TeacherScheduleDTO {

	private AdminTeacherDTO teacher;
	private List<ScheduleClassResponseDTO> scheduleClassResponse;

	public AdminTeacherDTO getTeacher() {
		return teacher;
	}

	public void setTeacher(AdminTeacherDTO teacher) {
		this.teacher = teacher;
	}

	public List<ScheduleClassResponseDTO> getScheduleClassResponse() {
		return scheduleClassResponse;
	}

	public void setScheduleClassResponse(List<ScheduleClassResponseDTO> scheduleClassResponse) {
		this.scheduleClassResponse = scheduleClassResponse;
	}

}
