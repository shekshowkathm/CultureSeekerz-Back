package com.cultureSeekerz.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cultureSeekerz.entity.PushNotification;

import jakarta.transaction.Transactional;

@Repository
public interface IPushNotificationRepository extends JpaRepository<PushNotification, Long> {

	List<PushNotification> findByParentId(Long parentId);

	List<PushNotification> findByTeacherId(Long teacherId);

	List<PushNotification> findByStudentLoginId(Long studentLoginId);

	List<PushNotification> findByNotificationStatusIsFalseAndStudentNotificationTokenIsNullAndParentIdIsNotNullAndNotificationTokenIsNotNull();

	List<PushNotification> findByNotificationStatusIsFalseAndStudentNotificationTokenIsNotNull();

	List<PushNotification> findByNotificationStatusIsFalseAndTeacherIdIsNotNullAndNotificationTokenIsNotNullAndStudentIdIsNotNull();

	List<PushNotification> findByParentIdAndStudentLoginId(Long parentId, Long studentLoginId);

	List<PushNotification> findByNotificationStatusFalseAndTeacherIdIsNotNullAndNotificationTokenIsNotNullAndEnrollStudentIdIsNotNull();

	@Modifying
	@Transactional
	@Query("DELETE FROM PushNotification pn WHERE pn.student.id = :studentId")
	int deleteByStudentId(@Param("studentId") Long studentId);
}
