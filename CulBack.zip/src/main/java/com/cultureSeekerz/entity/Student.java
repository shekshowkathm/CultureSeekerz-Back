package com.cultureSeekerz.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne
	@JoinColumn(name = "studentInfo_id")
	private Seekerz studentInfo;
	private String uniqueId;
	@ManyToOne
	@JoinColumn(name = "active_class_id")
	private ActiveClass activeClass;
	private boolean attendStatus;
	private boolean enable;
	private boolean paymentStatus;
	@ManyToOne
	@JoinColumn(name = "day_and_time_id")
	private DayAndTime dayAndTime;

	private String studentStartDate;
	private String studentEndDate;
	private String studentStartTime;
	private String studentEndTime;

	private boolean remainderStatus;
	private boolean rescheduleRequest;
	private boolean rescheduleStatus;
	@Column(length = 10000)
	private List<String> accomplishments;
	@Column(length = 10000)
	private List<String> goals;
	@Column(length = 10000)
	private List<String> feedback;
	@Column(length = 10000)
	private List<String> topicsCovered;
	private String classType;
	private String ageGroup;
	private double classFees;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Seekerz getStudentInfo() {
		return studentInfo;
	}

	public void setStudentInfo(Seekerz studentInfo) {
		this.studentInfo = studentInfo;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public ActiveClass getActiveClass() {
		return activeClass;
	}

	public void setActiveClass(ActiveClass activeClass) {
		this.activeClass = activeClass;
	}

	public boolean isAttendStatus() {
		return attendStatus;
	}

	public void setAttendStatus(boolean attendStatus) {
		this.attendStatus = attendStatus;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	public boolean isPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(boolean paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public DayAndTime getDayAndTime() {
		return dayAndTime;
	}

	public void setDayAndTime(DayAndTime dayAndTime) {
		this.dayAndTime = dayAndTime;
	}

	public String getStudentStartDate() {
		return studentStartDate;
	}

	public void setStudentStartDate(String studentStartDate) {
		this.studentStartDate = studentStartDate;
	}

	public String getStudentEndDate() {
		return studentEndDate;
	}

	public void setStudentEndDate(String studentEndDate) {
		this.studentEndDate = studentEndDate;
	}

	public String getStudentStartTime() {
		return studentStartTime;
	}

	public void setStudentStartTime(String studentStartTime) {
		this.studentStartTime = studentStartTime;
	}

	public String getStudentEndTime() {
		return studentEndTime;
	}

	public void setStudentEndTime(String studentEndTime) {
		this.studentEndTime = studentEndTime;
	}

	public boolean isRemainderStatus() {
		return remainderStatus;
	}

	public void setRemainderStatus(boolean remainderStatus) {
		this.remainderStatus = remainderStatus;
	}

	public boolean isRescheduleRequest() {
		return rescheduleRequest;
	}

	public void setRescheduleRequest(boolean rescheduleRequest) {
		this.rescheduleRequest = rescheduleRequest;
	}

	public boolean isRescheduleStatus() {
		return rescheduleStatus;
	}

	public void setRescheduleStatus(boolean rescheduleStatus) {
		this.rescheduleStatus = rescheduleStatus;
	}

	public List<String> getAccomplishments() {
		return accomplishments;
	}

	public void setAccomplishments(List<String> accomplishments) {
		this.accomplishments = accomplishments;
	}

	public List<String> getGoals() {
		return goals;
	}

	public void setGoals(List<String> goals) {
		this.goals = goals;
	}

	public List<String> getFeedback() {
		return feedback;
	}

	public void setFeedback(List<String> feedback) {
		this.feedback = feedback;
	}

	public List<String> getTopicsCovered() {
		return topicsCovered;
	}

	public void setTopicsCovered(List<String> topicsCovered) {
		this.topicsCovered = topicsCovered;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public String getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}

	public double getClassFees() {
		return classFees;
	}

	public void setClassFees(double classFees) {
		this.classFees = classFees;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", studentInfo=" + studentInfo + ", uniqueId=" + uniqueId + ", activeClass="
				+ activeClass + ", attendStatus=" + attendStatus + ", enable=" + enable + ", paymentStatus="
				+ paymentStatus + ", dayAndTime=" + dayAndTime + ", studentStartDate=" + studentStartDate
				+ ", studentEndDate=" + studentEndDate + ", studentStartTime=" + studentStartTime + ", studentEndTime="
				+ studentEndTime + ", remainderStatus=" + remainderStatus + ", rescheduleRequest=" + rescheduleRequest
				+ ", rescheduleStatus=" + rescheduleStatus + ", accomplishments=" + accomplishments + ", goals=" + goals
				+ ", feedback=" + feedback + ", topicsCovered=" + topicsCovered + ", classType=" + classType
				+ ", ageGroup=" + ageGroup + ", classFees=" + classFees + "]";
	}

//	@PrePersist
//	protected void onCreate() {
//		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//		this.enrolledOn = LocalDate.now().format(formatter);
//	}

}
