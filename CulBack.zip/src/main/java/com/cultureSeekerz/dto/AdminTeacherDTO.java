package com.cultureSeekerz.dto;

public class AdminTeacherDTO {

	private TeacherResponseDTO teacher;
	private String mobileNumber;
	private int age;
	private String uGUniversity;
	private String pGUniversity;
	private String b_EdInstitute;
	private String m_EdInstitute;
	private boolean approve;
	private String mode;
	private String about;
	private boolean trailclass;
	private String certificate;

	public TeacherResponseDTO getTeacher() {
		return teacher;
	}

	public void setTeacher(TeacherResponseDTO teacher) {
		this.teacher = teacher;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getuGUniversity() {
		return uGUniversity;
	}

	public void setuGUniversity(String uGUniversity) {
		this.uGUniversity = uGUniversity;
	}

	public String getpGUniversity() {
		return pGUniversity;
	}

	public void setpGUniversity(String pGUniversity) {
		this.pGUniversity = pGUniversity;
	}

	public String getB_EdInstitute() {
		return b_EdInstitute;
	}

	public void setB_EdInstitute(String b_EdInstitute) {
		this.b_EdInstitute = b_EdInstitute;
	}

	public String getM_EdInstitute() {
		return m_EdInstitute;
	}

	public void setM_EdInstitute(String m_EdInstitute) {
		this.m_EdInstitute = m_EdInstitute;
	}

	public boolean isApprove() {
		return approve;
	}

	public void setApprove(boolean approve) {
		this.approve = approve;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public boolean isTrailclass() {
		return trailclass;
	}

	public void setTrailclass(boolean trailclass) {
		this.trailclass = trailclass;
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	@Override
	public String toString() {
		return "AdminTeacherDTO [teacher=" + teacher + ", mobileNumber=" + mobileNumber + ", age=" + age
				+ ", uGUniversity=" + uGUniversity + ", pGUniversity=" + pGUniversity + ", b_EdInstitute="
				+ b_EdInstitute + ", m_EdInstitute=" + m_EdInstitute + ", approve=" + approve + ", mode=" + mode
				+ ", about=" + about + ", trailclass=" + trailclass + ", certificate=" + certificate + "]";
	}

}
