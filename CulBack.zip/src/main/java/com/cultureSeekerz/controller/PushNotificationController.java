package com.cultureSeekerz.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cultureSeekerz.entity.PushNotification;
import com.cultureSeekerz.firebase.PushNotificationService;
import com.cultureSeekerz.responseDTO.Events;

@RestController
@CrossOrigin("*")
@RequestMapping("/pushnotification")
public class PushNotificationController {

	@Autowired
	private PushNotificationService pushnotificationService;

	@PostMapping("/add")
	@PreAuthorize("hasAnyAuthority('TEACHER', 'STUDENT','PARENT')")
	public String createPushNotification(@RequestParam Long id, @RequestParam String notificationToken,
			@RequestParam String role) {
		return pushnotificationService.addPushNotificationToken(id, notificationToken, role);
	}

	//not used
	@GetMapping("/get/{id}/{role}")
	@PreAuthorize("hasAnyAuthority('TEACHER', 'STUDENT','PARENT')")
	public List<PushNotification> getNotificationBefore30Min(@PathVariable Long id, @PathVariable String role) {
		return pushnotificationService.getNotificationBefore30Min(id, role);
	}

	@GetMapping("/getTodayClass/{id}/{role}")
	@PreAuthorize("hasAnyAuthority('TEACHER', 'STUDENT','PARENT')")
	public List<Events> getTodayClasses(@PathVariable Long id, @PathVariable String role) {
		return pushnotificationService.retrieveTodayClasses(id, role);
	}

	@GetMapping("/getStudentClass/{parentId}/{studentLoginId}")
	@PreAuthorize("hasAuthority('STUDENT')")
	public List<Events> getStudentTodayClasses(@PathVariable Long parentId, @PathVariable Long studentId) {
		return pushnotificationService.retrieveStudentTodayClasses(parentId, studentId);
	}
}
