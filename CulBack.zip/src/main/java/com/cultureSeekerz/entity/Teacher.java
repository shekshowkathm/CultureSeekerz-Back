package com.cultureSeekerz.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

/**
 * 
 * @author Josephine
 * @date 3-Feb-2024
 * 
 */
@Entity
public class Teacher {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@OneToOne
	@JoinColumn(name = "seekerz_id")
	private Seekerz basicInfo;
	@Column(length = 1000)
	private String profile;
	private String uG;
	private String uGUniversity;
	private String pG;
	private String pGUniversity;
	private boolean b_Ed;
	private String b_EdInstitute;
	private boolean m_Ed;
	private String m_EdInstitute;
	private String experience;
	private List<String> specializedIn;
	private String additionalQualification;
	private String certificate;
	private boolean approve;
	private String mode;
	@Column(length = 1000)
	private String about;
	private boolean trailClass;
	@OneToMany
	@JoinTable(name = "teacher_activeClass", joinColumns = @JoinColumn(name = "teacher_id"), inverseJoinColumns = @JoinColumn(name = "activeClass_id"))
	private List<ActiveClass> classes = new ArrayList<ActiveClass>();
	private String uniqueId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Seekerz getBasicInfo() {
		return basicInfo;
	}

	public void setBasicInfo(Seekerz basicInfo) {
		this.basicInfo = basicInfo;
	}

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public String getuG() {
		return uG;
	}

	public void setuG(String uG) {
		this.uG = uG;
	}

	public String getuGUniversity() {
		return uGUniversity;
	}

	public void setuGUniversity(String uGUniversity) {
		this.uGUniversity = uGUniversity;
	}

	public String getpG() {
		return pG;
	}

	public void setpG(String pG) {
		this.pG = pG;
	}

	public String getpGUniversity() {
		return pGUniversity;
	}

	public void setpGUniversity(String pGUniversity) {
		this.pGUniversity = pGUniversity;
	}

	public boolean isB_Ed() {
		return b_Ed;
	}

	public void setB_Ed(boolean b_Ed) {
		this.b_Ed = b_Ed;
	}

	public String getB_EdInstitute() {
		return b_EdInstitute;
	}

	public void setB_EdInstitute(String b_EdInstitute) {
		this.b_EdInstitute = b_EdInstitute;
	}

	public boolean isM_Ed() {
		return m_Ed;
	}

	public void setM_Ed(boolean m_Ed) {
		this.m_Ed = m_Ed;
	}

	public String getM_EdInstitute() {
		return m_EdInstitute;
	}

	public void setM_EdInstitute(String m_EdInstitute) {
		this.m_EdInstitute = m_EdInstitute;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public List<String> getSpecializedIn() {
		return specializedIn;
	}

	public void setSpecializedIn(List<String> specializedIn) {
		this.specializedIn = specializedIn;
	}

	public String getAdditionalQualification() {
		return additionalQualification;
	}

	public void setAdditionalQualification(String additionalQualification) {
		this.additionalQualification = additionalQualification;
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	public boolean isApprove() {
		return approve;
	}

	public void setApprove(boolean approve) {
		this.approve = approve;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public boolean isTrailClass() {
		return trailClass;
	}

	public void setTrailClass(boolean trailClass) {
		this.trailClass = trailClass;
	}

	public List<ActiveClass> getClasses() {
		return classes;
	}

	public void setClasses(List<ActiveClass> classes) {
		this.classes = classes;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	@Override
	public String toString() {
		return "Teacher [id=" + id + ", basicInfo=" + basicInfo + ", profile=" + profile + ", uG=" + uG
				+ ", uGUniversity=" + uGUniversity + ", pG=" + pG + ", pGUniversity=" + pGUniversity + ", b_Ed=" + b_Ed
				+ ", b_EdInstitute=" + b_EdInstitute + ", m_Ed=" + m_Ed + ", m_EdInstitute=" + m_EdInstitute
				+ ", experience=" + experience + ", specializedIn=" + specializedIn + ", additionalQualification="
				+ additionalQualification + ", certificate=" + certificate + ", approve=" + approve + ", mode=" + mode
				+ ", about=" + about + ", trailClass=" + trailClass + ", classes=" + classes + ", uniqueId=" + uniqueId
				+ "]";
	}

}
