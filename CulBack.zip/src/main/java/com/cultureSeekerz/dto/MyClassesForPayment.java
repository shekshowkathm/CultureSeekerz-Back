package com.cultureSeekerz.dto;

public class MyClassesForPayment {

	private String teacherName;
	private String activity;
	private String enrolledOn;
	private double fees;
	private Long activeClassId;
	private boolean paid;
	private Long studentId;

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getEnrolledOn() {
		return enrolledOn;
	}

	public void setEnrolledOn(String enrolledOn) {
		this.enrolledOn = enrolledOn;
	}

	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	public Long getActiveClassId() {
		return activeClassId;
	}

	public void setActiveClassId(Long activeClassId) {
		this.activeClassId = activeClassId;
	}

	public boolean isPaid() {
		return paid;
	}

	public void setPaid(boolean paid) {
		this.paid = paid;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

}
