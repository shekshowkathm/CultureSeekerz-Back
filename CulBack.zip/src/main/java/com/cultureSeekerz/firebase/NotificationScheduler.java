package com.cultureSeekerz.firebase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.SimpleTrigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.cultureSeekerz.entity.PushNotification;
import com.cultureSeekerz.entity.Seekerz;
import com.cultureSeekerz.repository.IPushNotificationRepository;
import com.cultureSeekerz.repository.ISeekerzRepository;
import com.cultureSeekerz.responseDTO.Events;
import com.cultureSeekerz.responseDTO.RemainderEmail;
import com.cultureSeekerz.service.EmailService;

@Component
public class NotificationScheduler {

	@Autowired
	private Scheduler scheduler;

	@Autowired
	private EmailService emailService;

	@Autowired
	private PushNotificationService pushNotificationService;

	@Autowired
	private ISeekerzRepository seekerzRepository;

	@Autowired
	private IPushNotificationRepository pushNotificationRepository;

	private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");

	@Scheduled(fixedRate = 60000)
	private void scheduleNotifications() throws SchedulerException {
		List<Events> events = pushNotificationService.getParentEvents();
		if (events != null) {
			for (Events event : events) {
				if (!event.isNotificationStatus()) {
					scheduleEventNotification(event);
				}
			}
		}
		List<Events> teacherEvents = pushNotificationService.getTeacherEvents();
		if (teacherEvents != null) {
			for (Events event : teacherEvents) {
				if (!event.isNotificationStatus()) {
					scheduleEventNotification(event);
				}
			}
		}
		List<Events> studentEvent = pushNotificationService.getStudentEvents();
		if (studentEvent != null) {
			for (Events event : studentEvent) {
				if (!event.isNotificationStatus()) {
					scheduleEventNotification(event);
				}
			}
		}
	}

	public void scheduleEventNotification(Events event) throws SchedulerException {
		if (event.isNotificationStatus()) {
			return;
		}

		String body = "Your event will start in 30 minutes.";
		String eventDate = event.getDate();
		String eventTime = event.getTime();
		String url = "https://cultureseekerz.com/";

		if (eventDate == null || eventTime == null) {
			return;
		}

		String eventDateTime = eventDate + " " + eventTime;

		Calendar calendar = Calendar.getInstance();
		try {
			Date date = dateFormat.parse(eventDateTime);
			calendar.setTime(date);
			System.out.println("Parsed Date: " + date);
			System.out.println("Calendar Time: " + calendar.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
			return;
		}

		String title = event.getActivity() + " event";
		scheduleNotification(calendar, event.getNotificationToken(), title, body, event.getEventId(), url);

		Calendar reminderTime = (Calendar) calendar.clone();
		reminderTime.add(Calendar.MINUTE, -30);
		
		PushNotification pushNotification = pushNotificationRepository.findById(event.getEventId()).get();
		if (pushNotification.isEmailSend() != true
				&& reminderTime.getTimeInMillis() <= System.currentTimeMillis() + 1000) {
			Seekerz seeker = seekerzRepository.findById(event.getLoginId()).get();
			RemainderEmail remainderEmail = new RemainderEmail();
			remainderEmail.setActivity(event.getActivity());
			remainderEmail.setDate(eventDate);
			remainderEmail.setTime(eventTime);
			remainderEmail.setTeacherName(event.getTeacherName());
			pushNotification.setEmailSend(true);
			pushNotificationRepository.save(pushNotification);
			emailService.send30MinMail(seeker.getEmail(), remainderEmail);
		}
	}

	public void scheduleNotification(Calendar eventTime, String notificationToken, String title, String body, Long id,
			String url) throws SchedulerException {
		long eventTimeInMillis = eventTime.getTimeInMillis();

		long currentTimeInMillis = System.currentTimeMillis();

		long notificationTimeInMillis = eventTimeInMillis - (30 * 60 * 1000);

		System.out.println("Event Time: " + eventTime.getTime());
		System.out.println("Event Time in Millis: " + eventTimeInMillis);
		System.out.println("Current Time in Millis: " + currentTimeInMillis);
		System.out.println("Notification Time in Millis: " + notificationTimeInMillis);

		if (notificationTimeInMillis <= currentTimeInMillis || notificationTimeInMillis > eventTimeInMillis) {
			System.out.println("Invalid notification time. Skipping scheduling.");
			return;
		}

		Date notificationTime = new Date(notificationTimeInMillis);

		System.out.println("Notification Time: " + notificationTime);

		JobDataMap jobDataMap = new JobDataMap();
		jobDataMap.put("notificationToken", notificationToken);
		jobDataMap.put("title", title);
		jobDataMap.put("body", body);
		jobDataMap.put("id", id);
		jobDataMap.put("url", url);

		JobDetail jobDetail = JobBuilder.newJob(NotificationJob.class).usingJobData(jobDataMap).build();

		SimpleTrigger trigger = (SimpleTrigger) TriggerBuilder.newTrigger().startAt(notificationTime)
				.withSchedule(SimpleScheduleBuilder.simpleSchedule()).build();

		scheduler.scheduleJob(jobDetail, trigger);
	}

}
