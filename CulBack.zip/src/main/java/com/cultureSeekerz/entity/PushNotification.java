package com.cultureSeekerz.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class PushNotification {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(length = 1000)
	private String notificationToken;
	@OneToOne
	@JoinColumn(name = "student_id", referencedColumnName = "id")
	private Student student;
	private Long parentId;
	private Long studentLoginId;
	private Long teacherId;
	private boolean notificationStatus;
	@Column(length = 1000)
	private String studentNotificationToken;
	private Long enrollStudentId;
	private boolean emailSend;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNotificationToken() {
		return notificationToken;
	}

	public void setNotificationToken(String notificationToken) {
		this.notificationToken = notificationToken;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public Long getStudentLoginId() {
		return studentLoginId;
	}

	public void setStudentLoginId(Long studentLoginId) {
		this.studentLoginId = studentLoginId;
	}

	public Long getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(Long teacherId) {
		this.teacherId = teacherId;
	}

	public boolean isNotificationStatus() {
		return notificationStatus;
	}

	public void setNotificationStatus(boolean notificationStatus) {
		this.notificationStatus = notificationStatus;
	}

	public String getStudentNotificationToken() {
		return studentNotificationToken;
	}

	public void setStudentNotificationToken(String studentNotificationToken) {
		this.studentNotificationToken = studentNotificationToken;
	}

	public Long getEnrollStudentId() {
		return enrollStudentId;
	}

	public void setEnrollStudentId(Long enrollStudentId) {
		this.enrollStudentId = enrollStudentId;
	}

	public boolean isEmailSend() {
		return emailSend;
	}

	public void setEmailSend(boolean emailSend) {
		this.emailSend = emailSend;
	}

	@Override
	public String toString() {
		return "PushNotification [id=" + id + ", notificationToken=" + notificationToken + ", student=" + student
				+ ", parentId=" + parentId + ", studentLoginId=" + studentLoginId + ", teacherId=" + teacherId
				+ ", notificationStatus=" + notificationStatus + ", studentNotificationToken="
				+ studentNotificationToken + ", enrollStudentId=" + enrollStudentId + ", emailSend=" + emailSend + "]";
	}

}
