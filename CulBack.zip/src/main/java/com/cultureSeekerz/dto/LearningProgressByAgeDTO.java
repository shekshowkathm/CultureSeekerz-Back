package com.cultureSeekerz.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LearningProgressByAgeDTO {

	private String activity;
	private List<ClassDTO> classes;

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public List<ClassDTO> getClasses() {
		return classes;
	}

	public void setClasses(List<ClassDTO> classes) {
		this.classes = classes;
	}

	@Override
	public String toString() {
		return "LearningProgressByAgeDTO [activity=" + activity + ", classes=" + classes + "]";
	}

}
