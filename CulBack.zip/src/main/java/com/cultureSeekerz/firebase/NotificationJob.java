package com.cultureSeekerz.firebase;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class NotificationJob implements Job {

	@Autowired
	private PushNotificationService pushNotificationService;

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		String notificationToken = context.getJobDetail().getJobDataMap().getString("notificationToken");
		String title = context.getJobDetail().getJobDataMap().getString("title");
		String body = context.getJobDetail().getJobDataMap().getString("body");
		Long id = context.getJobDetail().getJobDataMap().getLong("id");
		String url = context.getJobDetail().getJobDataMap().getString("url");
		pushNotificationService.sendPushNotification(notificationToken, title, body, id, url);
	}
}
