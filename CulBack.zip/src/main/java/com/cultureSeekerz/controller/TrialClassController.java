package com.cultureSeekerz.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cultureSeekerz.entity.TrialClass;
import com.cultureSeekerz.service.TrialClassService;

@RestController
@RequestMapping("/trailclass")
@CrossOrigin("*")
public class TrialClassController {
	@Autowired
	private TrialClassService trialClassService;

	@PostMapping("/add")
	public TrialClass createTrailClass(@RequestBody TrialClass trialClass) {
		return trialClassService.createTrailClass(trialClass);
	}

	@GetMapping("/getTrialClasses/{activity}/{scheduledStatus}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<TrialClass> getTrailClassRequest(@PathVariable String activity,@PathVariable boolean scheduledStatus) {
		return trialClassService.getTrailClass(activity,scheduledStatus);
	}
	
	@PutMapping("/sendEmail")
	@PreAuthorize("hasAuthority('ADMIN')")
	public String updateAndSendEmail(@RequestBody TrialClass trialClass) {
		return trialClassService.updateAndSendEmail(trialClass);
	}

	@GetMapping("/gettrialclass/{requestEmailOrUsername}")
	@PreAuthorize("hasAnyAuthority('PARENT', 'STUDENT')")
	public List<TrialClass> getTrialClassesForManageClass(@PathVariable String requestEmailOrUsername) {
		return trialClassService.getTrialClassesByRequesterEmail(requestEmailOrUsername);
	}

	@GetMapping("/getteachertrialClass/{teacherEmail}")
	@PreAuthorize("hasAuthority('TEACHER')")
	public List<TrialClass> getTrialClassesForTeacher(@PathVariable String teacherEmail) {
		return trialClassService.getTrialClassesByteacherEmail(teacherEmail);
	}

	@PutMapping("/addfeedback")
	@PreAuthorize("hasAnyAuthority('PARENT', 'STUDENT')")
	public TrialClass provideFeedBack(@RequestBody TrialClass trialClass) {
		return trialClassService.createTrailClass(trialClass);
	}
	
	@GetMapping("/getTeacher/{uniqueId}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<TrialClass> retriveTeacherByUniqueId(@PathVariable String uniqueId) {
		return trialClassService.getTeacherByUniqueId(uniqueId);
	}
}
