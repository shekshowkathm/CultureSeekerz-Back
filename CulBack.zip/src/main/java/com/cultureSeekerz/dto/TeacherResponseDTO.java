package com.cultureSeekerz.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TeacherResponseDTO {

	private String name;
	private String email;
	private String gender;
	private String UG;
	private String PG;
	private boolean B_Ed;
	private boolean M_Ed;
	private String experience;
	private List<String> specializedIn;
	private String additionalQualification;
	private String mode;
	private String profile;
	private String about;
	private boolean trailClass;
	private Long teacherId;
	private String teacherUniqueId;
	private List<ScheduleClassResponseDTO> scheduleClass;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getUG() {
		return UG;
	}

	public void setUG(String uG) {
		UG = uG;
	}

	public String getPG() {
		return PG;
	}

	public void setPG(String pG) {
		PG = pG;
	}

	public boolean isB_Ed() {
		return B_Ed;
	}

	public void setB_Ed(boolean b_Ed) {
		B_Ed = b_Ed;
	}

	public boolean isM_Ed() {
		return M_Ed;
	}

	public void setM_Ed(boolean m_Ed) {
		M_Ed = m_Ed;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public List<String> getSpecializedIn() {
		return specializedIn;
	}

	public void setSpecializedIn(List<String> specializedIn) {
		this.specializedIn = specializedIn;
	}

	public String getAdditionalQualification() {
		return additionalQualification;
	}

	public void setAdditionalQualification(String additionalQualification) {
		this.additionalQualification = additionalQualification;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public boolean isTrailClass() {
		return trailClass;
	}

	public void setTrailClass(boolean trailClass) {
		this.trailClass = trailClass;
	}

	public Long getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(Long teacherId) {
		this.teacherId = teacherId;
	}

	public String getTeacherUniqueId() {
		return teacherUniqueId;
	}

	public void setTeacherUniqueId(String teacherUniqueId) {
		this.teacherUniqueId = teacherUniqueId;
	}

	public List<ScheduleClassResponseDTO> getScheduleClass() {
		return scheduleClass;
	}

	public void setScheduleClass(List<ScheduleClassResponseDTO> scheduleClass) {
		this.scheduleClass = scheduleClass;
	}

	@Override
	public String toString() {
		return "TeacherResponseDTO [name=" + name + ", email=" + email + ", gender=" + gender + ", UG=" + UG + ", PG="
				+ PG + ", B_Ed=" + B_Ed + ", M_Ed=" + M_Ed + ", experience=" + experience + ", specializedIn="
				+ specializedIn + ", additionalQualification=" + additionalQualification + ", mode=" + mode
				+ ", profile=" + profile + ", about=" + about + ", trailClass=" + trailClass + ", teacherId="
				+ teacherId + ", teacherUniqueId=" + teacherUniqueId + ", scheduleClass=" + scheduleClass + "]";
	}

}
