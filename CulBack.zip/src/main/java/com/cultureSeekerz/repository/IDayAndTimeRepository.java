package com.cultureSeekerz.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cultureSeekerz.entity.DayAndTime;

@Repository
public interface IDayAndTimeRepository extends JpaRepository<DayAndTime, Long> {

}
