package com.cultureSeekerz.responseDTO;

public class FeesProvider {

	private String childName;
	private String teacherName;
	private String feesRange;
	private String classType;
	private String ageGroup;
	private double classFees;
	private Long studentId;
	private String studentSelectedTime;
	private String studentSelectedDate;

	public String getChildName() {
		return childName;
	}

	public void setChildName(String childName) {
		this.childName = childName;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getFeesRange() {
		return feesRange;
	}

	public void setFeesRange(String feesRange) {
		this.feesRange = feesRange;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public String getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}

	public double getClassFees() {
		return classFees;
	}

	public void setClassFees(double classFees) {
		this.classFees = classFees;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public String getStudentSelectedTime() {
		return studentSelectedTime;
	}

	public void setStudentSelectedTime(String studentSelectedTime) {
		this.studentSelectedTime = studentSelectedTime;
	}

	public String getStudentSelectedDate() {
		return studentSelectedDate;
	}

	public void setStudentSelectedDate(String studentSelectedDate) {
		this.studentSelectedDate = studentSelectedDate;
	}
}
