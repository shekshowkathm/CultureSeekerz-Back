package com.cultureSeekerz.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cultureSeekerz.entity.ActiveClass;

@Repository
public interface IActiveClassRepository extends JpaRepository<ActiveClass, Long> {

	List<ActiveClass> findByActivityAndApproveIsTrue(String activity);
	
	List<ActiveClass> findByActivityAndApproveIsFalse(String activity);

	List<ActiveClass> findByApproveIsTrue();

	@Query(value = "SELECT * FROM active_class a WHERE :standard = ANY(a.age_group) AND a.approve = true", nativeQuery = true)
	List<ActiveClass> findByAgeGroupContainingAndApproveIsTrue(@Param("standard") String standard);

	@Query(value = "SELECT * FROM active_class a WHERE :type = ANY(a.class_type) AND a.approve = true", nativeQuery = true)
	List<ActiveClass> findByClassTypeContainingAndApproveIsTrue(@Param("type") String type);

	@Query(value = "SELECT * FROM active_class a WHERE :days = ANY(a.day) AND a.approve = true", nativeQuery = true)
	List<ActiveClass> findByDayContainingAndApproveIsTrue(@Param("days") String days);

	@Query(value = "SELECT * FROM active_class a WHERE :time = ANY(a.available_time) AND a.approve = true", nativeQuery = true)
	List<ActiveClass> findByAvailableTimeContainingAndApproveIsTrue(@Param("time") String time);

	List<ActiveClass> findByClassUniqueId(String classUniqueId);

	List<ActiveClass> findByUniqueId(String uniqueId);

}
