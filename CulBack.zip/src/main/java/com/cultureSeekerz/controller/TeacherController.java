package com.cultureSeekerz.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cultureSeekerz.Enum.Role;
import com.cultureSeekerz.dto.ActiveClassResponse;
import com.cultureSeekerz.dto.AdminTeacherDTO;
import com.cultureSeekerz.dto.ScheduleClassResponseDTO;
import com.cultureSeekerz.dto.TeacherScheduleDTO;
import com.cultureSeekerz.entity.Teacher;
import com.cultureSeekerz.responseDTO.TeacherCalender;
import com.cultureSeekerz.service.TeacherService;

@RestController
@RequestMapping("/teacher")
@CrossOrigin("*")
public class TeacherController {

	@Autowired
	public TeacherService teacherService;

	@PostMapping("/add")
	public Teacher createTeacher(@RequestBody Teacher teacher) {
		return teacherService.createTeacher(teacher);
	}

	@PutMapping("/update")
	@PreAuthorize("hasAuthority('TEACHER')")
	public Map<String, String> updateTeacher(@RequestBody Teacher teacher) {
		return teacherService.updateTeacherDetails(teacher);
	}

	@GetMapping("/retrieveTeachers/{specialization}/{approveStatus}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<AdminTeacherDTO> retrieveTeachers(@PathVariable String specialization,
			@PathVariable boolean approveStatus) {
		return teacherService.retrieveTeachers(Role.ADMIN, specialization, approveStatus);
	}

	@GetMapping("/getTeacherByuniqueId/{uniqueId}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<AdminTeacherDTO> getTeacher(@PathVariable String uniqueId) {
		return teacherService.getTeacherByUniqueId(uniqueId);
	}

	@GetMapping("/get/{id}")
	@PreAuthorize("hasAuthority('TEACHER')")
	public TeacherScheduleDTO fetchTeacher(@PathVariable Long id) {
		return teacherService.getTeacher(id, Role.TEACHER);
	}

	@GetMapping("/getmanageclass/{id}")
	@PreAuthorize("hasAuthority('TEACHER')")
	public List<ScheduleClassResponseDTO> getManageClass(@PathVariable Long id) {
		return teacherService.getManageClass(id, Role.TEACHER);
	}

	@PutMapping("/aprroveteacher/{id}")
	@PreAuthorize("hasAuthority('ADMIN')")
	public String approveTeacher(@PathVariable Long id) {
		return teacherService.approveTeacher(id);
	}

	@GetMapping("/gettrialclassteachers/{timeZone}")
	public List<ActiveClassResponse> getTrailClassTeachers(@PathVariable String timeZone) {
		return teacherService.getTeacherByTrailClass(Role.USER, timeZone);
	}

	@GetMapping("/teacherCalender/{id}")
	@PreAuthorize("hasAuthority('TEACHER')")
	public List<TeacherCalender> teacherCalender(@PathVariable Long id) {
		return teacherService.getTeacherCalender(id);
	}
}
