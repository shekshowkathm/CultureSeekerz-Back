package com.cultureSeekerz.responseDTO;

import java.util.List;

import com.cultureSeekerz.dto.StudentResponse;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DayAndTimeDTO {

	private Long dayAndTimeId;
	private String day;
	private String startTime;
	private String endTime;
	private String startDate;
	private String endDate;
	private String meetingLink;
	private List<StudentResponse> enrollStudents;

	public Long getDayAndTimeId() {
		return dayAndTimeId;
	}

	public void setDayAndTimeId(Long dayAndTimeId) {
		this.dayAndTimeId = dayAndTimeId;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getMeetingLink() {
		return meetingLink;
	}

	public void setMeetingLink(String meetingLink) {
		this.meetingLink = meetingLink;
	}

	public List<StudentResponse> getEnrollStudents() {
		return enrollStudents;
	}

	public void setEnrollStudents(List<StudentResponse> enrollStudents) {
		this.enrollStudents = enrollStudents;
	}

	@Override
	public String toString() {
		return "DayAndTimeDTO [dayAndTimeId=" + dayAndTimeId + ", day=" + day + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", startDate=" + startDate + ", endDate=" + endDate + ", meetingLink="
				+ meetingLink + ", enrollStudents=" + enrollStudents + "]";
	}

}
