package com.cultureSeekerz.dto;

import java.util.List;

public class GoalsAndFeedbackDTO {

	private List<String> goals;
	private List<String> feedbacks;
	private String activity;
	private String teacherName;
	private String profile;

	public List<String> getGoals() {
		return goals;
	}

	public void setGoals(List<String> goals) {
		this.goals = goals;
	}

	public List<String> getFeedbacks() {
		return feedbacks;
	}

	public void setFeedbacks(List<String> feedbacks) {
		this.feedbacks = feedbacks;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	@Override
	public String toString() {
		return "GoalsAndFeedbackDTO [goals=" + goals + ", feedbacks=" + feedbacks + ", activity=" + activity
				+ ", teacherName=" + teacherName + ", profile=" + profile + "]";
	}

}
