package com.cultureSeekerz.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cultureSeekerz.entity.Login;
import com.cultureSeekerz.entity.Seekerz;
import com.cultureSeekerz.repository.ISeekerzRepository;

@Service
public class LoginService implements UserDetailsService {

	@Autowired
	public ISeekerzRepository seekerzRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<Seekerz> seekerz = seekerzRepository.findByEmailAndStatus(username, true);
		return seekerz.map(Login::new).orElseThrow(() -> new UsernameNotFoundException(username + "user not found"));
	}
}
