package com.cultureSeekerz.dto;

import java.util.List;

import com.cultureSeekerz.responseDTO.DayAndTimeDTO;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScheduleClassResponseDTO {

	private Long classId;
	private String classUniqueId;
	private String activity;
	private String description;
	private String demoVideo;
	private String classImage;
	private List<String> day;
	private List<String> classType;
	private List<String> ageGroup;
	private int totalEnrolledStudentsCount;
	private StudentResponse studentResponse;
	private TeacherInfoResponse teacher;
	private List<DayAndTimeDTO> dayAndTimeDTO;
	private boolean approve;
	private String feesRange;
	private String feesInr;

	public Long getClassId() {
		return classId;
	}

	public void setClassId(Long classId) {
		this.classId = classId;
	}

	public String getClassUniqueId() {
		return classUniqueId;
	}

	public void setClassUniqueId(String classUniqueId) {
		this.classUniqueId = classUniqueId;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDemoVideo() {
		return demoVideo;
	}

	public void setDemoVideo(String demoVideo) {
		this.demoVideo = demoVideo;
	}

	public String getClassImage() {
		return classImage;
	}

	public void setClassImage(String classImage) {
		this.classImage = classImage;
	}

	public List<String> getDay() {
		return day;
	}

	public void setDay(List<String> day) {
		this.day = day;
	}

	public List<String> getClassType() {
		return classType;
	}

	public void setClassType(List<String> classType) {
		this.classType = classType;
	}

	public List<String> getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(List<String> ageGroup) {
		this.ageGroup = ageGroup;
	}

	public int getTotalEnrolledStudentsCount() {
		return totalEnrolledStudentsCount;
	}

	public void setTotalEnrolledStudentsCount(int totalEnrolledStudentsCount) {
		this.totalEnrolledStudentsCount = totalEnrolledStudentsCount;
	}

	public StudentResponse getStudentResponse() {
		return studentResponse;
	}

	public void setStudentResponse(StudentResponse studentResponse) {
		this.studentResponse = studentResponse;
	}

	public TeacherInfoResponse getTeacher() {
		return teacher;
	}

	public void setTeacher(TeacherInfoResponse teacher) {
		this.teacher = teacher;
	}

	public List<DayAndTimeDTO> getDayAndTimeDTO() {
		return dayAndTimeDTO;
	}

	public void setDayAndTimeDTO(List<DayAndTimeDTO> dayAndTimeDTO) {
		this.dayAndTimeDTO = dayAndTimeDTO;
	}

	public boolean isApprove() {
		return approve;
	}

	public void setApprove(boolean approve) {
		this.approve = approve;
	}

	public String getFeesRange() {
		return feesRange;
	}

	public void setFeesRange(String feesRange) {
		this.feesRange = feesRange;
	}

	public String getFeesInr() {
		return feesInr;
	}

	public void setFeesInr(String feesInr) {
		this.feesInr = feesInr;
	}

	@Override
	public String toString() {
		return "ScheduleClassResponseDTO [classId=" + classId + ", classUniqueId=" + classUniqueId + ", activity="
				+ activity + ", description=" + description + ", demoVideo=" + demoVideo + ", classImage=" + classImage
				+ ", day=" + day + ", classType=" + classType + ", ageGroup=" + ageGroup
				+ ", totalEnrolledStudentsCount=" + totalEnrolledStudentsCount + ", studentResponse=" + studentResponse
				+ ", teacher=" + teacher + ", dayAndTimeDTO=" + dayAndTimeDTO + ", approve=" + approve + ", feesRange="
				+ feesRange + ", feesInr=" + feesInr + "]";
	}

}
