package com.cultureSeekerz;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.cultureSeekerz.firebase.FirebaseInitializer;

@SpringBootApplication
@EnableScheduling
public class CultureSeekerzApplication implements CommandLineRunner {

	@Autowired
	private FirebaseInitializer firebaseInitializer;

	public static void main(String[] args) {
		SpringApplication.run(CultureSeekerzApplication.class, args);
	}
	

	@Override
	public void run(String... args) throws IOException {
		try {
			firebaseInitializer.initialize();
		} catch (Exception e) {
			System.err.println("Error in CommandLineRunner: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
