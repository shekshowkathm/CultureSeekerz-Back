package com.cultureSeekerz.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cultureSeekerz.Enum.Role;
import com.cultureSeekerz.dto.ScheduleClassResponseDTO;
import com.cultureSeekerz.entity.Student;
import com.cultureSeekerz.requestDTO.Child360DTO;
import com.cultureSeekerz.requestDTO.RescheduledDataDTO;
import com.cultureSeekerz.responseDTO.Accomplishment;
import com.cultureSeekerz.responseDTO.CalenderDTO;
import com.cultureSeekerz.responseDTO.Child360ParentDTO;
import com.cultureSeekerz.responseDTO.FeesProvider;
import com.cultureSeekerz.responseDTO.PaymentHistoryAdmin;
import com.cultureSeekerz.responseDTO.PaymentHistroy;
import com.cultureSeekerz.responseDTO.RemainderDTO;
import com.cultureSeekerz.responseDTO.RescheduleDTO;
import com.cultureSeekerz.service.StudentService;

@RestController
@CrossOrigin("*")
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService studentService;

	@PostMapping("/add")
	@PreAuthorize("hasAnyAuthority('PARENT', 'STUDENT')")
	public String createStudent(@RequestBody Student student) {
		return studentService.createStudent(student);
	}

	// student manage class
	@GetMapping("/get/{id}/{timeZone}")
	@PreAuthorize("hasAnyAuthority('PARENT', 'STUDENT')")
	public List<ScheduleClassResponseDTO> getStudentById(@PathVariable Long id, @PathVariable String timeZone) {
		return studentService.getStudentById(id, Role.STUDENT, timeZone);
	}

	// child id manage class
	@GetMapping("/getChildClass/{id}/{timeZone}")
	@PreAuthorize("hasAuthority('PARENT')")
	public List<ScheduleClassResponseDTO> parentManageClass(@PathVariable Long id, @PathVariable String timeZone) {
		return studentService.parentManageClass(id, Role.PARENT, timeZone);
	}

	// student Id
	@PutMapping("/parentapproveclass")
	@PreAuthorize("hasAuthority('PARENT')")
	public String parentApproveClasses(@RequestParam Long studentId, @RequestParam String classType,
			@RequestParam String ageGroup) {
		return studentService.parentApproveChildClass(studentId, classType, ageGroup);
	}

	@DeleteMapping("/remove/{id}")
	@PreAuthorize("hasAnyAuthority('PARENT', 'STUDENT')")
	public Map<String, String> deleteClass(@PathVariable Long id) {
		return studentService.removeEnrolledClass(id);
	}

	// Login id
	@GetMapping("/studentcalendar/{id}/{timezone}")
	@PreAuthorize("hasAnyAuthority('PARENT', 'STUDENT')")
	public List<CalenderDTO> studentCalendar(@PathVariable Long id, @PathVariable String timezone) {
		return studentService.studentCalender(id, timezone);
	}

	@GetMapping("/parentCalendar/{id}/{timezone}")
	@PreAuthorize("hasAnyAuthority('PARENT')")
	public List<CalenderDTO> parentCalendar(@PathVariable Long id, @PathVariable String timezone) {
		return studentService.parentCalender(id, timezone);
	}

	@GetMapping("/remainderclass/{id}/{timeZone}")
	@PreAuthorize("hasAnyAuthority('PARENT')")
	public List<ScheduleClassResponseDTO> retrieveRemainderClass(@PathVariable Long id, @PathVariable String timeZone) {
		return studentService.getRemainderClass(id, Role.STUDENT, timeZone);
	}

	@PutMapping("/sendRemaindermail")
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	public Map<String, String> sendRemainderMail(@RequestBody RemainderDTO remainder) {
		return studentService.sendPaymentRemainderMail(remainder);
	}

	@GetMapping("/learningProgressByAge/{id}")
	@PreAuthorize("hasAnyAuthority('PARENT')")
	public List<Child360ParentDTO> retrieveLearningProgress(@PathVariable Long id) {
		return studentService.getLearningProgressByAge(id);
	}

	@PutMapping("/providelearningprogress")
	@PreAuthorize("hasAnyAuthority('TEACHER')")
	public Map<String, String> provideLearningProgress(@RequestBody Child360DTO child360DTO) {
		return studentService.updateChild360(child360DTO);
	}

	@GetMapping("/getActivity/{id}")
	@PreAuthorize("hasAnyAuthority('PARENT')")
	public List<String> retrieveActivity(@PathVariable Long id) {
		return studentService.retrieveActivity(id);
	}

	@GetMapping("/learningProgressByActivity/{id}/{activity}")
	@PreAuthorize("hasAnyAuthority('PARENT')")
	public List<Child360ParentDTO> retrieveLearningProgressByActivity(@PathVariable Long id,
			@PathVariable String activity) {
		return studentService.getLearningProgressByActivity(id, activity);
	}

	@GetMapping("/goalsandfeedback/{id}")
	@PreAuthorize("hasAnyAuthority('PARENT')")
	public List<Child360ParentDTO> retrieveGoalsAndFeedback(@PathVariable Long id) {
		return studentService.getGoalsAndFeedbacks(id);
	}

	@GetMapping("/goalsandfeedbackByage/{id}/{activity}/{age}")
	@PreAuthorize("hasAnyAuthority('PARENT')")
	public List<Child360ParentDTO> retrieveGoalsAndFeedbackByAge(@PathVariable Long id, @PathVariable String activity,
			@PathVariable int age) {
		return studentService.getGoalsAndFeedbacksByAge(id, activity, age);
	}

	@GetMapping("/accomplishmentByactivity/{id}/{activity}")
	@PreAuthorize("hasAnyAuthority('PARENT')")
	public List<Accomplishment> retrieveAccomplishmentByActivity(@PathVariable Long id, @PathVariable String activity) {
		return studentService.getaccomplishmentByActivity(id, activity);
	}

	@GetMapping("/accomplishmentByAge/{id}/{activity}/{age}")
	@PreAuthorize("hasAnyAuthority('PARENT')")
	public Accomplishment retrieveAccomplishmentByAge(@PathVariable Long id, @PathVariable String activity,
			@PathVariable int age) {
		return studentService.getAccomplishmentByAge(id, activity, age);
	}

	@GetMapping("/accomplishment/{id}")
	@PreAuthorize("hasAnyAuthority('PARENT')")
	public List<Accomplishment> retrieveAccomplishment(@PathVariable Long id) {
		return studentService.getAccomplishment(id);
	}

	@PutMapping("/reschedule/{id}")
	@PreAuthorize("hasAnyAuthority('PARENT', 'STUDENT')")
	public Map<String, String> sendReschedule(@PathVariable Long id) {
		return studentService.updateClassForReschedule(id);
	}

	@GetMapping("/getrescheduleclasses/{activity}/{rescheduleStatus}")
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	public List<RescheduleDTO> retrieveRescheduleClasses(@PathVariable String activity,
			@PathVariable boolean rescheduleStatus) {
		return studentService.retrieveRescheduleClasses(activity, rescheduleStatus);
	}

	@GetMapping("/getStudentByUniqueId/{uniqueId}")
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	public List<RescheduleDTO> retireveTeacherByUniqueId(@PathVariable String uniqueId) {
		return studentService.getStudentByUniqueId(uniqueId);
	}

	@PutMapping("/updateReschedule")
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	public Map<String, String> updateRescheduleClass(@RequestBody RescheduledDataDTO newRescheduleData) {
		return studentService.updateRescheduleClass(newRescheduleData);
	}

	@GetMapping("/getEnrolledStudents/{activity}/{feeStatus}")
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	public List<FeesProvider> getEnrolledStudents(@PathVariable String activity, @PathVariable boolean feeStatus) {
		return studentService.getEnrolledStudents(activity, feeStatus);
	}

	@PutMapping("/updateFeesForStudent")
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	public Map<String, String> updateFeesForStudents(@RequestBody FeesProvider feesProvider) {
		return studentService.updateFeesForStudents(feesProvider.getStudentId(), feesProvider.getClassFees());
	}

	@GetMapping("/retrieveClasses/{studentLoginId}/{month}")
	@PreAuthorize("hasAnyAuthority('PARENT', 'STUDENT')")
	public PaymentHistroy retrieveEnrolledClasses(@PathVariable Long studentLoginId, @PathVariable int month) {
		return studentService.retrieveEnrolledOnClasses(studentLoginId, month);
	}

	@GetMapping("/retrievePaymentHistory/{month}/{paidStatus}")
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	public List<PaymentHistoryAdmin> retrievePaymentHistoryForAdmin(@PathVariable int month,
			@PathVariable boolean paidStatus) {
		return studentService.retrievePaymentHistory(month, paidStatus);
	}

	@PutMapping("/joinClass/{studentId}")
	@PreAuthorize("hasAnyAuthority('PARENT', 'STUDENT')")
	public Map<String, String> joinTheClass(@PathVariable Long studentId) {
		return studentService.updateTheClassAfterJoining(studentId);
	}

	@PutMapping("/paymentApproved")
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	public Map<String, String> updateThePayment(@RequestBody List<Long> studentId) {
		return studentService.updatePayment(studentId);
	}

	@GetMapping("/getpaymenthistroyByUniqueId/{uniqueId}/{month}")
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	public List<PaymentHistoryAdmin> retrievePaymentHistoryByUniqueId(@PathVariable String uniqueId,
			@PathVariable int month) {
		return studentService.retrieveHistroyPaymentByUniqueId(uniqueId, month);
	}
}
