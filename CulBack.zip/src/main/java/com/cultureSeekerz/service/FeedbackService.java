package com.cultureSeekerz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cultureSeekerz.entity.Feedback;
import com.cultureSeekerz.repository.IFeedbackRepository;

@Service
public class FeedbackService {

	@Autowired
	private IFeedbackRepository feedbackRepository;

	public Feedback saveFeedback(Feedback feedback) {
		feedbackRepository.save(feedback);
		return feedback;
	}

	public List<Feedback> getAllFeedbackApproachedTrue() {
		List<Feedback> feedBacks = feedbackRepository.findByApproachedIsTrue();
		return feedBacks;
	}

	public List<Feedback> getAllFeedbackApproachedFalse() {
		List<Feedback> feedBacks = feedbackRepository.findByApproachedIsFalse();
		return feedBacks;
	}

	public Feedback updateIsApproached(Long id) {
		Feedback feedback = feedbackRepository.findById(id).get();
		feedback.setApproached(true);
		return feedbackRepository.save(feedback);
	}
}
