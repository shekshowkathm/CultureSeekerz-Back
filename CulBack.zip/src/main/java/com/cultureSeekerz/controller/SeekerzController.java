package com.cultureSeekerz.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cultureSeekerz.entity.Seekerz;
import com.cultureSeekerz.entity.Teacher;
import com.cultureSeekerz.repository.ISeekerzRepository;
import com.cultureSeekerz.repository.ITeacherRepository;
import com.cultureSeekerz.requestDTO.AuthDTO;
import com.cultureSeekerz.requestDTO.ChangePasswordDTO;
import com.cultureSeekerz.responseDTO.LoginDTO;
import com.cultureSeekerz.responseDTO.SeekerzDTO;
import com.cultureSeekerz.service.JWTService;
import com.cultureSeekerz.service.SeekerzService;
import com.cultureSeekerz.utils.EmailSender;

@RestController
@CrossOrigin("*")
@RequestMapping("/seekerz")
public class SeekerzController {

	@Autowired
	public SeekerzService seekerzService;
	@Autowired
	public JWTService jwtService;

	@Autowired
	public ISeekerzRepository seekerzRepository;
	@Autowired
	public AuthenticationManager authenticationManager;
	@Autowired
	public EmailSender emailSender;
	@Autowired
	public ITeacherRepository teacherRepository;

	@PostMapping("/add")
	public SeekerzDTO createSeekerzProfile(@RequestBody Seekerz seekerz) {
		return seekerzService.createSeekerz(seekerz);
	}

	// Not used
	@GetMapping("/get")
	@PreAuthorize("hasAuthority('ADMIN')")
	public List<Seekerz> retrieveAllSeekerz() {
		return seekerzService.retrieveAllSeekerz();
	}

	@GetMapping("/get/{id}")
	@PreAuthorize("hasAnyAuthority('PARENT', 'STUDENT')")
	public Optional<Seekerz> retrieveSeekerzById(@PathVariable Long id) {
		return seekerzService.retrieveSeekerzById(id);
	}

	@PutMapping("/update")
//	@PreAuthorize("hasAnyAuthority('TEACHER', 'STUDENT','PARENT')")
	public Seekerz updateSeekerzProfile(@RequestBody Seekerz seekers) {
		return seekerzService.updateSeekerzProfile(seekers);
	}

	// not used
	@DeleteMapping("/delete")
	@PreAuthorize("hasAuthority('ADMIN')")
	public String deleteSeekerzById(Long id) {
		return seekerzService.deleteById(id);
	}

	@GetMapping("/verifyOtp/{otp}")
	public SeekerzDTO verifyOtpAndActivateAccount(@PathVariable String otp) {
		return seekerzService.verifyOtpAndActivateAccount(otp);
	}

	@GetMapping("/resend/{email}")
	public Seekerz resendOtpForEmail(@PathVariable String email) {
		return seekerzService.resendOTP(email);
	}

	@PutMapping("/forgotPassword")
	public SeekerzDTO forgotPasswordAndChange(@RequestBody ChangePasswordDTO changePasswordDto) {
		return seekerzService.forgotPassowrd(changePasswordDto);
	}

	@GetMapping("/forgotpassword/{email}")
	public SeekerzDTO forGotPassword(@PathVariable String email) {
		return seekerzService.forgotPasswordAndChangePassword(email);
	}

	@PostMapping("/authenticate")
	public LoginDTO authenticateAndGenerateToken(@RequestBody AuthDTO authDto) {
		LoginDTO loginResponseDto = new LoginDTO();

		Optional<Seekerz> optionalSeekerzOTP = seekerzRepository.findByEmail(authDto.getUsername());

		if (optionalSeekerzOTP.isEmpty()) {
			loginResponseDto.setResponse("Invalid User");
			return loginResponseDto;
		}

		Seekerz details = optionalSeekerzOTP.get();
		Seekerz seekerz = seekerzRepository.findByEmailAndStatusIsTrue(authDto.getUsername());

		if (seekerz == null) {
			loginResponseDto.setUsername(details.getEmail());
			loginResponseDto.setRole(details.getRole());
			loginResponseDto.setResponse("OTP not verified");
			return loginResponseDto;
		}

		Authentication authentication = authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(authDto.getUsername(), authDto.getPassword()));

		if (!authentication.isAuthenticated()) {
			throw new UsernameNotFoundException("Invalid user request!");
		}

		loginResponseDto.setId(seekerz.getId());
		loginResponseDto.setRole(seekerz.getRole());
		loginResponseDto.setUsername(authDto.getUsername());
		loginResponseDto.setPersonalId(seekerz.getPersonalId());
		loginResponseDto.setTimeZone(seekerz.getTimeZone());

		if ("TEACHER".equals(seekerz.getRole())) {
			if (seekerz.getPersonalId() != null) {
				Optional<Teacher> optionalTeacher = teacherRepository.findById(seekerz.getPersonalId());

				if (optionalTeacher.isPresent() && !optionalTeacher.get().isApprove()) {
					loginResponseDto.setResponse("Not verified");
					return loginResponseDto;
				}
			} else {
				loginResponseDto.setResponse("Step2");
				return loginResponseDto;
			}
		}

		loginResponseDto.setToken(jwtService.generateToken(authDto.getUsername()));
		loginResponseDto.setResponse("Login successfully");

		return loginResponseDto;
	}

	@PutMapping("/unique/{email}")
	public String generateUniqueId(@PathVariable String email) {
		return seekerzService.generateUniqueId(email);
	}

}
