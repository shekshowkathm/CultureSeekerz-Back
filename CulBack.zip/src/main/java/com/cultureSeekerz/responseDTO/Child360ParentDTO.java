package com.cultureSeekerz.responseDTO;

import java.util.List;

import com.cultureSeekerz.dto.GoalsAndFeedbackDTO;
import com.cultureSeekerz.dto.LearningProgressByActivityDTO;
import com.cultureSeekerz.dto.LearningProgressByAgeDTO;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Child360ParentDTO {

	private int age;
	private Long studentLoginId;
	private List<LearningProgressByAgeDTO> learningProgressByAge;
	private List<LearningProgressByActivityDTO> learningProgressByActivity;
	private List<GoalsAndFeedbackDTO> goalsAndFeedbacks;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Long getStudentLoginId() {
		return studentLoginId;
	}

	public void setStudentLoginId(Long studentLoginId) {
		this.studentLoginId = studentLoginId;
	}

	public List<LearningProgressByAgeDTO> getLearningProgressByAge() {
		return learningProgressByAge;
	}

	public void setLearningProgressByAge(List<LearningProgressByAgeDTO> learningProgressByAge) {
		this.learningProgressByAge = learningProgressByAge;
	}

	public List<LearningProgressByActivityDTO> getLearningProgressByActivity() {
		return learningProgressByActivity;
	}

	public void setLearningProgressByActivity(List<LearningProgressByActivityDTO> learningProgressByActivity) {
		this.learningProgressByActivity = learningProgressByActivity;
	}

	public List<GoalsAndFeedbackDTO> getGoalsAndFeedbacks() {
		return goalsAndFeedbacks;
	}

	public void setGoalsAndFeedbacks(List<GoalsAndFeedbackDTO> goalsAndFeedbacks) {
		this.goalsAndFeedbacks = goalsAndFeedbacks;
	}

	@Override
	public String toString() {
		return "Child360ParentDTO [age=" + age + ", studentLoginId=" + studentLoginId + ", learningProgressByAge="
				+ learningProgressByAge + ", learningProgressByActivity=" + learningProgressByActivity
				+ ", goalsAndFeedbacks=" + goalsAndFeedbacks + "]";
	}

}
