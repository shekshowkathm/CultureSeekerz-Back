package com.cultureSeekerz.dto;

public class ActiveClassResponse {

	private Long classId;
	private Long teacherId;
	private TeacherResponseDTO teacherResponse;
	private ScheduleClassResponseDTO scheduleClass;


	public Long getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(Long teacherId) {
		this.teacherId = teacherId;
	}

	public TeacherResponseDTO getTeacherResponse() {
		return teacherResponse;
	}

	public void setTeacherResponse(TeacherResponseDTO teacherResponse) {
		this.teacherResponse = teacherResponse;
	}

	public ScheduleClassResponseDTO getScheduleClass() {
		return scheduleClass;
	}

	public void setScheduleClass(ScheduleClassResponseDTO scheduleClass) {
		this.scheduleClass = scheduleClass;
	}

	public Long getClassId() {
		return classId;
	}

	public void setClassId(Long classId) {
		this.classId = classId;
	}

	@Override
	public String toString() {
		return "ActiveClassResponse [teacherId=" + teacherId + ", teacherResponse=" + teacherResponse
				+ ", scheduleClass=" + scheduleClass + ", classId=" + classId + "]";
	}

}
