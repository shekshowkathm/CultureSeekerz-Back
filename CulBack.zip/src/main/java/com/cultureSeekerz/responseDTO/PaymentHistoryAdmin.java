package com.cultureSeekerz.responseDTO;

import java.util.List;

import com.cultureSeekerz.dto.MyClassesForPayment;

public class PaymentHistoryAdmin {

	private String studentName;
	private String studentUniqueId;
	private String parentName;
	private String parentEmail;
	private String phonenumber;
	private String monthlyAmount;
	private String monthName;
	private List<MyClassesForPayment> paymentHistory;

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentUniqueId() {
		return studentUniqueId;
	}

	public void setStudentUniqueId(String studentUniqueId) {
		this.studentUniqueId = studentUniqueId;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getParentEmail() {
		return parentEmail;
	}

	public void setParentEmail(String parentEmail) {
		this.parentEmail = parentEmail;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getMonthlyAmount() {
		return monthlyAmount;
	}

	public void setMonthlyAmount(String monthlyAmount) {
		this.monthlyAmount = monthlyAmount;
	}

	public String getMonthName() {
		return monthName;
	}

	public void setMonthName(String monthName) {
		this.monthName = monthName;
	}

	public List<MyClassesForPayment> getPaymentHistory() {
		return paymentHistory;
	}

	public void setPaymentHistory(List<MyClassesForPayment> paymentHistory) {
		this.paymentHistory = paymentHistory;
	}

	@Override
	public String toString() {
		return "PaymentHistoryAdmin [studentName=" + studentName + ", studentUniqueId=" + studentUniqueId
				+ ", parentName=" + parentName + ", parentEmail=" + parentEmail + ", phonenumber=" + phonenumber
				+ ", monthlyAmount=" + monthlyAmount + ", monthName=" + monthName + ", paymentHistory=" + paymentHistory
				+ "]";
	}
}
