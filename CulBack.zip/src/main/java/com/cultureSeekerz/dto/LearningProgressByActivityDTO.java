package com.cultureSeekerz.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LearningProgressByActivityDTO {

	private String month;
	private List<String> topics;

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public List<String> getTopics() {
		return topics;
	}

	public void setTopics(List<String> topics) {
		this.topics = topics;
	}

	@Override
	public String toString() {
		return "LearningProgressByActivityDTO [month=" + month + ", topics=" + topics + "]";
	}

}
