<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <style>
        body {
            height: 100%;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 13px;
        }


    </style>
</head>

<body>
    
        <img src="https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/logosvg.svg">
        <div class="template-container">
        <p>Hi ${teacherName},</p>
        <p> Payment remainder </p>

        <p>Best regards,</p>
        <p>CultureSeekerz Team.</p>
    </div>


</body>

</html>